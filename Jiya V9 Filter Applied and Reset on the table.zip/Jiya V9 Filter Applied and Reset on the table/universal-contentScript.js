// ===========================================
// UNIVERSAL POWER BI CHATBOT - CONTENT SCRIPT
// ===========================================

(function () {
    'use strict';

    // Prevent multiple injections
    if (window.__universalPowerBIChatbotInjected) return;
    window.__universalPowerBIChatbotInjected = true;

    console.log('🚀 Universal Power BI Chatbot Content Script Initializing...');

    // Load and inject the universal chatbot system
    function loadUniversalChatbotSystem() {
        // Inject the complete universal chatbot directly
        const script = document.createElement('script');
        script.textContent = `
            // UNIVERSAL POWER BI CHATBOT - DIRECT INJECTION
            console.log('🚀 Universal Power BI Chatbot System Loading...');
            
            // Universal Detection System
            class UniversalDetector {
                detectDashboard() {
                    const features = {
                        tabs: document.querySelectorAll('.tabControl, .tab-container, .page-tabs, [role="tab"], .nav-tabs, .powerbi-tabControl'),
                        bookmarks: document.querySelectorAll('.bookmark, .bookmark-btn, [onclick*="bookmark"], [data-automation-id*="bookmark"]'),
                        filters: document.querySelectorAll('.slicer, .filter, .filter-container, select, input[type="text"], .dropdown'),
                        visuals: document.querySelectorAll('.visual, .visualization, .chart, .visual-container, .powerbi-visual, table'),
                        search: document.querySelectorAll('input[type="search"], .search-box, [placeholder*="search"]'),
                        actions: document.querySelectorAll('.export-button, .refresh-button, [aria-label*="export"], [aria-label*="refresh"]')
                    };
                    
                    return {
                        dashboardType: this.identifyDashboardType(),
                        capabilities: Object.keys(features).filter(key => features[key].length > 0),
                        elements: features
                    };
                }
                
                identifyDashboardType() {
                    if (window.powerBIComplexDashboard || window.universalPowerBITestDashboard) return 'test-dashboard';
                    if (window.powerBISimulator) return 'simulator';
                    if (window.location.href.includes('powerbi.microsoft.com')) return 'powerbi-service';
                    if (document.querySelector('.powerbi-embed, [data-automation-id*="powerbi"]')) return 'embedded-powerbi';
                    if (document.querySelector('.visual, .chart, .dashboard, .slicer')) return 'generic-dashboard';
                    return 'webpage';
                }
            }
            
            // Universal Interaction Engine
            class UniversalEngine {
                constructor(featureMap) {
                    this.featureMap = featureMap;
                    this.currentFilters = new Map();
                }
                
                // Navigation
                switchTab(tabName) {
                    console.log('🔄 Switching to tab:', tabName);
                    const tabs = this.featureMap.elements.tabs;
                    
                    for (const tab of tabs) {
                        const text = tab.textContent.toLowerCase();
                        if (text.includes(tabName.toLowerCase()) || tabName.toLowerCase().includes(text)) {
                            this.clickElement(tab);
                            return tab.textContent.trim();
                        }
                    }
                    return false;
                }
                
                switchBookmark(bookmarkName) {
                    console.log('📑 Switching to bookmark:', bookmarkName);
                    
                    // Try dashboard-specific APIs first
                    if (window.universalPowerBITestDashboard) {
                        const result = window.universalPowerBITestDashboard.switchBookmark(bookmarkName);
                        if (result) {
                            console.log('✅ Dashboard API bookmark switch successful:', result);
                            return result;
                        }
                    }
                    
                    if (window.powerBIComplexDashboard) {
                        try { 
                            window.applyBookmark(bookmarkName); 
                            console.log('✅ Complex dashboard bookmark applied');
                            return bookmarkName; 
                        } catch(e) {
                            console.log('⚠️ Complex dashboard method failed:', e);
                        }
                    }
                    
                    // Enhanced universal bookmark switching with multiple search strategies
                    const bookmarks = this.featureMap.elements.bookmarks;
                    const normalizedName = bookmarkName.toLowerCase().trim();
                    
                    console.log('🔍 Searching through', bookmarks.length, 'bookmark elements for:', normalizedName);
                    
                    // Strategy 1: Exact text match
                    for (const bookmark of bookmarks) {
                        const text = bookmark.textContent.toLowerCase().trim();
                        if (text === normalizedName || text.includes(normalizedName)) {
                            console.log('✅ Found exact match:', text);
                            return this.activateBookmark(bookmark, text);
                        }
                    }
                    
                    // Strategy 2: Partial word match
                    for (const bookmark of bookmarks) {
                        const text = bookmark.textContent.toLowerCase().trim();
                        const words = normalizedName.split(' ');
                        if (words.some(word => text.includes(word) && word.length > 2)) {
                            console.log('✅ Found partial match:', text);
                            return this.activateBookmark(bookmark, text);
                        }
                    }
                    
                    // Strategy 3: Onclick attribute search
                    for (const bookmark of bookmarks) {
                        const onclick = bookmark.getAttribute('onclick') || '';
                        if (onclick.toLowerCase().includes(normalizedName)) {
                            console.log('✅ Found onclick match:', onclick);
                            return this.activateBookmark(bookmark, bookmark.textContent || normalizedName);
                        }
                    }
                    
                    // Strategy 4: Data attribute search
                    for (const bookmark of bookmarks) {
                        const dataBookmark = bookmark.getAttribute('data-bookmark') || bookmark.getAttribute('data-name') || '';
                        if (dataBookmark.toLowerCase().includes(normalizedName)) {
                            console.log('✅ Found data attribute match:', dataBookmark);
                            return this.activateBookmark(bookmark, dataBookmark);
                        }
                    }
                    
                    console.log('❌ No bookmark found for:', bookmarkName);
                    return false;
                }
                
                activateBookmark(element, displayName) {
                    try {
                        // Try onclick execution first
                        const onclick = element.getAttribute('onclick');
                        if (onclick) {
                            console.log('🔄 Executing onclick:', onclick);
                            eval(onclick);
                            return displayName;
                        }
                        
                        // Try direct click
                        console.log('🔄 Attempting direct click on element');
                        element.click();
                        return displayName;
                        
                    } catch (e) {
                        try {
                            // Fallback to mouse event
                            console.log('🔄 Trying mouse event fallback');
                            const event = new MouseEvent('click', { 
                                bubbles: true, 
                                cancelable: true,
                                view: window 
                            });
                            element.dispatchEvent(event);
                            return displayName;
                        } catch (e2) {
                            console.error('❌ All bookmark activation methods failed:', e2);
                            return false;
                        }
                    }
                }
                
                // Filtering
                applyFilter(filterType, filterValue) {
                    console.log('🔧 Applying filter:', filterType, '=', filterValue);
                    
                    // Try dashboard-specific APIs first
                    if (window.universalPowerBITestDashboard) {
                        return window.universalPowerBITestDashboard.applyFilter(filterType, filterValue);
                    }
                    if (window.powerBIComplexDashboard) {
                        const filterElement = document.getElementById(filterType + 'Filter');
                        if (filterElement) {
                            filterElement.value = filterValue;
                            filterElement.dispatchEvent(new Event('change'));
                            return true;
                        }
                    }
                    if (window.powerBISimulator) {
                        if (filterType === 'region') window.powerBISimulator.updateFilters(filterValue, null, null);
                        else if (filterType === 'product') window.powerBISimulator.updateFilters(null, filterValue, null);
                        else if (filterType === 'timeperiod') window.powerBISimulator.updateFilters(null, null, filterValue);
                        return true;
                    }
                    
                    // Universal filtering
                    const filters = this.featureMap.elements.filters;
                    const normalizedType = filterType.toLowerCase();
                    
                    for (const filter of filters) {
                        const id = filter.id.toLowerCase();
                        const label = this.getFilterLabel(filter);
                        
                        if (id.includes(normalizedType) || label.includes(normalizedType)) {
                            if (filter.tagName === 'SELECT') {
                                return this.setSelectValue(filter, filterValue);
                            } else if (filter.tagName === 'INPUT') {
                                filter.value = filterValue;
                                filter.dispatchEvent(new Event('input'));
                                return true;
                            }
                        }
                    }
                    return false;
                }
                
                setSelectValue(select, value) {
                    const normalizedValue = value.toLowerCase();
                    for (const option of select.options) {
                        const optionText = option.textContent.toLowerCase();
                        const optionValue = option.value.toLowerCase();
                        
                        if (optionText.includes(normalizedValue) || 
                            optionValue.includes(normalizedValue) ||
                            normalizedValue.includes(optionText.trim())) {
                            select.value = option.value;
                            select.dispatchEvent(new Event('change'));
                            return true;
                        }
                    }
                    return false;
                }
                
                getFilterLabel(element) {
                    const label = element.previousElementSibling;
                    if (label && label.tagName === 'LABEL') {
                        return label.textContent.toLowerCase();
                    }
                    return element.getAttribute('placeholder') || element.id || '';
                }
                
                // Search
                searchData(searchTerm) {
                    console.log('🔍 Searching for:', searchTerm);
                    
                    if (window.universalPowerBITestDashboard) {
                        return window.universalPowerBITestDashboard.search(searchTerm);
                    }
                    
                    const searchBoxes = this.featureMap.elements.search;
                    if (searchBoxes.length > 0) {
                        searchBoxes[0].value = searchTerm;
                        searchBoxes[0].dispatchEvent(new Event('input'));
                        return true;
                    }
                    return false;
                }
                
                // Actions
                refreshData() {
                    console.log('🔄 Refreshing data');
                    
                    if (window.universalPowerBITestDashboard) {
                        window.universalPowerBITestDashboard.refresh();
                        return true;
                    }
                    
                    const refreshBtns = document.querySelectorAll('[aria-label*="refresh"], .refresh-button, [title*="refresh"]');
                    if (refreshBtns.length > 0) {
                        refreshBtns[0].click();
                        return true;
                    }
                    return false;
                }
                
                exportData(format = 'excel') {
                    console.log('📤 Exporting data as:', format);
                    
                    if (window.universalPowerBITestDashboard) {
                        window.universalPowerBITestDashboard.export(format);
                        return true;
                    }
                    
                    const exportBtns = document.querySelectorAll('[aria-label*="export"], .export-button, [title*="export"]');
                    if (exportBtns.length > 0) {
                        exportBtns[0].click();
                        return true;
                    }
                    return false;
                }
                
                resetFilters() {
                    console.log('🧹 Resetting all filters');
                    
                    if (window.universalPowerBITestDashboard) {
                        window.universalPowerBITestDashboard.resetFilters();
                        return true;
                    }
                    
                    if (window.resetFilters) {
                        window.resetFilters();
                        return true;
                    }
                    
                    // Universal reset
                    const selects = document.querySelectorAll('select');
                    selects.forEach(select => {
                        select.selectedIndex = 0;
                        select.dispatchEvent(new Event('change'));
                    });
                    return true;
                }
                
                clickElement(element) {
                    try {
                        element.click();
                        return true;
                    } catch (e) {
                        try {
                            const event = new MouseEvent('click', { bubbles: true });
                            element.dispatchEvent(event);
                            return true;
                        } catch (e2) {
                            console.warn('Element click failed:', e2);
                            return false;
                        }
                    }
                }
            }
            
            // Command Processor
            class CommandProcessor {
                constructor(engine) {
                    this.engine = engine;
                }
                
                processCommand(command) {
                    console.log('🧠 Processing command:', command);
                    const cmd = command.toLowerCase().trim();
                    
                    // Enhanced bookmark commands with better pattern matching
                    if (cmd.includes('bookmark') || cmd.includes('go to') || cmd.includes('switch to') || cmd.includes('show me') || cmd.includes('navigate to')) {
                        
                        // Enhanced bookmark patterns with more variations
                        const bookmarkPatterns = {
                            'sales': ['sales', 'sales focus', 'sale', 'selling'],
                            'customers': ['customer', 'customers', 'customer analytics', 'client', 'clients'],
                            'products': ['product', 'products', 'product performance', 'item', 'items'],
                            'regional': ['regional', 'region', 'regional analysis', 'geography', 'location'],
                            'overview': ['overview', 'summary', 'dashboard', 'main'],
                            'trends': ['trends', 'trend', 'trending', 'pattern', 'patterns']
                        };
                        
                        console.log('🔍 Searching for bookmark in command:', cmd);
                        
                        for (const [bookmark, patterns] of Object.entries(bookmarkPatterns)) {
                            if (patterns.some(pattern => cmd.includes(pattern))) {
                                console.log('✅ Matched bookmark pattern:', bookmark, 'from patterns:', patterns);
                                const result = this.engine.switchBookmark(bookmark);
                                if (result) {
                                    const message = \`✅ Successfully switched to \${bookmark} bookmark\`;
                                    console.log(message);
                                    this.speakResponse(message);
                                    return message;
                                } else {
                                    const errorMessage = \`❌ Could not switch to \${bookmark} bookmark. Please try saying "Go to \${bookmark}" or check if the bookmark exists.\`;
                                    console.log(errorMessage);
                                    this.speakResponse(errorMessage);
                                    return errorMessage;
                                }
                            }
                        }
                        
                        // If no pattern matched, try direct name extraction
                        const directMatch = cmd.match(/(?:go to|switch to|show me|navigate to)\\s+(.+)/);
                        if (directMatch) {
                            const bookmarkName = directMatch[1].trim();
                            console.log('🎯 Trying direct bookmark name:', bookmarkName);
                            const result = this.engine.switchBookmark(bookmarkName);
                            if (result) {
                                const message = \`✅ Successfully switched to \${bookmarkName} bookmark\`;
                                this.speakResponse(message);
                                return message;
                            }
                        }
                        
                        const fallbackMessage = '❌ Bookmark not found. Try saying: "Go to Sales Focus", "Go to Customer Analytics", "Go to Product Performance", "Go to Regional Analysis", "Go to Overview", or "Go to Trends"';
                        this.speakResponse(fallbackMessage);
                        return fallbackMessage;
                    }
                    
                    // Enhanced filter commands
                    if (cmd.includes('filter') || cmd.includes('show')) {
                        // Region filters
                        const regions = ['north', 'south', 'europe', 'asia', 'africa', 'oceania', 'america'];
                        const region = regions.find(r => cmd.includes(r));
                        if (region) {
                            const result = this.engine.applyFilter('region', region);
                            const message = result ? \`✅ Applied region filter: \${region}\` : \`❌ Could not apply region filter: \${region}\`;
                            this.speakResponse(message);
                            return message;
                        }
                        
                        // Segment filters
                        if (cmd.includes('enterprise')) {
                            const result = this.engine.applyFilter('segment', 'enterprise');
                            const message = result ? '✅ Applied enterprise filter' : '❌ Could not apply enterprise filter';
                            this.speakResponse(message);
                            return message;
                        }
                        
                        // Revenue filters
                        if (cmd.includes('revenue') && cmd.includes('high')) {
                            const result = this.engine.applyFilter('revenue', 'high');
                            const message = result ? '✅ Applied high revenue filter' : '❌ Could not apply high revenue filter';
                            this.speakResponse(message);
                            return message;
                        }
                        
                        // Category filters
                        const categories = ['electronics', 'clothing', 'books', 'home', 'sports'];
                        const category = categories.find(c => cmd.includes(c));
                        if (category) {
                            const result = this.engine.applyFilter('category', category);
                            const message = result ? \`✅ Applied category filter: \${category}\` : \`❌ Could not apply category filter: \${category}\`;
                            this.speakResponse(message);
                            return message;
                        }
                    }
                    
                    // Search commands
                    if (cmd.includes('search') || cmd.includes('find')) {
                        const searchMatch = command.match(/(?:search|find)\\s+(?:for\\s+)?(.+)/i);
                        if (searchMatch) {
                            const result = this.engine.searchData(searchMatch[1]);
                            const message = result ? \`✅ Searching for: \${searchMatch[1]}\` : \`❌ Could not search for: \${searchMatch[1]}\`;
                            this.speakResponse(message);
                            return message;
                        }
                    }
                    
                    // Action commands
                    if (cmd.includes('refresh')) {
                        const result = this.engine.refreshData();
                        const message = result ? '✅ Dashboard refreshed' : '❌ Could not refresh dashboard';
                        this.speakResponse(message);
                        return message;
                    }
                    
                    if (cmd.includes('export')) {
                        const result = this.engine.exportData();
                        const message = result ? '✅ Exporting data...' : '❌ Could not export data';
                        this.speakResponse(message);
                        return message;
                    }
                    
                    if (cmd.includes('reset') || cmd.includes('clear')) {
                        const result = this.engine.resetFilters();
                        const message = result ? '✅ All filters cleared' : '❌ Could not clear filters';
                        this.speakResponse(message);
                        return message;
                    }
                    
                    const errorMessage = '❌ I didn\\'t understand that command. Please try: "Go to [bookmark name]", "Filter [type] [value]", "Search for [term]", "Refresh dashboard", or "Export data"';
                    this.speakResponse(errorMessage);
                    return errorMessage;
                }
                
                speakResponse(message) {
                    // Text-to-speech response
                    if ('speechSynthesis' in window) {
                        const utterance = new SpeechSynthesisUtterance(message.replace(/[✅❌🔍🎯]/g, ''));
                        utterance.rate = 0.8;
                        utterance.pitch = 1;
                        speechSynthesis.speak(utterance);
                    }
                }
            }
            
            // Universal Chatbot UI
            function createUniversalChatbot(detector, engine, processor) {
                // Remove existing chatbot
                const existing = document.getElementById('universal-powerbi-chatbot');
                if (existing) existing.remove();
                
                const chatbot = document.createElement('div');
                chatbot.id = 'universal-powerbi-chatbot';
                chatbot.style.cssText = \`
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    width: 400px;
                    height: 600px;
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.3);
                    border: 1px solid #e1e1e1;
                    z-index: 10000;
                    display: flex;
                    flex-direction: column;
                    font-family: 'Segoe UI', sans-serif;
                    transition: all 0.3s ease;
                \`;
                
                const featureMap = detector.detectDashboard();
                
                chatbot.innerHTML = \`
                    <div style="background: linear-gradient(135deg, #0078d4, #106ebe); color: white; padding: 15px 20px; border-radius: 12px 12px 0 0; display: flex; justify-content: space-between; align-items: center;">
                        <div style="display: flex; align-items: center; gap: 8px; font-weight: 600;">
                            <span style="font-size: 20px;">🤖</span>
                            <span>Power BI Assistant</span>
                            <span style="font-size: 11px; opacity: 0.8; background: rgba(255,255,255,0.2); padding: 2px 6px; border-radius: 10px;">v2.1</span>
                        </div>
                        <div style="display: flex; gap: 8px;">
                            <button id="speech-toggle" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 8px 10px; border-radius: 6px; cursor: pointer; font-size: 14px;" title="Voice Input">🎤</button>
                            <button onclick="toggleChatbot()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 8px 10px; border-radius: 6px; cursor: pointer; font-size: 14px;" title="Minimize">−</button>
                            <button onclick="closeChatbot()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 8px 10px; border-radius: 6px; cursor: pointer; font-size: 14px;" title="Close">×</button>
                        </div>
                    </div>
                    <div id="chatbot-messages" style="flex: 1; padding: 20px; overflow-y: auto; background: #f8f9fa;">
                        <div style="background: white; padding: 15px; border-radius: 12px; border: 1px solid #e1e1e1; margin-bottom: 15px; animation: slideIn 0.3s ease;">
                            👋 <strong>Hi Shikher! How may I help you with your selected dashboard/report?</strong><br><br>
                            I can help you navigate and control this dashboard using voice or text commands.<br><br>
                            <div style="background: #e3f2fd; padding: 10px; border-radius: 8px; margin: 10px 0;">
                                <strong>📊 Dashboard Type:</strong> \${featureMap.dashboardType}<br>
                                <strong>🔧 Available Features:</strong> \${featureMap.capabilities.join(', ')}<br><br>
                                <strong>🎯 Available Bookmarks:</strong><br>
                                • "Go to Sales Focus"<br>
                                • "Go to Customer Analytics"<br>
                                • "Go to Product Performance"<br>
                                • "Go to Regional Analysis"<br>
                                • "Go to Overview"<br>
                                • "Go to Trends"<br><br>
                                <strong>💡 Other commands:</strong><br>
                                • "Filter region [name]"<br>
                                • "Search for [term]"<br>
                                • "Refresh dashboard"<br>
                                • "Export data"
                            </div>
                            <small style="color: #666;">🎤 Click the microphone and speak your command!</small>
                        </div>
                    </div>
                    <div style="padding: 15px 20px; border-top: 1px solid #e1e1e1; display: flex; gap: 10px; background: white; border-radius: 0 0 12px 12px;">
                        <input type="text" id="chatbot-input" placeholder="Ask me anything about this dashboard..." style="flex: 1; padding: 12px 16px; border: 1px solid #d1d1d1; border-radius: 20px; outline: none; font-size: 14px;">
                        <button onclick="sendMessage()" style="background: #0078d4; color: white; border: none; padding: 12px 20px; border-radius: 20px; cursor: pointer; font-weight: 500;">Send</button>
                    </div>
                    <div style="padding: 8px 20px; background: #f1f1f1; font-size: 11px; color: #666; display: flex; justify-content: space-between; border-radius: 0 0 12px 12px;">
                        <span>Dashboard: \${featureMap.dashboardType}</span>
                        <span>Features: \${featureMap.capabilities.length} detected</span>
                    </div>
                \`;
                
                document.body.appendChild(chatbot);
                
                // Add message function
                window.addMessage = function(content, type = 'bot') {
                    const messagesContainer = document.getElementById('chatbot-messages');
                    const messageDiv = document.createElement('div');
                    
                    const styles = {
                        user: 'background: #0078d4; color: white; margin-left: auto; border-bottom-right-radius: 6px;',
                        bot: 'background: white; color: #333; border: 1px solid #e1e1e1; border-bottom-left-radius: 6px;',
                        system: 'background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; text-align: center; margin: 10px auto; font-size: 13px;',
                        error: 'background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;'
                    };
                    
                    messageDiv.style.cssText = \`
                        margin-bottom: 15px;
                        padding: 12px 16px;
                        border-radius: 18px;
                        max-width: 85%;
                        animation: slideIn 0.3s ease;
                        \${styles[type]}
                    \`;
                    
                    messageDiv.innerHTML = content;
                    messagesContainer.appendChild(messageDiv);
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                };
                
                // Send message function
                window.sendMessage = function() {
                    const input = document.getElementById('chatbot-input');
                    const message = input.value.trim();
                    
                    if (!message) return;
                    
                    addMessage(message, 'user');
                    input.value = '';
                    
                    console.log('🎯 Processing user command:', message);
                    
                    // Process command
                    const result = processor.processCommand(message);
                    if (result) {
                        addMessage(result, 'bot');
                        console.log('✅ Command processed successfully:', result);
                    } else {
                        const errorMsg = '❌ I didn\\'t understand that command. Please try using more specific language or check the examples above.';
                        addMessage(errorMsg, 'bot');
                        console.log('❌ Command not understood:', message);
                        
                        // Speak the error message
                        if ('speechSynthesis' in window) {
                            const utterance = new SpeechSynthesisUtterance('I didn\\'t understand that command. Please try again.');
                            speechSynthesis.speak(utterance);
                        }
                    }
                };
                
                // Toggle functions
                window.toggleChatbot = function() {
                    const chatbot = document.getElementById('universal-powerbi-chatbot');
                    if (chatbot.style.height === '60px') {
                        chatbot.style.height = '600px';
                        chatbot.style.overflow = 'visible';
                    } else {
                        chatbot.style.height = '60px';
                        chatbot.style.overflow = 'hidden';
                    }
                };
                
                window.closeChatbot = function() {
                    const chatbot = document.getElementById('universal-powerbi-chatbot');
                    chatbot.style.transform = 'translateY(100%)';
                    chatbot.style.opacity = '0';
                    setTimeout(() => chatbot.remove(), 300);
                };
                
                // Event listeners
                document.getElementById('chatbot-input').addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        sendMessage();
                    }
                });
                
                // Speech recognition
                let recognition = null;
                if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
                    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
                    recognition = new SpeechRecognition();
                    recognition.continuous = false;
                    recognition.interimResults = false;
                    recognition.lang = 'en-US';
                    
                    recognition.onresult = function(event) {
                        const transcript = event.results[0][0].transcript;
                        console.log('🎤 Speech recognized:', transcript);
                        document.getElementById('chatbot-input').value = transcript;
                        
                        // Add the speech input as a user message
                        addMessage('🎤 ' + transcript, 'user');
                        
                        // Process the command immediately
                        const result = processor.processCommand(transcript);
                        if (result) {
                            addMessage(result, 'bot');
                            console.log('✅ Voice command processed:', result);
                        } else {
                            const errorMsg = '❌ I didn\\'t understand that voice command. Please try again.';
                            addMessage(errorMsg, 'bot');
                            
                            // Speak feedback
                            if ('speechSynthesis' in window) {
                                const utterance = new SpeechSynthesisUtterance('I didn\\'t understand that command. Please try again.');
                                speechSynthesis.speak(utterance);
                            }
                        }
                        
                        // Clear the input and reset speech button
                        document.getElementById('chatbot-input').value = '';
                        const button = document.getElementById('speech-toggle');
                        button.classList.remove('active');
                        button.style.background = 'rgba(255,255,255,0.2)';
                    };
                    
                    recognition.onerror = function(event) {
                        console.warn('Speech recognition error:', event.error);
                        addMessage('❌ Speech recognition error. Please try typing instead.', 'bot');
                    };
                }
                
                document.getElementById('speech-toggle').addEventListener('click', function() {
                    if (!recognition) {
                        addMessage('❌ Speech recognition not supported in this browser.', 'bot');
                        return;
                    }
                    
                    const button = this;
                    if (button.classList.contains('active')) {
                        recognition.stop();
                        button.classList.remove('active');
                        button.style.background = 'rgba(255,255,255,0.2)';
                    } else {
                        recognition.start();
                        button.classList.add('active');
                        button.style.background = '#ff4444';
                        addMessage('🎤 Listening... Speak your command now.', 'system');
                    }
                });
                
                // Add CSS animation
                const style = document.createElement('style');
                style.textContent = \`
                    @keyframes slideIn {
                        from { opacity: 0; transform: translateY(10px); }
                        to { opacity: 1; transform: translateY(0); }
                    }
                \`;
                document.head.appendChild(style);
                
                console.log('✅ Universal Power BI Chatbot created successfully!');
            }
            
            // Initialize the complete system
            function initializeUniversalChatbot() {
                try {
                    console.log('🚀 Initializing Universal Power BI Chatbot...');
                    
                    const detector = new UniversalDetector();
                    const featureMap = detector.detectDashboard();
                    const engine = new UniversalEngine(featureMap);
                    const processor = new CommandProcessor(engine);
                    
                    console.log('📊 Dashboard detected:', featureMap.dashboardType);
                    console.log('🔧 Features found:', featureMap.capabilities);
                    
                    createUniversalChatbot(detector, engine, processor);
                    
                    // Make globally available
                    window.universalPowerBIChatbot = { detector, engine, processor };
                    
                    console.log('✅ Universal Power BI Chatbot initialized successfully!');
                    
                } catch (error) {
                    console.error('❌ Universal Power BI Chatbot initialization failed:', error);
                }
            }
            
            // Auto-initialize
            initializeUniversalChatbot();
        `;

        document.head.appendChild(script);
        console.log('✅ Universal Power BI Chatbot System Injected Successfully');
    }

    // Monitor page changes and reinitialize when needed
    function initializePageMonitoring() {
        // Monitor for Power BI navigation changes
        let currentURL = window.location.href;
        let currentTitle = document.title;

        const observer = new MutationObserver((mutations) => {
            const newURL = window.location.href;
            const newTitle = document.title;

            // Check if page changed significantly
            if (newURL !== currentURL || newTitle !== currentTitle) {
                console.log('📄 Power BI page changed, reinitializing chatbot...');
                currentURL = newURL;
                currentTitle = newTitle;

                // Delay to allow page to load
                setTimeout(() => {
                    if (window.universalPowerBIChatbot) {
                        // Reinitialize the chatbot for the new page
                        initializeUniversalChatbot();
                    }
                }, 1500);
            }

            // Check for new dashboard elements
            mutations.forEach(mutation => {
                if (mutation.addedNodes.length > 0) {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === 1) { // Element node
                            // Check if significant dashboard elements were added
                            if (node.querySelector && (
                                node.querySelector('.visual') ||
                                node.querySelector('.slicer') ||
                                node.querySelector('[data-automation-id*="visual"]') ||
                                node.classList.contains('powerbi-visual')
                            )) {
                                console.log('🔄 New dashboard elements detected, updating chatbot...');
                                setTimeout(() => {
                                    if (window.universalPowerBIChatbot) {
                                        // Update the chatbot's understanding of the page
                                        window.universalPowerBIChatbot.detector.detectDashboard();
                                    }
                                }, 500);
                            }
                        }
                    });
                }
            });
        });

        // Start observing
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: false
        });
    }

    // Basic fallback implementation if universal system fails
    function initializeBasicFallback() {
        console.log('🔄 Initializing basic fallback chatbot...');

        // Create a minimal chatbot interface
        const fallbackChatbot = document.createElement('div');
        fallbackChatbot.id = 'fallback-powerbi-chatbot';
        fallbackChatbot.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 350px;
            height: 500px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
            border: 1px solid #e1e1e1;
            z-index: 10000;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            flex-direction: column;
        `;

        fallbackChatbot.innerHTML = `
            <div style="background: linear-gradient(135deg, #dc3545, #c82333); color: white; padding: 15px; border-radius: 12px 12px 0 0; font-weight: 600;">
                ⚠️ Basic Power BI Assistant
            </div>
            <div style="flex: 1; padding: 20px; overflow-y: auto; background: #f8f9fa;">
                <div style="background: white; padding: 15px; border-radius: 12px; border: 1px solid #e1e1e1;">
                    <p><strong>System Status:</strong> Universal chatbot system could not load.</p>
                    <p><strong>Basic Commands Available:</strong></p>
                    <ul style="margin: 10px 0; padding-left: 20px; font-size: 14px;">
                        <li>Search functionality</li>
                        <li>Basic filter detection</li>
                        <li>Element clicking</li>
                    </ul>
                    <p style="font-size: 13px; color: #666; margin-top: 15px;">
                        <em>Please reload the page to retry the full system.</em>
                    </p>
                </div>
            </div>
            <div style="padding: 15px; border-top: 1px solid #e1e1e1; background: white; border-radius: 0 0 12px 12px;">
                <button onclick="this.parentElement.parentElement.remove()" 
                        style="width: 100%; padding: 10px; background: #dc3545; color: white; border: none; border-radius: 6px; cursor: pointer;">
                    Close
                </button>
            </div>
        `;

        document.body.appendChild(fallbackChatbot);

        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (fallbackChatbot.parentElement) {
                fallbackChatbot.remove();
            }
        }, 10000);
    }

    // Detect if we're on a Power BI page
    function isPowerBIPage() {
        return (
            window.location.href.includes('powerbi') ||
            document.querySelector('[data-automation-id*="powerbi"]') ||
            document.querySelector('.powerbi-visual') ||
            document.querySelector('.visual-container') ||
            document.title.toLowerCase().includes('power bi') ||
            document.querySelector('.slicer') ||
            window.powerBIComplexDashboard ||
            window.powerBISimulator
        );
    }

    // Wait for page to be ready
    function waitForPageReady() {
        return new Promise((resolve) => {
            if (document.readyState === 'complete') {
                resolve();
            } else {
                window.addEventListener('load', resolve);
            }
        });
    }

    // Main initialization
    async function initialize() {
        try {
            // Wait for page to be ready
            await waitForPageReady();

            // Small delay to ensure all resources are loaded
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Check if this is a Power BI page
            if (!isPowerBIPage()) {
                console.log('ℹ️ Not a Power BI page, skipping chatbot initialization');
                return;
            }

            console.log('✅ Power BI page detected, initializing Universal Chatbot...');

            // Load the universal chatbot system
            loadUniversalChatbotSystem();

        } catch (error) {
            console.error('❌ Universal Power BI Chatbot initialization failed:', error);
            initializeBasicFallback();
        }
    }

    // Start initialization
    initialize();

    // Make utilities globally available for debugging
    window.powerBIChatbotUtils = {
        reinitialize: () => {
            console.log('🔄 Manually reinitializing Universal Power BI Chatbot...');
            if (window.universalPowerBIChatbot) {
                window.universalPowerBIChatbot.close();
            }
            setTimeout(loadUniversalChatbotSystem, 500);
        },

        getStatus: () => {
            if (window.universalPowerBIChatbot) {
                return window.universalPowerBIChatbot.getDashboardInfo();
            }
            return { status: 'Not initialized' };
        },

        executeCommand: (command) => {
            if (window.universalPowerBIChatbot) {
                return window.universalPowerBIChatbot.executeCommand(command);
            }
            console.warn('Universal chatbot not available');
            return false;
        }
    };

    console.log('🎯 Universal Power BI Chatbot Content Script Loaded');
    console.log('💡 Use window.powerBIChatbotUtils for debugging');

})();
