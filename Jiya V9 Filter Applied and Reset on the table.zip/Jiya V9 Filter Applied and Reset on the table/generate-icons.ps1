Add-Type -AssemblyName System.Drawing

function Create-Icon([int]$size, [string]$filename) {
    $bitmap = New-Object System.Drawing.Bitmap($size, $size)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    
    # Background circle with gradient
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        [System.Drawing.Point]::new(0, 0),
        [System.Drawing.Point]::new($size, $size),
        [System.Drawing.Color]::FromArgb(102, 126, 234),
        [System.Drawing.Color]::FromArgb(118, 75, 162)
    )
    $graphics.FillEllipse($brush, 2, 2, $size-4, $size-4)
    
    # White border
    $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::White, [Math]::Max(1, $size/32))
    $graphics.DrawEllipse($pen, 2, 2, $size-4, $size-4)
    
    # Robot head (white rectangle)
    $headSize = [int]($size * 0.3)
    $headX = [int]($size/2 - $headSize/2)
    $headY = [int]($size * 0.28)
    $whiteBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $graphics.FillRectangle($whiteBrush, $headX, $headY, $headSize, [int]($headSize * 0.8))
    
    # Eyes (black circles)
    $eyeSize = [Math]::Max(2, $size/20)
    $blackBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Black)
    $graphics.FillEllipse($blackBrush, [int]($headX + $headSize * 0.25 - $eyeSize/2), [int]($headY + $headSize * 0.3 - $eyeSize/2), $eyeSize, $eyeSize)
    $graphics.FillEllipse($blackBrush, [int]($headX + $headSize * 0.75 - $eyeSize/2), [int]($headY + $headSize * 0.3 - $eyeSize/2), $eyeSize, $eyeSize)
    
    # Mouth (black rectangle)
    $mouthHeight = [Math]::Max(1, $size/64)
    $graphics.FillRectangle($blackBrush, [int]($headX + $headSize * 0.3), [int]($headY + $headSize * 0.6), [int]($headSize * 0.4), $mouthHeight)
    
    # Chat indicator for larger icons
    if ($size -ge 32) {
        $chatSize = [int]($size * 0.12)
        $chatX = [int]($size * 0.75 - $chatSize)
        $chatY = [int]($size * 0.75 - $chatSize)
        $graphics.FillEllipse($whiteBrush, $chatX, $chatY, $chatSize * 2, $chatSize * 2)
        $graphics.DrawEllipse([System.Drawing.Pens]::Black, $chatX, $chatY, $chatSize * 2, $chatSize * 2)
    }
    
    $bitmap.Save($filename, [System.Drawing.Imaging.ImageFormat]::Png)
    $graphics.Dispose()
    $bitmap.Dispose()
    $brush.Dispose()
    $pen.Dispose()
    $whiteBrush.Dispose()
    $blackBrush.Dispose()
}

# Generate all icon sizes
Create-Icon 16 'icon16.png'
Create-Icon 32 'icon32.png'
Create-Icon 48 'icon48.png'
Create-Icon 128 'icon128.png'

Write-Host "Icons generated successfully!"
Write-Host "Files created: icon16.png, icon32.png, icon48.png, icon128.png"
