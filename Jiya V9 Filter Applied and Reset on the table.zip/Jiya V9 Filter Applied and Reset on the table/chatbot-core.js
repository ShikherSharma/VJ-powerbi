// Universal Power BI Chatbot - Core Functionality
// Voice-enabled, mobile-optimized chatbot for Power BI dashboards

// Global chatbot functions
let isListening = false;
let recognition = null;

// Initialize speech recognition
function initializeSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = function () {
            isListening = true;
            console.log('🎤 Voice recognition started');
            const speechBtn = document.getElementById('speech-toggle');
            if (speechBtn) {
                speechBtn.style.background = '#ff4444';
                speechBtn.textContent = '🔴';
            }
        };

        recognition.onend = function () {
            isListening = false;
            console.log('🎤 Voice recognition ended');
            const speechBtn = document.getElementById('speech-toggle');
            if (speechBtn) {
                speechBtn.style.background = '#0078d4';
                speechBtn.textContent = '🎤';
            }
        };

        recognition.onresult = function (event) {
            const transcript = event.results[0][0].transcript;
            console.log('🗣️ Voice input received:', transcript);

            if (window.addMessage) {
                window.addMessage(transcript, 'user');
            }

            processCommand(transcript);
        };

        recognition.onerror = function (event) {
            console.error('Speech recognition error:', event.error);
            isListening = false;
        };
    }
}

// Toggle speech recognition
function toggleSpeechRecognition() {
    if (!recognition) {
        initializeSpeechRecognition();
    }

    if (isListening) {
        recognition.stop();
    } else {
        recognition.start();
    }
}

// Make speech functions globally accessible
window.toggleSpeechRecognition = toggleSpeechRecognition;

// Text-to-speech function
function speakResponse(text) {
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 0.8;
        speechSynthesis.speak(utterance);
    }
}

// Make functions globally accessible
window.speakResponse = speakResponse;

// Send message function
function sendMessage() {
    const input = document.getElementById('chatbot-input');
    const message = input.value.trim();

    if (!message) return;

    addMessage(message, 'user');
    input.value = '';

    // Process the command
    processCommand(message);
}

// Make sendMessage globally accessible
window.sendMessage = sendMessage;

// Add message to chat
function addMessage(content, type = 'bot') {
    const messagesContainer = document.getElementById('chatbot-messages');
    if (!messagesContainer) return;

    const messageDiv = document.createElement('div');

    const styles = {
        user: 'background: #0078d4; color: white; margin-left: auto; border-bottom-right-radius: 6px;',
        bot: 'background: white; color: #333; border: 1px solid #e1e1e1; border-bottom-left-radius: 6px;',
        system: 'background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; text-align: center; margin: 10px auto; font-size: 13px;',
        error: 'background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;'
    };

    messageDiv.style.cssText = 'margin-bottom: 15px; padding: 12px 16px; border-radius: 18px; max-width: 85%; animation: slideIn 0.3s ease; ' + styles[type];

    // Convert newlines to proper HTML
    const formattedContent = content.replace(/\\n/g, '<br>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    messageDiv.innerHTML = formattedContent;
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Make addMessage globally accessible for intelligent summarizer
window.addMessage = addMessage;

// Command processing function
function processCommand(command) {
    console.log('🧠 Processing command:', command);

    const lowercaseCommand = command.toLowerCase().trim();
    let result = false;
    let responseMessage = '';

    // PRIORITY 1: Filter commands (must be checked first to avoid bookmark conflicts)
    if (lowercaseCommand.includes('filter') || lowercaseCommand.includes('equals') || lowercaseCommand.includes('=') ||
        (lowercaseCommand.includes('show') && (lowercaseCommand.includes('equals') || lowercaseCommand.includes('where') ||
            lowercaseCommand.includes('north') || lowercaseCommand.includes('south') || lowercaseCommand.includes('europe') ||
            lowercaseCommand.includes('asia') || lowercaseCommand.includes('africa') || lowercaseCommand.includes('oceania') ||
            lowercaseCommand.includes('electronics') || lowercaseCommand.includes('clothing') || lowercaseCommand.includes('books') ||
            lowercaseCommand.includes('enterprise') || lowercaseCommand.includes('consumer') || lowercaseCommand.includes('government'))) ||
        lowercaseCommand.includes('display') || lowercaseCommand.includes('apply') || lowercaseCommand.includes('find') || lowercaseCommand.includes('search')) {

        let filterApplied = false;
        let filterMessages = [];

        // Region filtering with comprehensive global mapping
        if (lowercaseCommand.includes('region') || lowercaseCommand.includes('location') || lowercaseCommand.includes('geographic') || lowercaseCommand.includes('territory')) {
            const regionMappings = {
                'north': ['north', 'north america', 'northern', 'usa', 'united states', 'canada', 'america', 'us', 'na'],
                'south': ['south', 'south america', 'southern', 'brazil', 'argentina', 'chile', 'peru', 'latin', 'sa'],
                'europe': ['europe', 'european', 'eu', 'germany', 'france', 'uk', 'britain', 'spain', 'italy', 'netherlands', 'emea'],
                'asia': ['asia', 'asian', 'asia pacific', 'china', 'japan', 'india', 'singapore', 'korea', 'apac', 'pacific'],
                'africa': ['africa', 'african', 'nigeria', 'south africa', 'egypt', 'kenya'],
                'oceania': ['oceania', 'australia', 'new zealand', 'pacific islands', 'aussie']
            };

            for (const regionKey in regionMappings) {
                const patterns = regionMappings[regionKey];
                let found = false;
                for (let i = 0; i < patterns.length; i++) {
                    if (lowercaseCommand.includes(patterns[i])) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    result = window.universalPowerBITestDashboard.applyFilter('region', regionKey);
                    if (result) {
                        filterApplied = true;
                        filterMessages.push('Region: ' + regionKey.charAt(0).toUpperCase() + regionKey.slice(1));
                    }
                    break;
                }
            }
        }

        // Continue with other filter processing...
        // (Rest of the processCommand function would go here)

        if (filterApplied) {
            responseMessage = '✅ Applied filters: ' + filterMessages.join(', ') + '. Dashboard updated!';
            addMessage(responseMessage, 'bot');
            speakResponse('Filters applied successfully. Dashboard has been updated.');
            return;
        }
    }

    // Navigation commands
    if (lowercaseCommand.includes('go to') || lowercaseCommand.includes('open') || lowercaseCommand.includes('show') || lowercaseCommand.includes('navigate')) {
        const bookmarkMappings = {
            'sales-focus': ['sales', 'sales focus', 'revenue', 'selling'],
            'customer-analytics': ['customer', 'customers', 'analytics', 'client'],
            'product-performance': ['product', 'products', 'performance', 'items'],
            'regional-analysis': ['regional', 'region', 'geographic', 'territory'],
            'overview': ['overview', 'dashboard', 'main', 'home', 'summary'],
            'trends': ['trends', 'trending', 'patterns', 'forecast']
        };

        for (const bookmark in bookmarkMappings) {
            const patterns = bookmarkMappings[bookmark];
            if (patterns.some(pattern => lowercaseCommand.includes(pattern))) {
                result = window.universalPowerBITestDashboard.navigateToBookmark(bookmark);
                if (result) {
                    responseMessage = `📊 Navigated to ${bookmark.replace('-', ' ')} view`;
                    addMessage(responseMessage, 'bot');
                    speakResponse(`Switched to ${bookmark.replace('-', ' ')} view`);
                    return;
                }
                break;
            }
        }
    }

    // Action commands
    if (lowercaseCommand.includes('refresh') || lowercaseCommand.includes('reload') || lowercaseCommand.includes('update')) {
        result = window.universalPowerBITestDashboard.refreshData();
        if (result) {
            responseMessage = '🔄 Dashboard refreshed successfully!';
            addMessage(responseMessage, 'bot');
            speakResponse('Dashboard has been refreshed');
            return;
        }
    }

    if (lowercaseCommand.includes('clear') || lowercaseCommand.includes('reset') || lowercaseCommand.includes('remove filters')) {
        result = window.universalPowerBITestDashboard.clearFilters();
        if (result) {
            responseMessage = '🧹 All filters cleared!';
            addMessage(responseMessage, 'bot');
            speakResponse('All filters have been cleared');
            return;
        }
    }

    // Help commands
    if (lowercaseCommand.includes('help') || lowercaseCommand.includes('what can you do') || lowercaseCommand.includes('commands')) {
        addMessage('🤖 I can help you with:\\n\\n📊 **Navigation**: "Open Sales Focus tab", "Go to Customer Analytics"\\n🔍 **Filtering**: "Show North America", "Filter Electronics"\\n🔎 **Search**: "Find customers", "Search products"\\n📈 **Actions**: "Refresh dashboard", "Export data"\\n🎤 **Voice**: Just speak your command!', 'bot');
        speakResponse('I can help you navigate, filter data, and perform various dashboard actions. You can speak or type your commands.');
        return;
    }

    // Default response with intelligent suggestions
    let suggestion = '';
    let spokenResponse = '';

    if (lowercaseCommand.includes('data') || lowercaseCommand.includes('information')) {
        suggestion = '📊 I can help you access different data views. Try: "Show me sales data" or "Open customer information"';
        spokenResponse = 'I can help you access different data views. Try asking for sales data or customer information.';
    } else if (lowercaseCommand.includes('report') || lowercaseCommand.includes('dashboard')) {
        suggestion = '📈 For reports and dashboards, try: "Go to Overview" or "Show me the main dashboard"';
        spokenResponse = 'For reports and dashboards, try asking to go to Overview or show the main dashboard.';
    } else if (lowercaseCommand.includes('tab') || lowercaseCommand.includes('page') || lowercaseCommand.includes('section')) {
        suggestion = '📑 To navigate sections, try: "Open Sales tab", "Go to Customer page", or "Show Product section"';
        spokenResponse = 'To navigate sections, try asking to open a specific tab or go to a particular page.';
    } else {
        suggestion = '🤖 I understand you want: "' + command + '"\\n\\nLet me help you with available options:\\n\\n📊 **Bookmarks**: Sales Focus, Customer Analytics, Product Performance, Regional Analysis, Overview, Trends\\n🔍 **Filters**: Region, Category, Customer Segment, Revenue, Time Period\\n⚡ **Actions**: Refresh, Export, Search, Clear filters';
        spokenResponse = 'I understand your request. You can navigate to different bookmarks, apply filters, or perform dashboard actions. What would you like to do?';
    }

    addMessage(suggestion, 'bot');
    speakResponse(spokenResponse);
}

// Make processCommand globally accessible
window.processCommand = processCommand;

// KPI summarization function
function summarizeKPI(kpiType, kpiLabel, kpiValue) {
    console.log(`🧠 Summarizing KPI: ${kpiType} - ${kpiLabel}: ${kpiValue}`);

    if (window.intelligentSummarizer) {
        console.log('✅ intelligentSummarizer available');
        const kpiInsights = {
            revenue: {
                title: '💰 Total Revenue Analysis',
                insight: '$4.2M total revenue represents 24% year-over-year growth. North America leads with $1.8M (43%), followed by Europe at $950K (23%). Electronics category drives 38% of total revenue.',
                breakdown: {
                    'Current': '$4.2M (Q4 2024)',
                    'Growth': '+24% vs $3.4M (Q4 2023)',
                    'Top Region': 'North America ($1.8M)',
                    'Top Category': 'Electronics ($1.6M)',
                    'Trend': 'Accelerating growth in Q3-Q4'
                },
                recommendations: ['Focus on Asia Pacific expansion (+35% growth potential)', 'Increase electronics inventory for Q1', 'Diversify revenue streams in mature markets']
            },
            customers: {
                title: '👥 Active Customer Analysis',
                insight: '2,847 active customers with 89% retention rate. Enterprise segment provides highest value with avg $85K orders. New customer acquisition up 15% with strong digital channel growth.',
                breakdown: {
                    'Total Active': '2,847 customers',
                    'Retention Rate': '89% (industry avg: 76%)',
                    'New Acquisitions': '+184 customers/month',
                    'Avg Order Value': '$268 per order',
                    'Top Segment': 'Enterprise (1,247 customers)'
                },
                recommendations: ['Implement customer success program for SMB segment', 'Expand enterprise sales team', 'Launch referral program to boost acquisition']
            },
            orders: {
                title: '📦 Total Orders Analysis',
                insight: '15,632 total orders with average order value of $268. Peak ordering in Q4 with strong mobile commerce growth. Order fulfillment rate at 98.5% with avg delivery time 2.3 days.',
                breakdown: {
                    'Total Orders': '15,632 (YTD)',
                    'Average Value': '$268 per order',
                    'Peak Month': 'December (2,890 orders)',
                    'Fulfillment Rate': '98.5%',
                    'Mobile Orders': '42% of total'
                },
                recommendations: ['Optimize inventory for Q1 demand surge', 'Improve mobile checkout experience', 'Implement predictive ordering for enterprise clients']
            },
            growth: {
                title: '📈 Year-over-Year Growth Analysis',
                insight: '+24% YoY growth driven by digital transformation and market expansion. Strongest growth in Asia Pacific (+35%) and Health & Beauty category (+45%). Growth acceleration expected in 2025.',
                breakdown: {
                    'Overall Growth': '+24% YoY',
                    'Revenue Growth': '+$816K vs 2023',
                    'Customer Growth': '+18% new customers',
                    'Fastest Region': 'Asia Pacific (+35%)',
                    'Fastest Category': 'Health & Beauty (+45%)'
                },
                recommendations: ['Invest in Asia Pacific market expansion', 'Scale digital marketing efforts', 'Develop growth partnerships in emerging markets']
            }
        };

        const insight = kpiInsights[kpiType] || {
            title: '📊 ' + kpiLabel + ' Analysis',
            insight: 'Current ' + kpiLabel.toLowerCase() + ': ' + kpiValue + '. This metric shows the current performance state of your business.',
            breakdown: { 'Current Value': kpiValue },
            recommendations: ['Monitor trends over time', 'Compare with industry benchmarks', 'Set targets for improvement']
        };

        // Directly call the summarizer's displaySummary method
        if (window.intelligentSummarizer) {
            console.log('🎯 Displaying KPI summary for:', kpiType, insight);
            window.intelligentSummarizer.displaySummary(insight);
        } else {
            console.error('❌ intelligentSummarizer not available');
        }
    }
}

// Make summarizeKPI globally accessible
window.summarizeKPI = summarizeKPI;

// Create chatbot interface
function createTestChatbot() {
    // Check if chatbot already exists
    const existing = document.getElementById('test-powerbi-chatbot');
    if (existing) return;

    const chatbot = document.createElement('div');
    chatbot.id = 'test-powerbi-chatbot';
    chatbot.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 350px;
        height: 500px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        z-index: 1000;
        display: none;
        flex-direction: column;
        font-family: 'Segoe UI', sans-serif;
    `;

    chatbot.innerHTML = `
        <div style="background: #0078d4; color: white; padding: 15px 20px; border-radius: 12px 12px 0 0; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h3 style="margin: 0; font-size: 16px;">🤖 Power BI Assistant</h3>
                <p style="margin: 0; font-size: 12px; opacity: 0.9;">Ask me anything about your dashboard</p>
            </div>
            <button id="chatbot-close" style="background: none; border: none; color: white; font-size: 18px; cursor: pointer;">✕</button>
        </div>
        <div id="chatbot-messages" style="flex: 1; padding: 15px; overflow-y: auto; background: #f8f9fa;"></div>
        <div style="padding: 15px; border-top: 1px solid #e1e1e1; display: flex; gap: 10px; align-items: center;">
            <input type="text" id="chatbot-input" placeholder="Ask me anything about this dashboard..." style="flex: 1; padding: 12px 16px; border: 1px solid #d1d1d1; border-radius: 20px; outline: none; font-size: 14px;">
            <button id="chatbot-send" style="background: #0078d4; color: white; border: none; padding: 12px 20px; border-radius: 20px; cursor: pointer; font-weight: 500;">Send</button>
            <button id="speech-toggle" style="background: #0078d4; color: white; border: none; padding: 12px; border-radius: 50%; cursor: pointer; font-size: 16px;">🎤</button>
        </div>
    `;

    // Add event listeners after creating the chatbot
    document.body.appendChild(chatbot);

    // Add event listeners
    document.getElementById('chatbot-close').addEventListener('click', function () {
        toggleChatbot();
    });

    document.getElementById('chatbot-send').addEventListener('click', function () {
        sendMessage();
    });

    document.getElementById('speech-toggle').addEventListener('click', function () {
        toggleSpeechRecognition();
    });

    // Add enter key handler for input
    document.getElementById('chatbot-input').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Add welcome message
    setTimeout(() => {
        if (window.addMessage) {
            addMessage('👋 Hi! I\'m your Power BI assistant. Try commands like "Show North America" or "Go to Sales Focus". You can also click KPI cards for intelligent insights!', 'bot');

            if (window.speakResponse) {
                speakResponse('Hi! I am your Power BI assistant. How can I help you today?');
            }
        }
    }, 500);
}

// Initialize chatbot when DOM is ready
document.addEventListener('DOMContentLoaded', function () {
    setTimeout(() => {
        createTestChatbot();
        console.log('✅ Chatbot created successfully');
    }, 1000);
});
