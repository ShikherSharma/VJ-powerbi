/*
====================================================================
ENHANCED POWER BI CHATBOT - CLIENT SPECIFIC SOLUTION
====================================================================
Purpose: Intelligent chatbot for specific Power BI app with voice commands
Target URL: https://app.powerbi.com/groups/me/apps/0201219b-480c-4bbc-bad5-2d47df08f957
Features: User greeting, report navigation, filtering, bookmarks
====================================================================
*/

class EnhancedPowerBIChatbot {
    constructor() {
        this.config = {
            targetAppId: '0201219b-480c-4bbc-bad5-2d47df08f957',
            userName: null,
            reports: new Map(),
            pages: new Map(),
            currentReport: null,
            currentPage: null,
            isListening: false,
            speechRecognition: null,
            chatbotElement: null
        };
        
        this.initialize();
    }

    async initialize() {
        console.log('🚀 Enhanced Power BI Chatbot initializing...');
        
        // Check if we're on the target app URL
        if (!this.isTargetApp()) {
            console.log('❌ Not on target Power BI app URL');
            return;
        }

        console.log('✅ Target Power BI app detected');
        
        // Wait for Power BI to load
        await this.waitForPowerBILoad();
        
        // Get user information
        await this.getUserInfo();
        
        // Scan for reports and pages
        await this.scanReportsAndPages();
        
        // Create chatbot UI
        this.createChatbotUI();
        
        // Initialize speech recognition
        this.initializeSpeechRecognition();
        
        // Greet user
        this.greetUser();
        
        console.log('✅ Enhanced Power BI Chatbot ready!');
    }

    isTargetApp() {
        const currentUrl = window.location.href;
        return currentUrl.includes(this.config.targetAppId) || 
               currentUrl.includes('app.powerbi.com/groups/me/apps');
    }

    async waitForPowerBILoad() {
        console.log('⏳ Waiting for Power BI to load...');
        
        return new Promise((resolve) => {
            const checkLoaded = () => {
                // Check for Power BI specific elements
                const powerBILoaded = document.querySelector('.powerbi-embed, .visual-container, iframe[src*="powerbi"], .exploration-container') ||
                                    document.querySelector('[data-automation-id], .visual, .slicer') ||
                                    window.powerbi || 
                                    document.querySelector('.report-container, .dashboard-container');
                
                if (powerBILoaded) {
                    console.log('✅ Power BI loaded');
                    setTimeout(resolve, 2000); // Extra time for full loading
                } else {
                    setTimeout checkLoaded, 1000);
                }
            };
            checkLoaded();
        });
    }

    async getUserInfo() {
        console.log('👤 Getting user information...');
        
        // Try multiple methods to get user name
        let userName = null;
        
        // Method 1: Check for user display element
        const userDisplays = document.querySelectorAll(
            '.user-name, .username, .display-name, [data-automation-id*="user"], .account-name, .profile-name'
        );
        
        for (const element of userDisplays) {
            const text = element.textContent.trim();
            if (text && text.length > 2 && !text.toLowerCase().includes('menu')) {
                userName = text;
                break;
            }
        }
        
        // Method 2: Check URL or page title for user info
        if (!userName) {
            const urlParams = new URLSearchParams(window.location.search);
            userName = urlParams.get('user') || urlParams.get('name');
        }
        
        // Method 3: Check local storage or session storage
        if (!userName) {
            try {
                const userData = localStorage.getItem('powerbi-user') || 
                                sessionStorage.getItem('user-info') ||
                                localStorage.getItem('msal.account.keys');
                if (userData) {
                    const parsed = JSON.parse(userData);
                    userName = parsed.name || parsed.displayName || parsed.username;
                }
            } catch (e) {
                console.log('Could not parse user data from storage');
            }
        }
        
        // Method 4: Extract from page elements
        if (!userName) {
            const titleElement = document.querySelector('title');
            if (titleElement && titleElement.textContent.includes('-')) {
                const parts = titleElement.textContent.split('-');
                userName = parts[parts.length - 1].trim();
            }
        }
        
        // Fallback
        this.config.userName = userName || 'Power BI User';
        console.log('👤 User identified as:', this.config.userName);
    }

    async scanReportsAndPages() {
        console.log('📊 Scanning for reports and pages...');
        
        // Wait a bit more for content to load
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        // Method 1: Scan navigation elements
        this.scanNavigationElements();
        
        // Method 2: Scan iframes and embedded content
        this.scanEmbeddedContent();
        
        // Method 3: Scan for Power BI specific elements
        this.scanPowerBIElements();
        
        console.log('📊 Scan complete. Found:', {
            reports: this.config.reports.size,
            pages: this.config.pages.size
        });
    }

    scanNavigationElements() {
        // Look for tabs, navigation items, menu items
        const navSelectors = [
            '.nav-item', '.tab-item', '.menu-item', '.page-item',
            '[role="tab"]', '[role="menuitem"]', '[data-automation-id*="tab"]',
            '.powerbi-tab', '.report-tab', '.page-tab', '.navigation-item'
        ];
        
        navSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach((element, index) => {
                const text = element.textContent.trim();
                if (text && text.length > 0) {
                    // Determine if it's a report or page
                    if (this.isReportElement(element, text)) {
                        this.config.reports.set(text, {
                            element: element,
                            name: text,
                            id: `report_${index}`,
                            type: 'report'
                        });
                    } else if (this.isPageElement(element, text)) {
                        this.config.pages.set(text, {
                            element: element,
                            name: text,
                            id: `page_${index}`,
                            type: 'page'
                        });
                    }
                }
            });
        });
    }

    scanEmbeddedContent() {
        // Look for iframes and embedded reports
        const iframes = document.querySelectorAll('iframe');
        iframes.forEach((iframe, index) => {
            const src = iframe.src;
            const title = iframe.title || iframe.getAttribute('aria-label') || `Report ${index + 1}`;
            
            if (src && src.includes('powerbi.com')) {
                this.config.reports.set(title, {
                    element: iframe,
                    name: title,
                    id: `iframe_report_${index}`,
                    type: 'embedded-report',
                    src: src
                });
            }
        });
        
        // Look for embedded containers
        const containers = document.querySelectorAll('.visual-container, .report-container, .dashboard-container');
        containers.forEach((container, index) => {
            const label = container.getAttribute('aria-label') || 
                         container.getAttribute('data-automation-id') ||
                         `Container ${index + 1}`;
            
            this.config.reports.set(label, {
                element: container,
                name: label,
                id: `container_${index}`,
                type: 'container'
            });
        });
    }

    scanPowerBIElements() {
        // Look for Power BI specific selectors
        const powerBISelectors = [
            '.slicer', '.visual', '.filter-pane', '.bookmark',
            '[data-automation-id]', '.powerbi-visual', '.exploration-container'
        ];
        
        powerBISelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach((element, index) => {
                const automationId = element.getAttribute('data-automation-id');
                const ariaLabel = element.getAttribute('aria-label');
                const text = element.textContent.trim();
                
                const identifier = automationId || ariaLabel || text || `Element ${index + 1}`;
                
                if (identifier && !this.config.pages.has(identifier) && !this.config.reports.has(identifier)) {
                    this.config.pages.set(identifier, {
                        element: element,
                        name: identifier,
                        id: `powerbi_${index}`,
                        type: 'powerbi-element'
                    });
                }
            });
        });
    }

    isReportElement(element, text) {
        const reportKeywords = ['report', 'dashboard', 'analysis', 'overview', 'summary'];
        const textLower = text.toLowerCase();
        return reportKeywords.some(keyword => textLower.includes(keyword)) ||
               element.closest('.report-container, .dashboard-container') !== null;
    }

    isPageElement(element, text) {
        const pageKeywords = ['page', 'tab', 'view', 'section', 'sheet'];
        const textLower = text.toLowerCase();
        return pageKeywords.some(keyword => textLower.includes(keyword)) ||
               element.closest('.page-container, .tab-container') !== null ||
               element.getAttribute('role') === 'tab';
    }

    createChatbotUI() {
        console.log('🎨 Creating chatbot UI...');
        
        // Remove existing chatbot if any
        const existing = document.getElementById('enhanced-powerbi-chatbot');
        if (existing) existing.remove();
        
        // Create chatbot container
        const chatbotHTML = `
            <div id="enhanced-powerbi-chatbot" class="chatbot-container">
                <div class="chatbot-header">
                    <div class="chatbot-title">
                        <span class="chatbot-icon">🤖</span>
                        Power BI Assistant
                    </div>
                    <div class="chatbot-controls">
                        <button id="chatbot-mic" class="mic-button" title="Voice Commands">🎤</button>
                        <button id="chatbot-minimize" class="minimize-button" title="Minimize">−</button>
                        <button id="chatbot-close" class="close-button" title="Close">×</button>
                    </div>
                </div>
                <div class="chatbot-messages" id="chatbot-messages">
                    <div class="message bot-message">
                        <div class="message-content">
                            <span class="loading-dots">Initializing...</span>
                        </div>
                        <div class="message-time">${new Date().toLocaleTimeString()}</div>
                    </div>
                </div>
                <div class="chatbot-input-area">
                    <input type="text" id="chatbot-input" placeholder="Ask about reports, pages, or say a command..." />
                    <button id="chatbot-send" class="send-button">📤</button>
                </div>
                <div class="chatbot-status" id="chatbot-status">
                    Ready • Found ${this.config.reports.size} reports, ${this.config.pages.size} pages
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', chatbotHTML);
        this.chatbotElement = document.getElementById('enhanced-powerbi-chatbot');
        
        // Add event listeners
        this.addChatbotEventListeners();
        
        // Add styles
        this.addChatbotStyles();
        
        console.log('✅ Chatbot UI created');
    }

    addChatbotEventListeners() {
        // Send message
        const sendMessage = () => {
            const input = document.getElementById('chatbot-input');
            const message = input.value.trim();
            if (message) {
                this.addMessage(message, 'user');
                this.processCommand(message);
                input.value = '';
            }
        };
        
        document.getElementById('chatbot-send').addEventListener('click', sendMessage);
        document.getElementById('chatbot-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
        
        // Voice button
        document.getElementById('chatbot-mic').addEventListener('click', () => {
            this.toggleVoiceRecognition();
        });
        
        // Minimize button
        document.getElementById('chatbot-minimize').addEventListener('click', () => {
            this.chatbotElement.classList.toggle('minimized');
        });
        
        // Close button
        document.getElementById('chatbot-close').addEventListener('click', () => {
            this.chatbotElement.style.display = 'none';
        });
        
        // Make draggable
        this.makeDraggable();
    }

    makeDraggable() {
        const header = this.chatbotElement.querySelector('.chatbot-header');
        let isDragging = false;
        let startX, startY, startLeft, startTop;
        
        header.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            const rect = this.chatbotElement.getBoundingClientRect();
            startLeft = rect.left;
            startTop = rect.top;
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });
        
        const onMouseMove = (e) => {
            if (!isDragging) return;
            const deltaX = e.clientX - startX;
            const deltaY = e.clientY - startY;
            this.chatbotElement.style.left = (startLeft + deltaX) + 'px';
            this.chatbotElement.style.top = (startTop + deltaY) + 'px';
            this.chatbotElement.style.right = 'auto';
            this.chatbotElement.style.bottom = 'auto';
        };
        
        const onMouseUp = () => {
            isDragging = false;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
    }

    initializeSpeechRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.config.speechRecognition = new SpeechRecognition();
            
            this.config.speechRecognition.continuous = false;
            this.config.speechRecognition.interimResults = false;
            this.config.speechRecognition.lang = 'en-US';
            
            this.config.speechRecognition.onstart = () => {
                this.config.isListening = true;
                document.getElementById('chatbot-mic').style.backgroundColor = '#ff4444';
                document.getElementById('chatbot-status').textContent = 'Listening...';
            };
            
            this.config.speechRecognition.onend = () => {
                this.config.isListening = false;
                document.getElementById('chatbot-mic').style.backgroundColor = '#4CAF50';
                document.getElementById('chatbot-status').textContent = `Ready • Found ${this.config.reports.size} reports, ${this.config.pages.size} pages`;
            };
            
            this.config.speechRecognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                document.getElementById('chatbot-input').value = transcript;
                this.addMessage(transcript, 'user');
                this.processCommand(transcript);
            };
            
            this.config.speechRecognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                this.addMessage('Sorry, I couldn\'t hear that clearly. Please try again.', 'bot');
            };
            
            console.log('✅ Speech recognition initialized');
        } else {
            console.log('❌ Speech recognition not supported');
            document.getElementById('chatbot-mic').style.display = 'none';
        }
    }

    toggleVoiceRecognition() {
        if (!this.config.speechRecognition) return;
        
        if (this.config.isListening) {
            this.config.speechRecognition.stop();
        } else {
            this.config.speechRecognition.start();
        }
    }

    greetUser() {
        setTimeout(() => {
            const greeting = `Hello ${this.config.userName}! 👋\n\nI'm your Power BI Assistant. I can help you:\n\n🔍 Navigate to reports and pages\n📊 Filter data and apply bookmarks\n🎤 Use voice commands\n📈 Interact with visuals\n\nI found ${this.config.reports.size} reports and ${this.config.pages.size} pages in your app.\n\nTry saying: "Show me the sales report" or "Go to page 2"`;
            
            this.addMessage(greeting, 'bot');
        }, 1000);
    }

    addMessage(content, type) {
        const messagesContainer = document.getElementById('chatbot-messages');
        const messageElement = document.createElement('div');
        messageElement.className = `message ${type}-message`;
        
        messageElement.innerHTML = `
            <div class="message-content">${content.replace(/\n/g, '<br>')}</div>
            <div class="message-time">${new Date().toLocaleTimeString()}</div>
        `;
        
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    async processCommand(command) {
        console.log('🎯 Processing command:', command);
        
        const normalizedCommand = command.toLowerCase().trim();
        
        // Navigation commands
        if (this.isNavigationCommand(normalizedCommand)) {
            await this.handleNavigationCommand(normalizedCommand);
            return;
        }
        
        // Filter commands
        if (this.isFilterCommand(normalizedCommand)) {
            await this.handleFilterCommand(normalizedCommand);
            return;
        }
        
        // Bookmark commands
        if (this.isBookmarkCommand(normalizedCommand)) {
            await this.handleBookmarkCommand(normalizedCommand);
            return;
        }
        
        // Information commands
        if (this.isInformationCommand(normalizedCommand)) {
            await this.handleInformationCommand(normalizedCommand);
            return;
        }
        
        // Default response
        this.addMessage('I understand you want help with Power BI. Try commands like:\n\n• "Show me [report name]"\n• "Go to [page name]"\n• "Filter by [criteria]"\n• "Apply bookmark [name]"\n• "What reports are available?"', 'bot');
    }

    isNavigationCommand(command) {
        const navKeywords = ['show', 'open', 'go to', 'navigate', 'switch', 'display', 'view'];
        return navKeywords.some(keyword => command.includes(keyword));
    }

    async handleNavigationCommand(command) {
        console.log('🧭 Handling navigation command:', command);
        
        // Extract target from command
        const target = this.extractTargetFromCommand(command);
        
        // Try to find and navigate to report
        const report = this.findBestMatch(target, this.config.reports);
        if (report) {
            const success = await this.navigateToReport(report);
            if (success) {
                this.addMessage(`✅ Navigated to report: ${report.name}`, 'bot');
                this.config.currentReport = report;
                return;
            }
        }
        
        // Try to find and navigate to page
        const page = this.findBestMatch(target, this.config.pages);
        if (page) {
            const success = await this.navigateToPage(page);
            if (success) {
                this.addMessage(`✅ Navigated to page: ${page.name}`, 'bot');
                this.config.currentPage = page;
                return;
            }
        }
        
        this.addMessage(`❌ Could not find "${target}". Available options:\n\nReports: ${Array.from(this.config.reports.keys()).join(', ')}\n\nPages: ${Array.from(this.config.pages.keys()).join(', ')}`, 'bot');
    }

    extractTargetFromCommand(command) {
        // Remove common navigation words
        let target = command
            .replace(/show me|open|go to|navigate to|switch to|display|view/gi, '')
            .replace(/the |a |an /gi, '')
            .trim();
        
        return target || command;
    }

    findBestMatch(target, collection) {
        const targetLower = target.toLowerCase();
        
        // Exact match
        for (const [key, value] of collection) {
            if (key.toLowerCase() === targetLower) {
                return value;
            }
        }
        
        // Partial match
        for (const [key, value] of collection) {
            if (key.toLowerCase().includes(targetLower) || targetLower.includes(key.toLowerCase())) {
                return value;
            }
        }
        
        // Fuzzy match (simple)
        for (const [key, value] of collection) {
            const keyWords = key.toLowerCase().split(' ');
            const targetWords = targetLower.split(' ');
            
            if (keyWords.some(word => targetWords.some(targetWord => 
                word.includes(targetWord) || targetWord.includes(word)))) {
                return value;
            }
        }
        
        return null;
    }

    async navigateToReport(report) {
        console.log('📊 Navigating to report:', report);
        
        try {
            if (report.element) {
                // Scroll into view first
                report.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                
                await new Promise(resolve => setTimeout(resolve, 500));
                
                // Try multiple click methods
                if (report.element.click) {
                    report.element.click();
                } else {
                    report.element.dispatchEvent(new MouseEvent('click', { bubbles: true }));
                }
                
                // Wait for navigation
                await new Promise(resolve => setTimeout(resolve, 2000));
                
                return true;
            }
        } catch (error) {
            console.error('Navigation error:', error);
        }
        
        return false;
    }

    async navigateToPage(page) {
        console.log('📄 Navigating to page:', page);
        
        try {
            if (page.element) {
                // Scroll into view first
                page.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                
                await new Promise(resolve => setTimeout(resolve, 500));
                
                // Try multiple interaction methods
                if (page.element.click) {
                    page.element.click();
                } else {
                    page.element.dispatchEvent(new MouseEvent('click', { bubbles: true }));
                }
                
                // For tab elements, also try key events
                if (page.element.getAttribute('role') === 'tab') {
                    page.element.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' }));
                }
                
                // Wait for navigation
                await new Promise(resolve => setTimeout(resolve, 2000));
                
                return true;
            }
        } catch (error) {
            console.error('Page navigation error:', error);
        }
        
        return false;
    }

    isFilterCommand(command) {
        const filterKeywords = ['filter', 'where', 'show only', 'exclude', 'include'];
        return filterKeywords.some(keyword => command.includes(keyword));
    }

    async handleFilterCommand(command) {
        console.log('🔍 Handling filter command:', command);
        
        // Look for filter elements (slicers, dropdowns, etc.)
        const filterElements = document.querySelectorAll('.slicer, select, input[type="text"], .dropdown, .filter-container');
        
        if (filterElements.length === 0) {
            this.addMessage('❌ No filter controls found on this page.', 'bot');
            return;
        }
        
        // Extract filter criteria from command
        const criteria = this.extractFilterCriteria(command);
        
        this.addMessage(`🔍 Attempting to apply filter: "${criteria}"\n\nFound ${filterElements.length} filter controls. This feature is being enhanced for your specific reports.`, 'bot');
        
        // TODO: Implement specific filtering logic based on your report structure
    }

    extractFilterCriteria(command) {
        return command
            .replace(/filter by|where|show only|include|exclude/gi, '')
            .trim();
    }

    isBookmarkCommand(command) {
        const bookmarkKeywords = ['bookmark', 'apply', 'preset', 'saved view'];
        return bookmarkKeywords.some(keyword => command.includes(keyword));
    }

    async handleBookmarkCommand(command) {
        console.log('📑 Handling bookmark command:', command);
        
        const bookmarkElements = document.querySelectorAll('.bookmark, [onclick*="bookmark"], [data-automation-id*="bookmark"]');
        
        if (bookmarkElements.length === 0) {
            this.addMessage('❌ No bookmarks found on this page.', 'bot');
            return;
        }
        
        const bookmarkName = this.extractBookmarkName(command);
        
        // Try to find and apply bookmark
        for (const element of bookmarkElements) {
            const elementText = element.textContent.toLowerCase();
            if (elementText.includes(bookmarkName.toLowerCase()) || bookmarkName.toLowerCase().includes(elementText)) {
                element.click();
                this.addMessage(`✅ Applied bookmark: ${element.textContent.trim()}`, 'bot');
                return;
            }
        }
        
        this.addMessage(`❌ Could not find bookmark "${bookmarkName}". Available bookmarks: ${Array.from(bookmarkElements).map(e => e.textContent.trim()).join(', ')}`, 'bot');
    }

    extractBookmarkName(command) {
        return command
            .replace(/apply bookmark|bookmark|apply|preset|saved view/gi, '')
            .trim();
    }

    isInformationCommand(command) {
        const infoKeywords = ['what', 'list', 'show me', 'available', 'help'];
        return infoKeywords.some(keyword => command.includes(keyword));
    }

    async handleInformationCommand(command) {
        if (command.includes('report')) {
            const reportList = Array.from(this.config.reports.keys()).join('\n• ');
            this.addMessage(`📊 Available Reports (${this.config.reports.size}):\n\n• ${reportList}`, 'bot');
        } else if (command.includes('page')) {
            const pageList = Array.from(this.config.pages.keys()).join('\n• ');
            this.addMessage(`📄 Available Pages (${this.config.pages.size}):\n\n• ${pageList}`, 'bot');
        } else {
            this.addMessage(`ℹ️ Power BI Assistant Help:\n\n🔍 Navigation:\n• "Show me [report name]"\n• "Go to [page name]"\n\n🎯 Filtering:\n• "Filter by [criteria]"\n\n📑 Bookmarks:\n• "Apply bookmark [name]"\n\n❓ Information:\n• "What reports are available?"\n• "List all pages"\n\nI found ${this.config.reports.size} reports and ${this.config.pages.size} pages in your current app.`, 'bot');
        }
    }

    addChatbotStyles() {
        const styles = `
            <style id="enhanced-powerbi-chatbot-styles">
                #enhanced-powerbi-chatbot {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    width: 350px;
                    height: 500px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                    z-index: 10000;
                    display: flex;
                    flex-direction: column;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    transition: all 0.3s ease;
                }

                #enhanced-powerbi-chatbot.minimized {
                    height: 50px;
                }

                #enhanced-powerbi-chatbot.minimized .chatbot-messages,
                #enhanced-powerbi-chatbot.minimized .chatbot-input-area,
                #enhanced-powerbi-chatbot.minimized .chatbot-status {
                    display: none;
                }

                .chatbot-header {
                    background: rgba(255,255,255,0.1);
                    padding: 15px;
                    border-radius: 15px 15px 0 0;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    cursor: move;
                    backdrop-filter: blur(10px);
                }

                .chatbot-title {
                    color: white;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }

                .chatbot-icon {
                    font-size: 20px;
                    animation: pulse 2s infinite;
                }

                @keyframes pulse {
                    0%, 100% { transform: scale(1); }
                    50% { transform: scale(1.1); }
                }

                .chatbot-controls {
                    display: flex;
                    gap: 5px;
                }

                .chatbot-controls button {
                    background: rgba(255,255,255,0.2);
                    border: none;
                    border-radius: 50%;
                    width: 30px;
                    height: 30px;
                    color: white;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }

                .chatbot-controls button:hover {
                    background: rgba(255,255,255,0.3);
                    transform: scale(1.1);
                }

                .mic-button {
                    background: #4CAF50 !important;
                }

                .chatbot-messages {
                    flex: 1;
                    padding: 15px;
                    overflow-y: auto;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }

                .message {
                    max-width: 85%;
                    word-wrap: break-word;
                }

                .user-message {
                    align-self: flex-end;
                }

                .bot-message {
                    align-self: flex-start;
                }

                .message-content {
                    padding: 10px 15px;
                    border-radius: 15px;
                    margin-bottom: 5px;
                }

                .user-message .message-content {
                    background: #007acc;
                    color: white;
                }

                .bot-message .message-content {
                    background: rgba(255,255,255,0.9);
                    color: #333;
                }

                .message-time {
                    font-size: 11px;
                    color: rgba(255,255,255,0.7);
                    text-align: right;
                }

                .user-message .message-time {
                    text-align: right;
                }

                .bot-message .message-time {
                    text-align: left;
                    color: rgba(0,0,0,0.5);
                }

                .chatbot-input-area {
                    padding: 15px;
                    display: flex;
                    gap: 10px;
                }

                #chatbot-input {
                    flex: 1;
                    padding: 10px 15px;
                    border: none;
                    border-radius: 25px;
                    outline: none;
                    font-size: 14px;
                }

                .send-button {
                    background: #007acc;
                    border: none;
                    border-radius: 50%;
                    width: 40px;
                    height: 40px;
                    color: white;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }

                .send-button:hover {
                    background: #005a9e;
                    transform: scale(1.1);
                }

                .chatbot-status {
                    background: rgba(0,0,0,0.1);
                    padding: 8px 15px;
                    font-size: 12px;
                    color: rgba(255,255,255,0.8);
                    text-align: center;
                    border-radius: 0 0 15px 15px;
                }

                .loading-dots {
                    animation: loading 1.5s infinite;
                }

                @keyframes loading {
                    0%, 20% { opacity: 1; }
                    50% { opacity: 0.5; }
                    80%, 100% { opacity: 1; }
                }

                /* Scrollbar styling */
                .chatbot-messages::-webkit-scrollbar {
                    width: 6px;
                }

                .chatbot-messages::-webkit-scrollbar-track {
                    background: rgba(255,255,255,0.1);
                    border-radius: 3px;
                }

                .chatbot-messages::-webkit-scrollbar-thumb {
                    background: rgba(255,255,255,0.3);
                    border-radius: 3px;
                }

                .chatbot-messages::-webkit-scrollbar-thumb:hover {
                    background: rgba(255,255,255,0.5);
                }
            </style>
        `;
        
        document.head.insertAdjacentHTML('beforeend', styles);
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new EnhancedPowerBIChatbot();
    });
} else {
    new EnhancedPowerBIChatbot();
}
