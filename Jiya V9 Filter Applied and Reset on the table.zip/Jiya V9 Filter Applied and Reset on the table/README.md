# Power BI Chatbot Browser Extension

This browser extension injects a chatbot with speech recognition into every Power BI report page you open in your browser. The chatbot can answer questions about your data and (with further development) can be integrated to filter or interact with Power BI visuals based on your commands.

## Features
- Chatbot UI overlay on all Power BI report pages
- Speech recognition (mic button) for voice commands
- Smart Power BI interaction with navigation and filtering capabilities
- Table visual column selection and reset functionality
- Modern, draggable, and closable UI

## How to Use
1. Load the extension in Chrome/Edge:
   - Go to `chrome://extensions` or `edge://extensions`
   - Enable "Developer mode"
   - Click "Load unpacked" and select this folder
2. Open any Power BI report in your browser. The chatbot will appear in the bottom-right corner.
3. Type or speak your question. The bot will respond (demo logic).

## Files
- `manifest.json` - Extension manifest (permissions, content script)
- `background.js` - Background service worker
- `contentScript.js` - Injects chatbot UI and logic
- `chatbot.css` - Styles for the chatbot UI

## Next Steps
- Integrate with Power BI JavaScript API for real data interaction
- Enhance NLP for more natural conversations
- Add settings or customization options

---

Created with GitHub Copilot
