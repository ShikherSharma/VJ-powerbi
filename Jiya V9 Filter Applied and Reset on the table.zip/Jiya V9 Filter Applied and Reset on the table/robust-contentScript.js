/*
====================================================================
ENHANCED POWER BI CHATBOT - ROBUST CONTENT SCRIPT
====================================================================
Purpose: Reliable chatbot loader for Power BI apps
Target: Any Power BI app, especially your specific one
====================================================================
*/

(function () {
    'use strict';

    // Prevent multiple injections
    if (window.__powerBIChatbotLoaded) {
        console.log('🔄 Chatbot already loaded, skipping...');
        return;
    }
    window.__powerBIChatbotLoaded = true;

    console.log('🚀 Power BI Chatbot Content Script Starting...');
    console.log('📍 Current URL:', window.location.href);

    // Check if we're on a Power BI page
    function isPowerBIPage() {
        const url = window.location.href;
        return url.includes('powerbi.com') || 
               url.includes('app.powerbi') ||
               document.querySelector('.powerbi-embed, iframe[src*="powerbi"]') !== null;
    }

    // Create the enhanced chatbot directly
    function createEnhancedChatbot() {
        console.log('🤖 Creating Enhanced Power BI Chatbot...');

        // Remove any existing chatbot
        const existing = document.getElementById('enhanced-powerbi-chatbot');
        if (existing) existing.remove();

        // Create chatbot HTML
        const chatbotContainer = document.createElement('div');
        chatbotContainer.id = 'enhanced-powerbi-chatbot';
        chatbotContainer.innerHTML = `
            <div class="chatbot-header">
                <div class="chatbot-title">
                    <span class="chatbot-icon">🤖</span>
                    Power BI Assistant
                </div>
                <div class="chatbot-controls">
                    <button id="chatbot-mic" class="mic-button" title="Voice Commands">🎤</button>
                    <button id="chatbot-minimize" class="minimize-button" title="Minimize">−</button>
                    <button id="chatbot-close" class="close-button" title="Close">×</button>
                </div>
            </div>
            <div class="chatbot-messages" id="chatbot-messages">
                <div class="message bot-message">
                    <div class="message-content">
                        Hello! 👋 I'm your Power BI Assistant.<br><br>
                        � <strong>Your App Structure:</strong><br>
                        • Consumer Website Traffic (Report)<br>
                        • Operations Analytics (Report & Page)<br>
                        • Location Analytics (Page)<br>
                        • Website Analytics (Page)<br><br>
                        🎤 <strong>Try These Commands:</strong><br>
                        • "Open Location Analytics"<br>
                        • "Show me Website Analytics"<br>
                        • "What reports are available?"<br>
                        • "Go to Operations Analytics"<br>
                        • "Select columns 1, 2, 3 from Sales Table"<br><br>
                        💬 <strong>Voice or Text:</strong> Click 🎤 or type below!
                    </div>
                    <div class="message-time">${new Date().toLocaleTimeString()}</div>
                </div>
            </div>
            <div class="chatbot-input-area">
                <input type="text" id="chatbot-input" placeholder="Ask about reports, pages, or say a command..." />
                <button id="chatbot-send" class="send-button">📤</button>
            </div>
            <div class="chatbot-status" id="chatbot-status">
                Ready • Power BI Assistant Active
            </div>
        `;

        // Add styles
        const styles = document.createElement('style');
        styles.textContent = `
            #enhanced-powerbi-chatbot {
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 350px;
                height: 500px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                z-index: 10000;
                display: flex;
                flex-direction: column;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                transition: all 0.3s ease;
                color: white;
            }

            #enhanced-powerbi-chatbot.minimized {
                height: 50px;
            }

            #enhanced-powerbi-chatbot.minimized .chatbot-messages,
            #enhanced-powerbi-chatbot.minimized .chatbot-input-area,
            #enhanced-powerbi-chatbot.minimized .chatbot-status {
                display: none;
            }

            .chatbot-header {
                background: rgba(255,255,255,0.1);
                padding: 15px;
                border-radius: 15px 15px 0 0;
                display: flex;
                justify-content: space-between;
                align-items: center;
                cursor: move;
                backdrop-filter: blur(10px);
            }

            .chatbot-title {
                color: white;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .chatbot-icon {
                font-size: 20px;
                animation: pulse 2s infinite;
            }

            @keyframes pulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.1); }
            }

            .chatbot-controls {
                display: flex;
                gap: 5px;
            }

            .chatbot-controls button {
                background: rgba(255,255,255,0.2);
                border: none;
                border-radius: 50%;
                width: 30px;
                height: 30px;
                color: white;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .chatbot-controls button:hover {
                background: rgba(255,255,255,0.3);
                transform: scale(1.1);
            }

            .mic-button {
                background: #4CAF50 !important;
            }

            .chatbot-messages {
                flex: 1;
                padding: 15px;
                overflow-y: auto;
                display: flex;
                flex-direction: column;
                gap: 10px;
            }

            .message {
                max-width: 85%;
                word-wrap: break-word;
            }

            .user-message {
                align-self: flex-end;
            }

            .bot-message {
                align-self: flex-start;
            }

            .message-content {
                padding: 10px 15px;
                border-radius: 15px;
                margin-bottom: 5px;
            }

            .user-message .message-content {
                background: #007acc;
                color: white;
            }

            .bot-message .message-content {
                background: rgba(255,255,255,0.9);
                color: #333;
            }

            .message-time {
                font-size: 11px;
                color: rgba(255,255,255,0.7);
                text-align: right;
            }

            .user-message .message-time {
                text-align: right;
            }

            .bot-message .message-time {
                text-align: left;
                color: rgba(0,0,0,0.5);
            }

            .chatbot-input-area {
                padding: 15px;
                display: flex;
                gap: 10px;
            }

            #chatbot-input {
                flex: 1;
                padding: 10px 15px;
                border: none;
                border-radius: 25px;
                outline: none;
                font-size: 14px;
            }

            .send-button {
                background: #007acc;
                border: none;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                color: white;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .send-button:hover {
                background: #005a9e;
                transform: scale(1.1);
            }

            .chatbot-status {
                background: rgba(0,0,0,0.1);
                padding: 8px 15px;
                font-size: 12px;
                color: rgba(255,255,255,0.8);
                text-align: center;
                border-radius: 0 0 15px 15px;
            }

            /* Scrollbar styling */
            .chatbot-messages::-webkit-scrollbar {
                width: 6px;
            }

            .chatbot-messages::-webkit-scrollbar-track {
                background: rgba(255,255,255,0.1);
                border-radius: 3px;
            }

            .chatbot-messages::-webkit-scrollbar-thumb {
                background: rgba(255,255,255,0.3);
                border-radius: 3px;
            }

            .chatbot-messages::-webkit-scrollbar-thumb:hover {
                background: rgba(255,255,255,0.5);
            }
        `;

        // Add to page
        document.head.appendChild(styles);
        document.body.appendChild(chatbotContainer);

        console.log('✅ Chatbot UI created successfully');

        // Initialize functionality
        initializeChatbotFunctionality();
    }

    // Initialize chatbot functionality
    function initializeChatbotFunctionality() {
        console.log('⚙️ Initializing chatbot functionality...');

        let speechRecognition = null;
        let isListening = false;

        // Initialize speech recognition
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            speechRecognition = new SpeechRecognition();
            
            speechRecognition.continuous = false;
            speechRecognition.interimResults = false;
            speechRecognition.lang = 'en-US';
            
            speechRecognition.onstart = () => {
                isListening = true;
                document.getElementById('chatbot-mic').style.backgroundColor = '#ff4444';
                document.getElementById('chatbot-status').textContent = 'Listening...';
            };
            
            speechRecognition.onend = () => {
                isListening = false;
                document.getElementById('chatbot-mic').style.backgroundColor = '#4CAF50';
                document.getElementById('chatbot-status').textContent = 'Ready • Power BI Assistant Active';
            };
            
            speechRecognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                document.getElementById('chatbot-input').value = transcript;
                addMessage(transcript, 'user');
                processCommand(transcript);
            };
            
            speechRecognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                addMessage('Sorry, I couldn\'t hear that clearly. Please try again.', 'bot');
            };
        }

        // Event listeners
        const sendMessage = () => {
            const input = document.getElementById('chatbot-input');
            const message = input.value.trim();
            if (message) {
                addMessage(message, 'user');
                processCommand(message);
                input.value = '';
            }
        };
        
        document.getElementById('chatbot-send').addEventListener('click', sendMessage);
        document.getElementById('chatbot-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
        
        // Voice button
        document.getElementById('chatbot-mic').addEventListener('click', () => {
            if (!speechRecognition) {
                addMessage('Speech recognition is not supported in your browser.', 'bot');
                return;
            }
            
            if (isListening) {
                speechRecognition.stop();
            } else {
                speechRecognition.start();
            }
        });
        
        // Minimize button
        document.getElementById('chatbot-minimize').addEventListener('click', () => {
            document.getElementById('enhanced-powerbi-chatbot').classList.toggle('minimized');
        });
        
        // Close button
        document.getElementById('chatbot-close').addEventListener('click', () => {
            document.getElementById('enhanced-powerbi-chatbot').style.display = 'none';
        });

        // Make draggable
        makeDraggable();

        console.log('✅ Chatbot functionality initialized');
    }

    // Add message to chat
    function addMessage(content, type) {
        const messagesContainer = document.getElementById('chatbot-messages');
        const messageElement = document.createElement('div');
        messageElement.className = `message ${type}-message`;
        
        messageElement.innerHTML = `
            <div class="message-content">${content.replace(/\n/g, '<br>')}</div>
            <div class="message-time">${new Date().toLocaleTimeString()}</div>
        `;
        
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Process user commands with enhanced Power BI app structure understanding
    function processCommand(command) {
        console.log('🎯 Processing command:', command);
        
        const normalizedCommand = command.toLowerCase().trim();
        
        // Enhanced Power BI elements scanning with your app structure
        const allElements = scanPowerBIStructure();
        
        // Navigation commands with enhanced debugging
        if ((normalizedCommand.includes('show') || normalizedCommand.includes('open') || normalizedCommand.includes('go to')) &&
            !normalizedCommand.includes('show all') && !normalizedCommand.includes('list all') && !normalizedCommand.includes('what')) {
            console.log(`🎯 Navigation command detected: "${command}"`);
            
            const target = extractTarget(normalizedCommand);
            console.log(`🎯 Extracted target: "${target}"`);
            
            // Enhanced navigation with fuzzy matching for your app structure
            const foundElement = findBestNavigationMatch(target, allElements);
            if (foundElement) {
                console.log(`✅ Found element to navigate to: "${foundElement.name}" (${foundElement.type})`);
                
                // Double-check the match before clicking with strict validation
                const targetWords = target.toLowerCase().split(/\s+/);
                const foundWords = foundElement.name.toLowerCase().split(/\s+/);
                const matchQuality = calculateMatchQuality(targetWords, foundWords);
                
                console.log(`🔍 Match quality check: ${matchQuality}% for "${target}" → "${foundElement.name}"`);
                
                // STRICT validation for your specific app to prevent wrong matches
                let isValidMatch = true;
                
                console.log(`🔍 VALIDATION CHECK: target="${target}", foundElement="${foundElement.name.toLowerCase()}"`);
                
                // If user wants "location analytics" (and NOT consumer website traffic), found element MUST contain "location"
                if (target.includes('location') && !target.includes('consumer') && !target.includes('traffic') && 
                    !foundElement.name.toLowerCase().includes('location')) {
                    console.log(`❌ User wants LOCATION ANALYTICS but found element doesn't contain 'location': "${foundElement.name}"`);
                    isValidMatch = false;
                }
                
                // If user wants "website analytics" (and NOT consumer website traffic), found element MUST contain "website" AND "analytics"
                if (target.includes('website') && target.includes('analytics') && !target.includes('consumer') && !target.includes('traffic') && 
                    !(foundElement.name.toLowerCase().includes('website') && foundElement.name.toLowerCase().includes('analytics'))) {
                    console.log(`❌ User wants WEBSITE ANALYTICS but found element doesn't contain both 'website' and 'analytics': "${foundElement.name}"`);
                    isValidMatch = false;
                }
                
                // If user wants "operations analytics" (and NOT consumer website traffic), found element MUST contain "operations"
                if (target.includes('operations') && !target.includes('consumer') && !target.includes('traffic') && 
                    !foundElement.name.toLowerCase().includes('operations')) {
                    console.log(`❌ User wants OPERATIONS ANALYTICS but found element doesn't contain 'operations': "${foundElement.name}"`);
                    isValidMatch = false;
                }
                
                // If user wants "consumer website traffic" (full phrase), found element should contain consumer/traffic/cwt keywords
                if ((target.includes('consumer') && target.includes('website') && target.includes('traffic')) && 
                    !(foundElement.name.toLowerCase().includes('consumer') || 
                      foundElement.name.toLowerCase().includes('traffic') || 
                      foundElement.name.toLowerCase().includes('cwt'))) {
                    console.log(`❌ User wants CONSUMER WEBSITE TRAFFIC but found element doesn't contain relevant keywords: "${foundElement.name}"`);
                    isValidMatch = false;
                }
                
                // Only proceed if match quality is high enough AND validation passes
                if (isValidMatch && (matchQuality >= 80 || (targetWords.length === 1 && matchQuality >= 90))) {
                    // Scroll into view and click
                    foundElement.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    setTimeout(() => {
                        foundElement.element.click();
                        addMessage(`✅ Navigating to: ${foundElement.name} (${foundElement.type})\n\n🎯 You requested: "${target}"\n📊 Match quality: ${matchQuality}%`, 'bot');
                    }, 500);
                } else {
                    console.log(`⚠️ Match failed - Quality: ${matchQuality}%, Valid: ${isValidMatch}`);
                    
                    let errorMessage = `❌ I found "${foundElement.name}" but it doesn't match "${target}".\n\n`;
                    
                    // Be more specific about what the user actually wanted
                    if (target.includes('location') && !target.includes('consumer') && !target.includes('traffic')) {
                        errorMessage += `🎯 You asked for LOCATION Analytics but I found "${foundElement.name}".\n\n`;
                        errorMessage += `✅ Try these exact commands:\n`;
                        errorMessage += `• "Open Location Analytics page"\n`;
                        errorMessage += `• "Go to Location Analytics"\n`;
                        errorMessage += `• "Show Location Analytics"`;
                    } else if (target.includes('website') && target.includes('analytics') && !target.includes('consumer') && !target.includes('traffic')) {
                        errorMessage += `🎯 You asked for WEBSITE Analytics but I found "${foundElement.name}".\n\n`;
                        errorMessage += `✅ Try: "Open Website Analytics"`;
                    } else if (target.includes('operations') && !target.includes('consumer') && !target.includes('traffic')) {
                        errorMessage += `🎯 You asked for OPERATIONS Analytics but I found "${foundElement.name}".\n\n`;
                        errorMessage += `✅ Try: "Open Operations Analytics"`;
                    } else if (target.includes('consumer') && target.includes('website') && target.includes('traffic')) {
                        errorMessage += `🎯 You asked for CONSUMER WEBSITE TRAFFIC but I found "${foundElement.name}".\n\n`;
                        errorMessage += `✅ Try these exact commands:\n`;
                        errorMessage += `• "Open Consumer Website Traffic"\n`;
                        errorMessage += `• "Go to CWT report"\n`;
                        errorMessage += `• "Show Consumer Website Traffic report"`;
                    } else {
                        errorMessage += `✅ Available options:\n• Consumer Website Traffic (CWT)\n• Location Analytics\n• Website Analytics\n• Operations Analytics`;
                    }
                    
                    addMessage(errorMessage, 'bot');
                }
            } else {
                console.log(`❌ No matching element found for: "${target}"`);
                
                let notFoundMessage = `❌ Could not find "${target}".\n\n`;
                
                // Provide specific guidance based on what they're looking for
                if (target.includes('location') && !target.includes('consumer') && !target.includes('traffic')) {
                    notFoundMessage += `🔍 Looking for Location Analytics? Try:\n`;
                    notFoundMessage += `• "Open Location Analytics"\n`;
                    notFoundMessage += `• "Go to Location Analytics page"\n\n`;
                    notFoundMessage += `💡 Make sure you're on the right report first!`;
                } else if (target.includes('website') && target.includes('analytics') && !target.includes('consumer') && !target.includes('traffic')) {
                    notFoundMessage += `🔍 Looking for Website Analytics? Try:\n`;
                    notFoundMessage += `• "Open Website Analytics"\n`;
                    notFoundMessage += `• "Show Website Analytics page"`;
                } else if (target.includes('operations') && !target.includes('consumer') && !target.includes('traffic')) {
                    notFoundMessage += `🔍 Looking for Operations Analytics? Try:\n`;
                    notFoundMessage += `• "Open Operations Analytics"\n`;
                    notFoundMessage += `• "Go to Operations Analytics page"`;
                } else if (target.includes('consumer') && target.includes('website') && target.includes('traffic')) {
                    notFoundMessage += `🔍 Looking for Consumer Website Traffic (CWT)? Try:\n`;
                    notFoundMessage += `• "Open Consumer Website Traffic"\n`;
                    notFoundMessage += `• "Go to CWT report"\n`;
                    notFoundMessage += `• "Show Consumer Website Traffic report"\n\n`;
                    notFoundMessage += `💡 Make sure you're in the right workspace!`;
                } else {
                    const availableItems = formatAvailableItems(allElements);
                    notFoundMessage += availableItems;
                }
                
                addMessage(notFoundMessage, 'bot');
            }
        }
        // RESET REPORT COMMAND (check first to avoid conflicts with other reset commands)
        else if (normalizedCommand.includes('reset report') || normalizedCommand.includes('restore report') || 
                 normalizedCommand.includes('reset to default') || normalizedCommand.includes('restore default') ||
                 normalizedCommand.includes('default view') || normalizedCommand.includes('original view') ||
                 normalizedCommand.includes('reset page') || normalizedCommand.includes('restore page')) {
            console.log(`🔄 Reset report command detected: "${command}"`);
            handleResetReportCommand();
        }
        // RESET TABLE VISUAL COMMAND - reset a specific table visual to show all columns
        else if ((normalizedCommand.includes('reset') || normalizedCommand.startsWith('reset')) && 
                !(normalizedCommand.includes('filter') || normalizedCommand.includes('report') || 
                  normalizedCommand.includes('page') || normalizedCommand.includes('all') || 
                  normalizedCommand.includes('default'))) {
            console.log(`🔄 Reset table visual command detected: "${command}"`);
            
            // Preprocess special cases - handle "Reset table visual" as a generic reset command
            if (normalizedCommand.match(/reset\s+table\s+visual/i) || 
                normalizedCommand === "reset table" || 
                normalizedCommand === "reset visual" ||
                normalizedCommand === "reset") {
                console.log(`🎯 Generic reset command detected`);
                handleResetVisualCommand("", command);
                return;
            }
            
            // Extract visual name to reset
            const visualName = extractVisualNameToReset(normalizedCommand);
            console.log(`🎯 Extracted visual name to reset: "${visualName || 'unknown'}"`);
            
            // Handle reset visual command
            handleResetVisualCommand(visualName, command);
        }
        // RESET ALL FILTERS COMMAND (check first to avoid conflicts)
        else if (normalizedCommand.includes('reset all') || normalizedCommand.includes('clear all') || 
                 normalizedCommand.includes('remove all filters')) {
            console.log(`� Reset all filters command detected: "${command}"`);
            handleResetAllFiltersCommand();
        }
        // RESET INDIVIDUAL FILTER COMMANDS (check before regular filter commands)
        else if ((normalizedCommand.includes('reset') && normalizedCommand.includes('filter')) || 
                 (normalizedCommand.includes('clear') && normalizedCommand.includes('filter')) ||
                 (normalizedCommand.includes('remove') && normalizedCommand.includes('filter'))) {
            console.log(`🔄 Reset individual filter command detected: "${command}"`);
            console.log(`🔍 Normalized command: "${normalizedCommand}"`);
            
            // Extract filter name and use enhanced function
            const filterName = extractFilterNameToReset(normalizedCommand);
            console.log(`🎯 Extracted filter name: "${filterName}"`);
            
            if (filterName) {
                console.log(`✅ Calling handleResetFilterCommand with: "${filterName}"`);
                handleResetFilterCommand(filterName);
            } else {
                console.log(`❌ No filter name extracted, falling back to old method`);
                handleResetFilterCommandOld(normalizedCommand, command);
            }
        }
        // EXPORT COMMANDS - Export Power BI visuals to Excel/CSV
        else if (normalizedCommand.includes('export') || normalizedCommand.includes('download') ||
                 normalizedCommand.includes('save to excel') || normalizedCommand.includes('save to csv')) {
            console.log(`📤 EXPORT COMMAND DETECTED`);
            console.log(`📋 Original command: "${command}"`);
            console.log(`📋 Normalized command: "${normalizedCommand}"`);
            
            // Add immediate user feedback
            addMessage(`📤 Processing export command: "${command}"\n\n🔍 Analyzing export request...`, 'bot');
            
            try {
                console.log(`🚀 Calling handleExportCommand...`);
                handleExportCommand(normalizedCommand, command);
                console.log(`✅ handleExportCommand call completed`);
            } catch (error) {
                console.error(`❌ Error calling handleExportCommand:`, error);
                addMessage(`❌ Error processing export command: ${error.message}`, 'bot');
            }
        }
        // FILTERING COMMANDS - Apply filters to Power BI reports
        else if (normalizedCommand.includes('filter') || normalizedCommand.includes('show data') || 
                 normalizedCommand.includes('apply') || normalizedCommand.includes('set filter')) {
            console.log(`🔍 MAIN FILTER COMMAND DETECTED`);
            console.log(`📋 Original command: "${command}"`);
            console.log(`📋 Normalized command: "${normalizedCommand}"`);
            console.log(`🎯 Command matches filter condition: ${normalizedCommand.includes('filter')}`);
            
            // Add immediate user feedback
            addMessage(`🔍 Processing filter command: "${command}"\n\n⏳ Analyzing request...`, 'bot');
        }
        // TABLE COLUMN SELECTION COMMANDS - Select specific columns from table visuals
        else if (((normalizedCommand.includes('select') || normalizedCommand.includes('show')) && 
                 normalizedCommand.includes('column') && 
                 (normalizedCommand.includes('from') || normalizedCommand.includes('in') || normalizedCommand.includes('visual'))) ||
                 // Also detect simpler column selection commands like "select Region from Table" without "column" word
                 ((normalizedCommand.includes('select') || normalizedCommand.includes('show')) && 
                 (normalizedCommand.includes('from') || normalizedCommand.includes('in')) &&
                 !normalizedCommand.includes('data') && !normalizedCommand.includes('filter'))) {
            console.log(`📊 TABLE COLUMN SELECTION COMMAND DETECTED`);
            console.log(`📋 Original command: "${command}"`);
            console.log(`📋 Normalized command: "${normalizedCommand}"`);
            
            // Add immediate user feedback
            addMessage(`📊 Processing column selection command: "${command}"\n\n⏳ Analyzing table visuals...`, 'bot');
            
            try {
                handleTableColumnSelection(normalizedCommand, command);
            } catch (error) {
                console.error(`❌ Error processing column selection command:`, error);
                addMessage(`❌ Error selecting columns: ${error.message}`, 'bot');
            }
        }
        // Information commands with enhanced app structure display
        else if (normalizedCommand.includes('what') || normalizedCommand.includes('available') || normalizedCommand.includes('list') ||
                 normalizedCommand.includes('show all') || normalizedCommand.includes('all reports') || normalizedCommand.includes('all pages')) {
            const allElements = scanPowerBIStructure();
            
            if (normalizedCommand.includes('report') || normalizedCommand.includes('show all reports') || normalizedCommand.includes('all reports')) {
                const reports = allElements.filter(e => e.type === 'report');
                if (reports.length > 0) {
                    const reportList = reports.map(r => r.name).join('\n• ');
                    addMessage(`📊 Available Reports (${reports.length}):\n\n• ${reportList}\n\n💡 Try: "Open [report name]" to navigate to a specific report`, 'bot');
                } else {
                    addMessage('📊 No reports detected.\n\n🔍 Scanning for items containing "report"...\n\n💡 Navigate to your Power BI workspace to see available reports.', 'bot');
                }
            } else if (normalizedCommand.includes('page') || normalizedCommand.includes('tab') || normalizedCommand.includes('show all pages') || normalizedCommand.includes('all pages')) {
                const pages = allElements.filter(e => e.type === 'page');
                if (pages.length > 0) {
                    // ULTRA-STRICT filtering - only show actual meaningful page navigation
                    const relevantPages = pages.filter(p => {
                        const name = p.name.toLowerCase();
                        
                        // Filter out UI elements, data values, and system text
                        const excludePatterns = [
                            'undefined', 'null', 'loading', 'error', 'button', 'menu', 'toolbar',
                            'navigation', 'header', 'footer', 'sidebar', 'dropdown', 'popup',
                            'modal', 'dialog', 'tooltip', 'icon', 'spinner', 'loader',
                            'press enter', 'click', 'explore data', 'see details', 'more options',
                            'visuals are loading', 'go back', 'expand', 'collapse', 'zoom',
                            'share', 'export', 'subscribe', 'alert', 'copilot', 'edit',
                            'favorite', 'bookmark', 'filter', 'clear', 'reset', 'search',
                            'download', 'help', 'support', 'settings', 'account', 'app info',
                            'file', 'view', 'explore', 'average', 'number of', 'daily users',
                            'unique visitors', 'conversion rate', 'duration', 'visits by',
                            'sentiment by', 'tweets by', 'popular products', 'device category',
                            'product category', 'region', 'asia pacific', 'europe', 'america',
                            'desktop', 'mobile', 'tablet', 'complete', 'in progress', 'not started',
                            'filters on this page', 'is not blank', 'basic filtering', 'app launcher',
                            'clear selections', 'global search', 'hide the navigation', 'account manager',
                            'help improve fabric', 'fit to page', 'show/hide filter pane',
                            'demo project', 'average daily and unique users', 'visits', 'popular products',
                            'sentiment', 'return visitors', 'camera housing', 'chipset', 'finance',
                            'recharchable battery', 'tilt sensor', 'consumer website traffic', 'visits visits',
                            'return visitors return visitors', 'filters'
                        ];
                        
                        // Exclude if contains any unwanted patterns
                        if (excludePatterns.some(pattern => name.includes(pattern))) {
                            return false;
                        }
                        
                        // Must be reasonable length (not too short, not too long)
                        if (name.length < 5 || name.length > 50) return false;
                        
                        // Must not be pure numbers, percentages, or data values
                        if (/^[0-9\s\.\,\%\-\+\(\)KkMm]+$/.test(name)) return false;
                        
                        // Must not be mostly symbols or special characters
                        const alphaRatio = (name.match(/[a-zA-Z]/g) || []).length / name.length;
                        if (alphaRatio < 0.6) return false;
                        
                        // Must have reasonable word structure (1-4 words for pages)
                        const words = name.split(/\s+/).filter(w => w.length > 1);
                        if (words.length < 1 || words.length > 4) return false;
                        
                        // Must contain meaningful page-related keywords
                        const pageKeywords = [
                            'analytics', 'location', 'website', 'operations', 'dashboard',
                            'overview', 'summary', 'details', 'performance', 'insights',
                            'home', 'main', 'primary'
                        ];
                        
                        const hasPageKeyword = pageKeywords.some(keyword => name.includes(keyword));
                        
                        return hasPageKeyword;
                    });
                    
                    if (relevantPages.length > 0) {
                        const pageList = relevantPages.map(p => p.name).join('\n• ');
                        addMessage(`📄 Available Pages (${relevantPages.length}):\n\n• ${pageList}\n\n💡 Try: "Open [page name]" to navigate to a specific page`, 'bot');
                    } else {
                        addMessage('📄 No meaningful page navigation found.\n\n🔍 Looking for actual page tabs and navigation elements...\n\n💡 Try navigating to a report first to see available pages.', 'bot');
                    }
                } else {
                    addMessage('📄 No pages found. Try navigating to a report first to see page tabs.', 'bot');
                }
            } else {
                // Show structured view of your app
                const reports = allElements.filter(e => e.type === 'report');
                const pages = allElements.filter(e => e.type === 'page');
                
                let response = '📋 Your Power BI App Structure:\n\n';
                
                if (reports.length > 0) {
                    response += `📊 Reports (${reports.length}):\n`;
                    reports.forEach(r => response += `• ${r.name}\n`);
                    response += '\n';
                }
                
                if (pages.length > 0) {
                    response += `📄 Pages (${pages.length}):\n`;
                    pages.forEach(p => response += `• ${p.name}\n`);
                    response += '\n';
                }
                
                response += '💡 Expected Structure:\n';
                response += '1. Consumer Website Traffic (Report)\n';
                response += '   • Operations Analytics\n';
                response += '   • Location Analytics  \n';
                response += '   • Website Analytics\n\n';
                response += '2. Operations Analytics (Report)\n';
                response += '   • Operations Analytics\n';
                response += '   • Location Analytics\n';
                response += '   • Website Analytics\n\n';
                response += 'Try: "Show me Location Analytics" or "Open Website Analytics"';
                
                addMessage(response, 'bot');
            }
        }
        // Help command with your app-specific examples
        else if (normalizedCommand.includes('help')) {
            addMessage(`🆘 Power BI Assistant Help - Your App Guide:\n\n🎤 Navigation Commands:\n• "Show me Consumer Website Traffic" or "Open CWT"\n• "Open Location Analytics"\n• "Go to Website Analytics"\n• "Switch to Operations Analytics"\n\n🔍 Filter Commands:\n• "Filter by Location New York"\n• "Show data for Region East"\n• "Apply filter Category Electronics"\n• "Set Date to last month"\n\n📊 Table Column Selection:\n• "Select columns 1, 2, 5 from Sales Table"\n• "Show columns Product, Price from Revenue Table"\n• "Select Region from Sales Table"\n• "Show Customer Name from Customer Data"\n• "Reset Sales Table" - Restore all columns\n\n� Export Commands:\n• "Export sentiment by product category"\n• "Download sales data to Excel"\n• "Save revenue chart to CSV"\n• "Export visual to Excel"\n\n�🔄 Reset Commands:\n• "Reset report" - Restore default view\n• "Reset to default" - Full report reset\n• "Default view" - Return to original\n• "Reset Location filter" - Clear specific filter\n• "Clear Category filter" - Remove filter\n• "Reset all filters" - Clear all filters\n\n❓ Information Commands:\n• "What reports are available?"\n• "List all pages"\n• "Show me everything"\n\n� Your App Structure:\n• Report 1: Consumer Website Traffic (CWT)\n• Report 2: Operations Analytics\n• Pages: Operations, Location, Website Analytics\n\n💡 Tips:\n• Use abbreviations: "CWT" for Consumer Website Traffic\n• Use partial names: "Location Analytics" works\n• Voice commands: Click 🎤 and speak\n• Be specific: "Open Location Analytics page"\n• Export any visual: "Export [visual name]"\n• Try variations: "Show Location" or "Go to Analytics"`, 'bot');
        }
        // Default response
        else {
            addMessage(`I understand you said: "${command}"\n\nTry commands like:\n• "Show me [report/page name]"\n• "Select [column name] from [table name]"\n• "Reset [table name]"\n• "What's available?"\n• "Help"`, 'bot');
        }
    }

    // Enhanced Power BI structure scanning with PAGE vs REPORT distinction
    function scanPowerBIStructure() {
        console.log('🔍 Scanning Power BI app structure...');
        console.log('📍 Current URL:', window.location.href);
        
        const allElements = [];
        const debugInfo = {
            totalScanned: 0,
            bySelector: {},
            clickableElements: [],
            allTextElements: [],
            pages: [],
            reports: [],
            tabs: []
        };
        
        // ENHANCED selectors specifically for Power BI PAGES vs REPORTS
        const selectors = {
            // PAGE TAB SELECTORS - These are the page navigation tabs within reports
            pageTabs: [
                '.tabstrip-tab', '.tab-item', '.page-tab', '.pageTab',
                '[role="tab"]', '.pivot-item', '.ms-Pivot-link',
                '.exploration-host .tabItem', '.reportSection-tabs .tab',
                '[data-automation-id*="tab"]', '[data-automation-id*="page"]'
            ],
            // REPORT SELECTORS - These are main report/app navigation
            reports: [
                '.app-item', '.workspace-item', '.report-item',
                '.navigation-pane a', '.nav-item', '.report-nav',
                '[data-automation-id*="report"]', '[data-automation-id*="app"]',
                '.left-nav-item', '.side-nav-item'
            ],
            // NAVIGATION ELEMENTS - General clickable navigation
            navigation: [
                '.nav-item', '.menu-item', '.navigation-item', 
                '[role="menuitem"]', '[role="button"]',
                '.navigation-pane button', '.exploration-container button'
            ],
            // Power BI SPECIFIC selectors with data attributes
            powerbiSpecific: [
                '[data-automation-id]', '[aria-label]', '[title]',
                '[data-testid]', '[data-tab-id]', '[data-page-id]',
                '.visual-container', '.slicer', '.filter-container',
                '.exploration-container', '.report-container',
                '.pageTabStrip', '.tabItem', '.reportBookmark'
            ],
            // TEXT-BASED elements that might contain page/report names
            textBased: [
                'span[title]', 'div[title]', 'button[aria-label]', 
                'a[aria-label]', 'li[role="tab"]', '[data-automation-id] span'
            ]
        };
        
        // Scan all selector types with ENHANCED PAGE vs REPORT detection
        Object.entries(selectors).forEach(([category, categorySelectors]) => {
            console.log(`🔍 Scanning ${category} selectors...`);
            
            categorySelectors.forEach(selector => {
                try {
                    const elements = document.querySelectorAll(selector);
                    debugInfo.bySelector[selector] = elements.length;
                    debugInfo.totalScanned += elements.length;
                    
                    if (elements.length > 0) {
                        console.log(`📋 Found ${elements.length} elements for selector: ${selector} (${category})`);
                    }
                    
                    elements.forEach(element => {
                        const text = element.textContent?.trim();
                        const ariaLabel = element.getAttribute('aria-label');
                        const title = element.getAttribute('title');
                        const dataId = element.getAttribute('data-automation-id');
                        
                        // Get the best text representation
                        const displayText = text || ariaLabel || title || dataId || '';
                        
                        if (displayText && displayText.length > 2 && displayText.length < 200) {
                            
                            // DETERMINE TYPE: PAGE vs REPORT vs TAB
                            let elementType = 'element';
                            let isClickable = false;
                            
                            // Check if it's a PAGE TAB (within a report)
                            if (category === 'pageTabs' || 
                                element.getAttribute('role') === 'tab' ||
                                selector.includes('tab') ||
                                element.closest('.pageTabStrip') ||
                                element.closest('.tabstrip') ||
                                dataId?.includes('tab') ||
                                dataId?.includes('page')) {
                                elementType = 'page';
                                isClickable = true;
                                debugInfo.pages.push({ text: displayText, element });
                                console.log(`📄 Found PAGE: "${displayText}" (selector: ${selector})`);
                            }
                            // Check if it's a REPORT (main navigation)
                            else if (category === 'reports' ||
                                    selector.includes('app-item') ||
                                    selector.includes('report') ||
                                    element.closest('.navigation-pane') ||
                                    dataId?.includes('report') ||
                                    dataId?.includes('app')) {
                                elementType = 'report';
                                isClickable = true;
                                debugInfo.reports.push({ text: displayText, element });
                                console.log(`📊 Found REPORT: "${displayText}" (selector: ${selector})`);
                            }
                            // Check general clickability
                            else if (element.onclick || 
                                    element.getAttribute('role') === 'button' ||
                                    element.getAttribute('role') === 'menuitem' ||
                                    element.tagName === 'BUTTON' ||
                                    element.tagName === 'A' ||
                                    element.classList.contains('nav-item') ||
                                    element.classList.contains('tab-item') ||
                                    element.classList.contains('menu-item') ||
                                    element.style.cursor === 'pointer' ||
                                    window.getComputedStyle(element).cursor === 'pointer') {
                                isClickable = true;
                                elementType = 'navigation';
                                debugInfo.tabs.push({ text: displayText, element });
                                console.log(`🔗 Found CLICKABLE: "${displayText}" (selector: ${selector})`);
                            }
                            
                            // Log all text elements for debugging
                            debugInfo.allTextElements.push({
                                text: displayText,
                                selector: selector,
                                element: element,
                                type: elementType,
                                isClickable: isClickable
                            });
                            
                            if (isClickable) {
                                debugInfo.clickableElements.push({
                                    text: displayText,
                                    selector: selector,
                                    element: element,
                                    type: elementType
                                });
                            }
                            
                            // Analyze for your specific app structure
                            const elementInfo = analyzeElementWithType(element, displayText, elementType);
                            if (elementInfo) {
                                allElements.push(elementInfo);
                            }
                        }
                    });
                } catch (e) {
                    console.log(`⚠️ Error scanning selector ${selector}:`, e.message);
                }
            });
        });
        
        // ENHANCED debugging output with PAGE vs REPORT distinction
        console.log('🔍 POWER BI SCAN RESULTS:');
        console.log(`📊 Total elements scanned: ${debugInfo.totalScanned}`);
        console.log(`🎯 Clickable elements found: ${debugInfo.clickableElements.length}`);
        console.log(`� Pages detected: ${debugInfo.pages.length}`);
        console.log(`📊 Reports detected: ${debugInfo.reports.length}`);
        console.log(`�📝 All text elements: ${debugInfo.allTextElements.length}`);
        
        // Log PAGES specifically
        if (debugInfo.pages.length > 0) {
            console.log('📄 DETECTED PAGES:');
            debugInfo.pages.forEach(page => {
                console.log(`  📄 PAGE: "${page.text}"`);
            });
        }
        
        // Log REPORTS specifically  
        if (debugInfo.reports.length > 0) {
            console.log('📊 DETECTED REPORTS:');
            debugInfo.reports.forEach(report => {
                console.log(`  📊 REPORT: "${report.text}"`);
            });
        }
        
        // Log all clickable elements that might contain analytics-related text
        console.log('🔍 ANALYTICS-RELATED CLICKABLE ELEMENTS:');
        debugInfo.clickableElements.forEach(item => {
            const text = item.text.toLowerCase();
            if (text.includes('analytics') || text.includes('location') || 
                text.includes('website') || text.includes('operations') || 
                text.includes('consumer') || text.includes('traffic')) {
                console.log(`  ✅ ${item.type.toUpperCase()}: "${item.text}" (${item.selector})`);
            }
        });
        
        // Log ALL text elements that contain your keywords (even if not clickable)
        console.log('🔍 ALL ELEMENTS WITH YOUR KEYWORDS:');
        debugInfo.allTextElements.forEach(item => {
            const text = item.text.toLowerCase();
            if (text.includes('location') || text.includes('website') || 
                text.includes('operations') || text.includes('analytics')) {
                const isClickable = debugInfo.clickableElements.some(c => c.text === item.text);
                console.log(`  📋 ${item.type.toUpperCase()}: "${item.text}" (${item.selector}) - Clickable: ${isClickable}`);
            }
        });
        
        // Special search for "Location Analytics" specifically
        console.log('🎯 SEARCHING SPECIFICALLY FOR "LOCATION ANALYTICS":');
        debugInfo.allTextElements.forEach(item => {
            const text = item.text.toLowerCase();
            if (text.includes('location') && text.includes('analytics')) {
                const isClickable = debugInfo.clickableElements.some(c => c.text === item.text);
                console.log(`  🎯 FOUND: "${item.text}" - Type: ${item.type} - Clickable: ${isClickable} - Selector: ${item.selector}`);
            }
        });
        
        // Remove duplicates based on text content
        const uniqueElements = [];
        const seenTexts = new Set();
        
        allElements.forEach(item => {
            const key = item.name.toLowerCase();
            if (!seenTexts.has(key)) {
                seenTexts.add(key);
                uniqueElements.push(item);
            }
        });
        
        console.log(`📊 FINAL NAVIGATION ELEMENTS: ${uniqueElements.length}`);
        const pageElements = uniqueElements.filter(item => item.type === 'page');
        const reportElements = uniqueElements.filter(item => item.type === 'report');
        const otherElements = uniqueElements.filter(item => !['page', 'report'].includes(item.type));
        
        console.log('🏷️ CLASSIFICATION SUMMARY:');
        console.log(`📊 Reports: ${reportElements.length} (items containing "report")`);
        console.log(`📄 Pages: ${pageElements.length} (items without "report")`);
        console.log(`🔗 Other: ${otherElements.length}`);
        
        if (reportElements.length > 0) {
            console.log('� REPORTS DETECTED (contain "report"):');
            reportElements.forEach(item => {
                console.log(`  � "${item.name}" (${item.classification})`);
            });
        }
        
        if (pageElements.length > 0) {
            console.log('� PAGES DETECTED (no "report" keyword):');
            pageElements.forEach(item => {
                console.log(`  � "${item.name}" (${item.classification})`);
            });
        }
        
        if (otherElements.length > 0) {
            console.log('🔗 OTHER NAVIGATION:');
            otherElements.forEach(item => {
                console.log(`  🔗 ${item.name} (${item.type})`);
            });
        }
        
        return uniqueElements;
    }
    
    // SIMPLE element analyzer with minimal UI filtering
    function analyzeElementWithType(element, text, detectedType) {
        const normalizedText = text.toLowerCase();
        
        // Skip empty or very short text
        if (!text || text.trim().length < 2) {
            return null;
        }
        
        // MINIMAL filtering - only exclude obvious UI clutter
        const excludeUIClutter = [
            'go back', 'data updated', 'demo project', 'power bi report'
        ];
        
        // Skip if it's obvious UI clutter
        if (excludeUIClutter.some(pattern => normalizedText.includes(pattern))) {
            return null;
        }
        
        // Skip if text is too long (likely concatenated elements)
        if (normalizedText.length > 100) {
            return null;
        }
        
        // Skip if text has too few letters (likely numbers/symbols)
        const alphaRatio = (normalizedText.match(/[a-zA-Z]/g) || []).length / normalizedText.length;
        if (alphaRatio < 0.3) {
            return null;
        }
        
        // SIMPLE LOGIC: If text contains "report" anywhere, it's a REPORT
        // Otherwise, it's a PAGE
        let finalType = 'page'; // Default to page
        
        if (normalizedText.includes('report')) {
            finalType = 'report';
            console.log(`📊 REPORT detected: "${text}" (contains "report")`);
        } else {
            finalType = 'page';
            console.log(`📄 PAGE detected: "${text}" (no "report" keyword)`);
        }
        
        return {
            element: element,
            name: text,
            type: finalType,
            normalizedName: normalizedText,
            selector: getElementSelector(element),
            domType: detectedType, // Keep track of what DOM analysis detected
            classification: finalType === 'report' ? 'Contains "report" keyword' : 'Default to page (no "report" keyword)'
        };
    }
    
    // Get a unique selector for an element
    function getElementSelector(element) {
        if (element.id) return `#${element.id}`;
        if (element.className) return `.${element.className.split(' ')[0]}`;
        return element.tagName.toLowerCase();
    }
    
    // Calculate match quality percentage between target and found element
    function calculateMatchQuality(targetWords, foundWords) {
        if (targetWords.length === 0 || foundWords.length === 0) return 0;
        
        let matchedWords = 0;
        let totalScore = 0;
        
        for (const targetWord of targetWords) {
            let bestMatch = 0;
            for (const foundWord of foundWords) {
                if (targetWord === foundWord) {
                    bestMatch = 100; // Perfect word match
                    break;
                } else if (foundWord.includes(targetWord)) {
                    bestMatch = Math.max(bestMatch, 80);
                } else if (targetWord.includes(foundWord)) {
                    bestMatch = Math.max(bestMatch, 70);
                }
            }
            if (bestMatch > 0) {
                matchedWords++;
                totalScore += bestMatch;
            }
        }
        
        // Calculate percentage: (average score of matched words) * (percentage of words matched)
        const averageScore = matchedWords > 0 ? totalScore / matchedWords : 0;
        const wordCoverage = matchedWords / targetWords.length;
        
        return Math.round(averageScore * wordCoverage);
    }
    
    // Enhanced navigation matching for your app structure with precise matching
    function findBestNavigationMatch(target, elements) {
        const targetLower = target.toLowerCase();
        console.log(`🎯 Searching for: "${target}" in ${elements.length} elements`);
        
        // Log all available elements for debugging
        console.log('📋 Available elements:', elements.map(e => `"${e.name}" (${e.type})`));
        
        // Priority 1: Exact match
        for (const item of elements) {
            if (item.normalizedName === targetLower) {
                console.log(`✅ Exact match found: ${item.name}`);
                return item;
            }
        }
        
        // Priority 2: Ultra-precise keyword matching for your app structure
        const specificMatches = [];
        
        // STRICT matching - must contain EXACT keywords
        if (targetLower.includes('location')) {
            console.log('🔍 Looking for LOCATION analytics specifically...');
            for (const item of elements) {
                const itemLower = item.normalizedName;
                // Must contain "location" AND "analytics" but NOT "operations"
                if (itemLower.includes('location') && itemLower.includes('analytics') && !itemLower.includes('operations')) {
                    specificMatches.push({ item, priority: 10, reason: 'EXACT location analytics match' });
                    console.log(`✅ Found exact Location Analytics: "${item.name}"`);
                }
            }
        }
        
        if (targetLower.includes('website') && !targetLower.includes('location') && !targetLower.includes('operations')) {
            console.log('🔍 Looking for WEBSITE analytics specifically...');
            for (const item of elements) {
                const itemLower = item.normalizedName;
                // Must contain "website" AND "analytics" but NOT "operations" or "location"
                if (itemLower.includes('website') && itemLower.includes('analytics') && 
                    !itemLower.includes('operations') && !itemLower.includes('location')) {
                    specificMatches.push({ item, priority: 10, reason: 'EXACT website analytics match' });
                    console.log(`✅ Found exact Website Analytics: "${item.name}"`);
                }
            }
        }
        
        if (targetLower.includes('operations') && !targetLower.includes('location') && !targetLower.includes('website')) {
            console.log('🔍 Looking for OPERATIONS analytics specifically...');
            for (const item of elements) {
                const itemLower = item.normalizedName;
                // Must contain "operations" AND "analytics" but NOT "location" or "website"
                if (itemLower.includes('operations') && itemLower.includes('analytics') && 
                    !itemLower.includes('location') && !itemLower.includes('website')) {
                    specificMatches.push({ item, priority: 10, reason: 'EXACT operations analytics match' });
                    console.log(`✅ Found exact Operations Analytics: "${item.name}"`);
                }
            }
        }
        
        if (targetLower.includes('consumer') || targetLower.includes('traffic') || targetLower.includes('cwt')) {
            console.log('🔍 Looking for CONSUMER/TRAFFIC/CWT report specifically...');
            for (const item of elements) {
                const itemLower = item.normalizedName;
                if ((itemLower.includes('consumer') || itemLower.includes('traffic') || itemLower.includes('cwt')) && 
                    (itemLower.includes('website') || itemLower.includes('report'))) {
                    specificMatches.push({ item, priority: 10, reason: 'EXACT consumer/traffic/cwt match' });
                    console.log(`✅ Found exact Consumer Website Traffic/CWT: "${item.name}"`);
                }
            }
        }
        
        // Return ONLY if we have a high-priority exact match
        if (specificMatches.length > 0) {
            const bestSpecific = specificMatches.sort((a, b) => b.priority - a.priority)[0];
            console.log(`✅ EXACT MATCH FOUND: ${bestSpecific.item.name} (${bestSpecific.reason})`);
            return bestSpecific.item;
        }
        
        // If no exact match found for location/website/operations, STOP HERE - don't fall back to fuzzy matching
        if (targetLower.includes('location') || targetLower.includes('website') || targetLower.includes('operations')) {
            console.log(`❌ NO EXACT MATCH for "${target}" - not using fuzzy matching to avoid confusion`);
            return null;
        }
        
        // Priority 3: Enhanced word-based matching with stricter criteria
        const targetWords = targetLower.split(/\s+/).filter(word => word.length > 2);
        const scoredMatches = [];
        
        for (const item of elements) {
            const itemWords = item.normalizedName.split(/\s+/).filter(word => word.length > 2);
            let score = 0;
            let matchedWords = 0;
            
            // Calculate precise match score
            for (const targetWord of targetWords) {
                let bestWordScore = 0;
                for (const itemWord of itemWords) {
                    let wordScore = 0;
                    
                    // Exact word match gets highest score
                    if (targetWord === itemWord) {
                        wordScore = 100;
                    }
                    // Word contains target (but not just "analytics" matching everything)
                    else if (itemWord.includes(targetWord) && targetWord !== 'analytics') {
                        wordScore = targetWord.length * 10;
                    }
                    // Target contains word (but not just "analytics")
                    else if (targetWord.includes(itemWord) && itemWord !== 'analytics') {
                        wordScore = itemWord.length * 8;
                    }
                    
                    if (wordScore > bestWordScore) {
                        bestWordScore = wordScore;
                    }
                }
                
                if (bestWordScore > 0) {
                    matchedWords++;
                    score += bestWordScore;
                }
            }
            
            // Only consider items that match at least half the target words
            // and have a minimum score threshold
            if (matchedWords >= Math.ceil(targetWords.length / 2) && score > 50) {
                scoredMatches.push({ item, score, matchedWords });
                console.log(`🔍 Candidate: "${item.name}" - Score: ${score}, Matched words: ${matchedWords}`);
            }
        }
        
        // Return best match if any, but only if it's significantly better
        if (scoredMatches.length > 0) {
            scoredMatches.sort((a, b) => {
                // First sort by number of matched words, then by score
                if (a.matchedWords !== b.matchedWords) {
                    return b.matchedWords - a.matchedWords;
                }
                return b.score - a.score;
            });
            
            const bestMatch = scoredMatches[0];
            console.log(`✅ Best match found: ${bestMatch.item.name} (score: ${bestMatch.score}, words: ${bestMatch.matchedWords})`);
            return bestMatch.item;
        }
        
        // Priority 4: Simple contains match as last resort (but avoid "analytics" only matches)
        for (const item of elements) {
            if (targetLower !== 'analytics' && item.normalizedName.includes(targetLower)) {
                console.log(`✅ Contains match found: ${item.name}`);
                return item;
            }
        }
        
        console.log(`❌ No match found for: ${target}`);
        return null;
    }
    
    // Format available items for user display
    function formatAvailableItems(elements) {
        const reports = elements.filter(e => e.type === 'report');
        const pages = elements.filter(e => e.type === 'page');
        const others = elements.filter(e => e.type === 'element');
        
        let result = '📋 Available Items:\n\n';
        
        if (reports.length > 0) {
            result += `📊 Reports (${reports.length}):\n`;
            reports.forEach(r => result += `• ${r.name}\n`);
            result += '\n';
        }
        
        if (pages.length > 0) {
            result += `📄 Pages (${pages.length}):\n`;
            pages.forEach(p => result += `• ${p.name}\n`);
            result += '\n';
        }
        
        if (others.length > 0 && others.length < 10) {
            result += `🔗 Other Elements (${others.length}):\n`;
            others.slice(0, 5).forEach(o => result += `• ${o.name}\n`);
        }
        
        return result;
    }

    // Enhanced target extraction for your app structure
    function extractTarget(command) {
        let target = command
            .replace(/show me|open|go to|navigate to|switch to|display|view|show/gi, '')
            .replace(/the |a |an |page|report/gi, '')
            .replace(/[\.!?,:;]/g, '') // Remove punctuation
            .replace(/\s+/g, ' ')
            .trim();
        
        console.log(`🎯 Original command: "${command}" → Extracted target: "${target}"`);
        
        // Precise normalization for your app structure
        const targetLower = target.toLowerCase();
        
        // Handle abbreviations first
        if (targetLower === 'cwt' || targetLower.includes('cwt')) {
            target = 'consumer website traffic';
            console.log(`🎯 CWT abbreviation detected → "${target}"`);
        }
        // Handle exact matches for your specific pages/reports
        else if (targetLower.includes('location') && targetLower.includes('analytics')) {
            target = 'location analytics';
        } else if (targetLower.includes('website') && targetLower.includes('analytics')) {
            target = 'website analytics';
        } else if (targetLower.includes('operations') && targetLower.includes('analytics')) {
            target = 'operations analytics';
        } else if (targetLower.includes('consumer') || (targetLower.includes('website') && targetLower.includes('traffic'))) {
            target = 'consumer website traffic';
        }
        // Handle single word cases
        else if (targetLower === 'location') {
            target = 'location analytics';
        } else if (targetLower === 'website') {
            target = 'website analytics';
        } else if (targetLower === 'operations') {
            target = 'operations analytics';
        } else if (targetLower === 'consumer' || targetLower === 'traffic') {
            target = 'consumer website traffic';
        }
        
        console.log(`🎯 Final normalized target: "${target}"`);
        return target;
    }

    // Find element by name
    function findElementByName(target, elements) {
        const targetLower = target.toLowerCase();
        
        // Exact match
        for (const element of elements) {
            const text = element.textContent.trim().toLowerCase();
            if (text === targetLower) {
                return element;
            }
        }
        
        // Partial match
        for (const element of elements) {
            const text = element.textContent.trim().toLowerCase();
            if (text.includes(targetLower) || targetLower.includes(text)) {
                return element;
            }
        }
        
        return null;
    }

    // ========================================
    // POWER BI FILTERING FUNCTIONS
    // ========================================
    
    // Handle filter commands like "Filter by Location New York" or "Show data for Product A"
    function handleFilterCommand(normalizedCommand, originalCommand) {
        console.log(`🔍 STARTING handleFilterCommand`);
        console.log(`📋 Original command: "${originalCommand}"`);
        console.log(`📋 Normalized command: "${normalizedCommand}"`);
        
        try {
            // Extract filter criteria from the command
            console.log(`🎯 Step 1: Extracting filter criteria...`);
            const filterCriteria = extractFilterCriteria(normalizedCommand);
            console.log(`✅ Filter criteria extracted:`, filterCriteria);
            
            if (filterCriteria.field && filterCriteria.value) {
                console.log(`🎯 Step 2: Scanning for Power BI filters...`);
                
                // Update user with progress
                setTimeout(() => {
                    addMessage(`📊 Found field: "${filterCriteria.field}" with value: "${filterCriteria.value}"\n\n🔍 Scanning Power BI filters...`, 'bot');
                }, 100);
                
                // Scan for filter elements in Power BI
                const filterElements = scanPowerBIFilters();
                console.log(`✅ Filter scan complete: ${filterElements.length} filters found`);
                
                console.log(`🎯 Step 3: Finding matching filter for "${filterCriteria.field}"...`);
                
                // Find matching filter
                const matchingFilter = findMatchingFilter(filterCriteria.field, filterElements);
                console.log(`🔍 Matching filter result:`, matchingFilter ? `Found: "${matchingFilter.name}"` : 'No match found');
                
                if (matchingFilter) {
                    console.log(`✅ Step 4: Applying filter...`);
                    applyFilter(matchingFilter, filterCriteria.value, originalCommand);
                } else {
                    console.log(`❌ Step 4: No matching filter found - showing available filters`);
                    // Show available filters
                    showAvailableFilters(filterElements, filterCriteria.field);
                }
            } else {
                console.log(`❌ Invalid filter criteria - missing field or value`);
                addMessage(`🔍 Filter Command Help:\n\nTry these command formats:\n• "Filter region Asia Pacific" ← YOUR FORMAT\n• "Filter by Location New York"\n• "Show data for Region East"\n• "Apply filter Category Electronics"\n• "Region equals Asia Pacific"\n\n💡 Supported Formats:\n• "Filter [field] [value]"\n• "Filter by [field] [value]"\n• "Show data for [field] [value]"\n\n🔍 Scanning for available filters...`, 'bot');
                
                // Also trigger a filter scan to show what's available
                setTimeout(() => {
                    const filterElements = scanPowerBIFilters();
                    showAvailableFilters(filterElements, 'help');
                }, 1000);
            }
        } catch (error) {
            console.error('❌ Error in handleFilterCommand:', error);
            addMessage(`❌ Error processing filter command: ${error.message}\n\nPlease try again or check the browser console for details.`, 'bot');
        }
    }
    
    // Handle individual filter reset commands - UPDATED to use enhanced function
    async function handleResetFilterCommandOld(normalizedCommand, originalCommand) {
        console.log(`🔄 Processing reset filter command: "${originalCommand}"`);
        
        // Extract filter name to reset
        const filterName = extractFilterNameToReset(normalizedCommand);
        
        if (filterName) {
            // Use the enhanced reset function
            const success = await handleResetFilterCommand(filterName);
            
            if (!success) {
                // Fallback to old method if enhanced fails
                const filterElements = scanPowerBIFilters();
                const matchingFilter = findMatchingFilter(filterName, filterElements);
                
                if (matchingFilter) {
                    resetIndividualFilter(matchingFilter, originalCommand);
                } else {
                    showAvailableFilters(filterElements, filterName);
                }
            }
        } else {
            addMessage(`🔄 Reset Filter Help:\n\nTry commands like:\n• "Reset Location filter"\n• "Clear Category filter"\n• "Remove Region filter"\n\n💡 Format: "Reset [filter name] filter"`, 'bot');
        }
    }
    
    // Enhanced individual filter reset function
    async function handleResetFilterCommand(filterName) {
        console.log(`🔄 Starting handleResetFilterCommand for: "${filterName}"`);
        
        // Provide immediate user feedback
        addMessage(`🔍 Looking for "${filterName}" filter to clear...`, 'bot');
        
        try {
            // Use existing filter scanning function
            console.log(`🔍 Calling scanPowerBIFilters()...`);
            const filterElements = scanPowerBIFilters();
            console.log(`🔍 Found ${filterElements.length} filter elements to search`);
            
            if (filterElements.length === 0) {
                addMessage(`❌ No filter elements found on this page.\n\n💡 Make sure you're on a Power BI report with filters/slicers.`, 'bot');
                return false;
            }
            
            // Find matching filter using existing function
            console.log(`🔍 Calling findMatchingFilter("${filterName}", filterElements)...`);
            const matchingFilter = findMatchingFilter(filterName, filterElements);
            
            if (matchingFilter) {
                console.log(`✅ Found matching filter: "${matchingFilter.name}"`);
                addMessage(`✅ Found "${matchingFilter.name}" filter! Attempting to clear it...`, 'bot');
                
                // Use existing resetIndividualFilter function
                console.log(`🔄 Calling resetIndividualFilter...`);
                resetIndividualFilter(matchingFilter, `clear ${filterName} filter`);
                return true;
            } else {
                console.log(`❌ No matching filter found for: "${filterName}"`);
                
                // Show available filters
                addMessage(`❌ Could not find "${filterName}" filter.\n\n🔍 Let me show you what filters are available...`, 'bot');
                
                // Use existing function to show available filters
                setTimeout(() => {
                    showAvailableFilters(filterElements, filterName);
                }, 1000);
                
                return false;
            }
        } catch (error) {
            console.error("❌ Error resetting filter:", error);
            addMessage(`❌ Error resetting "${filterName}" filter: ${error.message}\n\nPlease check the browser console for more details.`, 'bot');
            return false;
        }
    }
    
    // Helper function to find reset button within a filter container
    function findFilterResetButton(filterContainer) {
        const resetSelectors = [
            '[aria-label*="clear"]',
            '[aria-label*="reset"]', 
            '[aria-label*="remove"]',
            '[title*="clear"]',
            '[title*="reset"]',
            '[title*="remove"]',
            'button[class*="clear"]',
            'button[class*="reset"]',
            '.clear-button',
            '.reset-button',
            '.remove-filter'
        ];
        
        for (const selector of resetSelectors) {
            const button = filterContainer.querySelector(selector);
            if (button) {
                console.log(`🔍 Found reset button with selector: ${selector}`);
                return button;
            }
        }
        
        // Look for X buttons or clear icons
        const clearIcons = filterContainer.querySelectorAll('*');
        for (const icon of clearIcons) {
            const text = (icon.textContent || '').trim();
            const ariaLabel = icon.getAttribute('aria-label') || '';
            const title = icon.getAttribute('title') || '';
            
            if (text === '×' || text === '✕' || text === '✗' || 
                ariaLabel.includes('clear') || ariaLabel.includes('remove') ||
                title.includes('clear') || title.includes('remove')) {
                console.log(`🔍 Found clear icon: "${text || ariaLabel || title}"`);
                return icon;
            }
        }
        
        return null;
    }
    
    // Helper function to clear filter selection
    async function clearFilterSelection(filterContainer) {
        // Try to find and uncheck selected items
        const selectedItems = filterContainer.querySelectorAll('[aria-selected="true"], .selected, input[type="checkbox"]:checked');
        
        if (selectedItems.length > 0) {
            console.log(`🔄 Clearing ${selectedItems.length} selected items`);
            
            for (const item of selectedItems) {
                await simulateClick(item);
                await delay(100);
            }
            
            return true;
        }
        
        // Try to click on "Select All" to deselect everything
        const selectAllButton = filterContainer.querySelector('[aria-label*="select all"], [title*="select all"]');
        if (selectAllButton) {
            console.log(`🔄 Using "Select All" to clear selections`);
            await simulateClick(selectAllButton);
            await delay(200);
            await simulateClick(selectAllButton); // Click twice to deselect all
            return true;
        }
        
        return false;
    }
    
    // ENHANCED reset all filters command - multiple strategies
    function handleResetAllFiltersCommand() {
        console.log('🔄 Processing UNIVERSAL reset all filters command');
        addMessage('🔄 Resetting all filters...\n\n🔍 Scanning for reset options...', 'bot');
        
        // Strategy 1: Find Power BI reset buttons
        const resetButtons = scanUniversalResetButtons();
        
        if (resetButtons.length > 0) {
            const resetAllButton = findBestResetAllButton(resetButtons);
            
            if (resetAllButton) {
                console.log(`✅ Found reset all button: "${resetAllButton.text}"`);
                resetAllButton.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                setTimeout(() => {
                    resetAllButton.element.click();
                    addMessage('🔄 All filters have been reset!\n\n✅ The report now shows all data without any filters applied.', 'bot');
                }, 1000);
                return;
            }
        }
        
        // Strategy 2: Try keyboard shortcut (Ctrl+Shift+R for Power BI reset)
        console.log('🔄 Trying keyboard shortcut for reset...');
        document.dispatchEvent(new KeyboardEvent('keydown', {
            key: 'r',
            keyCode: 82,
            ctrlKey: true,
            shiftKey: true,
            bubbles: true
        }));
        
        setTimeout(() => {
            // Strategy 3: Reset individual filters one by one
            console.log('🔄 Falling back to individual filter reset...');
            resetAllFiltersIndividuallyEnhanced();
        }, 2000);
    }
    
    // ENHANCED reset report command - restores default view with multiple strategies
    function handleResetReportCommand() {
        console.log('🔄 Processing RESET REPORT command');
        addMessage('🔄 Resetting report to default view...\n\n🔍 Searching for reset options...', 'bot');
        
        // Strategy 1: Look for Power BI "Reset to default" buttons
        const resetReportButtons = scanResetReportButtons();
        
        if (resetReportButtons.length > 0) {
            const bestResetButton = findBestResetReportButton(resetReportButtons);
            
            if (bestResetButton) {
                console.log(`✅ Found reset to default button: "${bestResetButton.text}"`);
                bestResetButton.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                setTimeout(() => {
                    bestResetButton.element.click();
                    addMessage('✅ Report reset to default view!\n\n🔄 All filters cleared and visuals restored to original state.\n\n📊 You\'re now viewing the default dashboard configuration.', 'bot');
                }, 1000);
                return;
            }
        }
        
        // Strategy 2: Try Power BI keyboard shortcuts for reset
        console.log('🔄 Trying Power BI reset shortcuts...');
        
        // Try Ctrl+Alt+R (Power BI reset shortcut)
        document.dispatchEvent(new KeyboardEvent('keydown', {
            key: 'r',
            keyCode: 82,
            ctrlKey: true,
            altKey: true,
            bubbles: true
        }));
        
        // Also try Ctrl+Shift+R (alternative reset)
        setTimeout(() => {
            document.dispatchEvent(new KeyboardEvent('keydown', {
                key: 'r',
                keyCode: 82,
                ctrlKey: true,
                shiftKey: true,
                bubbles: true
            }));
        }, 500);
        
        // Strategy 3: Page refresh as fallback
        setTimeout(() => {
            console.log('🔄 Trying page refresh as fallback...');
            
            // Ask user for confirmation before refresh
            const confirmRefresh = confirm('No "Reset to Default" button found. Would you like to refresh the page to restore the default view?\n\nNote: This will reload the entire page.');
            
            if (confirmRefresh) {
                addMessage('🔄 Refreshing page to restore default view...', 'bot');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            } else {
                addMessage('❌ Report reset cancelled.\n\n💡 Try these alternatives:\n• "Reset all filters" - to clear all filters\n• Look for "Reset to default" button in Power BI menu\n• Manually refresh the page', 'bot');
            }
        }, 2000);
    }
    
    // Scan for reset report buttons in Power BI
    function scanResetReportButtons() {
        console.log('🔍 Scanning for reset report buttons...');
        
        const resetButtons = [];
        
        // Power BI reset to default selectors
        const resetSelectors = [
            // Reset to default buttons
            '[aria-label*="reset"]', '[title*="reset"]',
            '[aria-label*="Reset"]', '[title*="Reset"]',
            '[aria-label*="default"]', '[title*="default"]',
            '[aria-label*="Default"]', '[title*="Default"]',
            '[aria-label*="restore"]', '[title*="restore"]',
            '[aria-label*="Restore"]', '[title*="Restore"]',
            
            // Power BI specific reset buttons
            '[data-automation-id*="reset"]', '[data-testid*="reset"]',
            '[data-automation-id*="default"]', '[data-testid*="default"]',
            '[data-automation-id*="restore"]', '[data-testid*="restore"]',
            
            // Menu and toolbar buttons
            '.toolbar button', '.menu-item', '.dropdown-item',
            '[role="menuitem"]', '[role="button"]',
            
            // Text-based reset options
            'button', 'a[href*="reset"]', 'span[role="button"]'
        ];
        
        resetSelectors.forEach(selector => {
            try {
                const elements = document.querySelectorAll(selector);
                elements.forEach(element => {
                    const text = element.textContent?.toLowerCase().trim() || '';
                    const ariaLabel = element.getAttribute('aria-label')?.toLowerCase() || '';
                    const title = element.getAttribute('title')?.toLowerCase() || '';
                    
                    // Check if it's a reset/default/restore button
                    const isResetButton = text.includes('reset') || text.includes('default') || text.includes('restore') ||
                                         ariaLabel.includes('reset') || ariaLabel.includes('default') || ariaLabel.includes('restore') ||
                                         title.includes('reset') || title.includes('default') || title.includes('restore');
                    
                    // Check if it's related to report/page reset (not just filters)
                    const isReportReset = text.includes('report') || text.includes('page') || text.includes('view') ||
                                         ariaLabel.includes('report') || ariaLabel.includes('page') || ariaLabel.includes('view') ||
                                         title.includes('report') || title.includes('page') || title.includes('view') ||
                                         text.includes('to default') || ariaLabel.includes('to default') || title.includes('to default');
                    
                    if (isResetButton && (isReportReset || text.includes('reset to default') || ariaLabel.includes('reset to default'))) {
                        const buttonInfo = {
                            element: element,
                            text: text || ariaLabel || title || 'Reset button',
                            selector: selector,
                            priority: calculateResetButtonPriority(text, ariaLabel, title)
                        };
                        
                        console.log(`📋 Found reset button: "${buttonInfo.text}" (priority: ${buttonInfo.priority})`);
                        resetButtons.push(buttonInfo);
                    }
                });
            } catch (error) {
                console.log(`⚠️ Error scanning selector ${selector}:`, error.message);
            }
        });
        
        console.log(`✅ Found ${resetButtons.length} potential reset report buttons`);
        return resetButtons;
    }
    
    // Calculate priority for reset buttons
    function calculateResetButtonPriority(text, ariaLabel, title) {
        let priority = 0;
        const allText = (text + ' ' + ariaLabel + ' ' + title).toLowerCase();
        
        // Higher priority for more specific reset terms
        if (allText.includes('reset to default')) priority += 10;
        if (allText.includes('restore default')) priority += 9;
        if (allText.includes('reset report')) priority += 8;
        if (allText.includes('reset page')) priority += 7;
        if (allText.includes('default view')) priority += 6;
        if (allText.includes('original view')) priority += 5;
        if (allText.includes('reset')) priority += 3;
        if (allText.includes('default')) priority += 2;
        if (allText.includes('restore')) priority += 2;
        
        return priority;
    }
    
    // Find the best reset report button
    function findBestResetReportButton(resetButtons) {
        if (resetButtons.length === 0) return null;
        
        // Sort by priority (highest first)
        resetButtons.sort((a, b) => b.priority - a.priority);
        
        // Return the highest priority visible button
        for (const button of resetButtons) {
            if (button.element.offsetWidth > 0 && button.element.offsetHeight > 0) {
                console.log(`✅ Selected best reset button: "${button.text}" (priority: ${button.priority})`);
                return button;
            }
        }
        
        // If no visible buttons, return the highest priority one anyway
        console.log(`⚠️ No visible reset buttons, using highest priority: "${resetButtons[0].text}"`);
        return resetButtons[0];
    }
    
    // Scan for Power BI filter elements
    function scanPowerBIFilters() {
        console.log('🔍 Scanning for Power BI filter elements...');
        
        const filterElements = [];
        
        // ENHANCED Power BI filter selectors for visual detection
        const filterSelectors = [
            // Power BI Visual Containers (where slicers live)
            '.visual-container-component', '.visual-container', '.visualContainer',
            '.visual', '.visuals', '.reportVisual', '.visual-modern',
            
            // Slicer specific selectors
            '.slicer', '.slicerContainer', '.slicer-container', '.slicer-visual',
            '[data-automation-id*="slicer"]', '.visual-slicer',
            '.slicerHeaderText', '.slicerText', '.slicerBody',
            
            // Filter pane elements
            '.filter-pane', '.filters-pane', '.filterPane', '.filter-container',
            '.filter-card', '.filter-item', '.filterCard', '.filterHeader',
            '[data-automation-id*="filter"]', '[data-testid*="filter"]',
            
            // Visual titles and headers (often contain filter names)
            '.visual-title', '.visualTitle', '.chart-title', '.title-text',
            '.visual-header', '.visualHeader', '.vcHeaderText',
            
            // Interactive elements within visuals
            '[role="button"]', '[role="combobox"]', '[role="listbox"]',
            '[role="menuitem"]', '[aria-label*="filter"]',
            
            // Power BI specific data attributes
            '[data-automation-id]', '[data-testid]', '[data-visual-type]',
            
            // Date/time pickers
            '.date-picker', '.time-picker', '.dateTimePicker',
            
            // Search and input elements
            '.filter-search', '.search-box', 'input[placeholder*="Search"]',
            'input[type="text"]', 'input[aria-label]'
        ];
        
        // PRIORITIZED scanning - scan most specific selectors first
        const prioritizedSelectors = [
            // High priority: Specific slicer elements
            { selectors: ['.slicer', '.slicerContainer', '.slicer-container', '[data-automation-id*="slicer"]'], priority: 10 },
            // Medium priority: Filter pane elements
            { selectors: ['.filter-pane', '.filters-pane', '.filter-card', '[data-automation-id*="filter"]'], priority: 8 },
            // Lower priority: Visual containers (more general)
            { selectors: ['.visual-container', '.visual', '[data-visual-type]'], priority: 5 },
            // Lowest priority: Generic elements
            { selectors: ['[role="button"]', '[aria-label*="filter"]', '.visual-title'], priority: 2 }
        ];
        
        const foundFilters = new Map(); // Use Map to avoid duplicates
        
        for (const group of prioritizedSelectors) {
            for (const selector of group.selectors) {
                try {
                    const elements = document.querySelectorAll(selector);
                    if (elements.length > 0) {
                        console.log(`📋 Found ${elements.length} elements for filter selector: ${selector} (priority ${group.priority})`);
                    }
                    
                    elements.forEach(element => {
                        const filterInfo = analyzeFilterElement(element, selector);
                        if (filterInfo && filterInfo.name && filterInfo.name.length <= 100) { // Limit name length
                            const key = filterInfo.name.toLowerCase().trim();
                            
                            // Only add if we don't have this filter or if this one has higher priority
                            if (!foundFilters.has(key) || foundFilters.get(key).priority < group.priority) {
                                filterInfo.priority = group.priority;
                                foundFilters.set(key, filterInfo);
                                console.log(`✅ Filter detected: "${filterInfo.name}" (${filterInfo.type}, priority ${group.priority}) - Interactive: ${filterInfo.isInteractive}`);
                            }
                        }
                    });
                } catch (e) {
                    console.log(`⚠️ Error scanning filter selector ${selector}:`, e.message);
                }
            }
        }
        
        // Convert Map back to array, sorted by priority
        foundFilters.forEach(filter => filterElements.push(filter));
        filterElements.sort((a, b) => (b.priority || 0) - (a.priority || 0));
        
        // FINAL CLEANUP - Remove very similar or poor quality filters
        const cleanedFilters = [];
        const seenNames = new Set();
        
        for (const filter of filterElements) {
            const cleanName = filter.name.toLowerCase().trim();
            
            // Skip if we've seen a very similar name
            let isDuplicate = false;
            for (const seen of seenNames) {
                if (Math.abs(cleanName.length - seen.length) <= 2 && 
                    (cleanName.includes(seen) || seen.includes(cleanName))) {
                    isDuplicate = true;
                    break;
                }
            }
            
            // Only keep high-quality filters
            if (!isDuplicate && 
                filter.name.length >= 3 && 
                filter.name.length <= 50 && 
                !/^(press|enter|explore|data|visual|container)$/i.test(filter.name)) {
                cleanedFilters.push(filter);
                seenNames.add(cleanName);
            }
        }
        
        // Enhanced logging for debugging
        console.log(`🔍 FILTER SCAN COMPLETE: ${cleanedFilters.length} total filters found (${filterElements.length} before cleanup)`);
        
        if (cleanedFilters.length > 0) {
            console.log('📋 CLEANED FILTER LIST:');
            cleanedFilters.forEach((filter, index) => {
                console.log(`  ${index + 1}. "${filter.name}" (${filter.type}, priority ${filter.priority || 0}) - Interactive: ${filter.isInteractive}`);
            });
        } else {
            console.log('❌ NO CLEAN FILTERS DETECTED - Possible reasons:');
            console.log('  • Page still loading');
            console.log('  • No interactive visuals on current page');
            console.log('  • Filters use different CSS classes');
            console.log('  • Need to navigate to a report with slicers');
        }
        
        console.log(`🔍 Final filter count: ${cleanedFilters.length}`);
        return cleanedFilters;
    }
    
    // ENHANCED filter element analyzer for Power BI visuals with PROPER TITLE DETECTION
    function analyzeFilterElement(element, selector) {
        console.log(`🔍 Analyzing element with selector: ${selector}`);
        
        // PRIORITY 1: Look for explicit filter titles/headers FIRST
        let filterTitle = null;
        const visualContainer = element.closest('.visual-container');
        
        if (visualContainer) {
            // Try to find the slicer title specifically
            const titleSelectors = [
                '.slicerHeaderText', '.slicer-header', '.visual-title', '.visualTitle',
                '.vcHeaderText', '.chart-title', '.title-text', '.filterTitle',
                '[data-automation-id*="title"]', '[data-testid*="title"]'
            ];
            
            for (const titleSelector of titleSelectors) {
                const titleElement = visualContainer.querySelector(titleSelector);
                if (titleElement) {
                    filterTitle = titleElement.textContent?.trim();
                    if (filterTitle && filterTitle.length > 1 && filterTitle.length < 50) {
                        console.log(`✅ Found filter title: "${filterTitle}" using selector: ${titleSelector}`);
                        break;
                    }
                }
            }
        }
        
        // PRIORITY 2: Get element text and clean it up
        let text = element.textContent?.trim() || 
                  element.getAttribute('aria-label') || 
                  element.getAttribute('title') || 
                  element.getAttribute('data-automation-id') || '';
        
        // ENHANCED CLEANUP - Detect if text contains multiple values (slicer options)
        if (text && text.length > 0) {
            console.log(`📋 Raw element text: "${text}"`);
            
            // Check if this looks like concatenated slicer options
            const hasMultipleCapitalWords = (text.match(/[A-Z][a-z]+/g) || []).length >= 3;
            const hasCommonSlicerValues = /Desktop|Mobile|Tablet|Asia|Europe|North|America|East|West|Coffee|Customers|Inc|Corp|Ltd|Group/i.test(text);
            
            if (hasMultipleCapitalWords && hasCommonSlicerValues && text.length > 20) {
                console.log(`⚠️ Text appears to be concatenated slicer options: "${text}"`);
                
                // If we found a title above, use that instead
                if (filterTitle) {
                    text = filterTitle;
                    console.log(`✅ Using filter title instead: "${text}"`);
                } else {
                    // Try to extract a meaningful filter name from the concatenated values
                    console.log(`🔍 Attempting to derive filter name from options...`);
                    
                    // Common filter name patterns based on values
                    if (/Desktop.*Mobile.*Tablet/i.test(text)) {
                        text = 'Device Category';
                        console.log(`✅ Detected Device Category filter from values`);
                    } else if (/Asia.*Pacific.*Europe.*North/i.test(text)) {
                        text = 'Region';
                        console.log(`✅ Detected Region filter from values`);
                    } else if (/Coffee.*Customer.*Corp.*Inc/i.test(text)) {
                        text = 'Customer';
                        console.log(`✅ Detected Customer filter from values`);
                    } else if (/Zoom.*Lens.*Accounting.*Camera/i.test(text)) {
                        text = 'Product';
                        console.log(`✅ Detected Product filter from values`);
                    } else {
                        // Try to find a header/title in the visual container
                        const containerTitle = visualContainer?.querySelector('*')?.textContent?.trim();
                        if (containerTitle && containerTitle.length < 30) {
                            text = containerTitle.split(' ').slice(0, 2).join(' ');
                            console.log(`✅ Using container title: "${text}"`);
                        } else {
                            // Last resort - use a generic name based on position or content
                            text = 'Filter';
                            console.log(`⚠️ Using generic name: "Filter"`);
                        }
                    }
                }
            } else {
                // Normal text cleanup for non-concatenated text
                console.log(`✅ Text appears to be a proper filter name: "${text}"`);
                
                // Remove common Power BI prefixes
                text = text.replace(/^Press Enter to explore data/i, '').trim();
                text = text.replace(/^Variance to target visitors by store/i, '').trim();
                
                // Remove duplicate words
                const words = text.split(/\s+/);
                const uniqueWords = [...new Set(words)];
                if (words.length > uniqueWords.length && uniqueWords.length <= 3) {
                    text = uniqueWords.join(' ');
                }
                
                // If still too long, extract meaningful parts
                if (text.length > 50) {
                    const filterPatterns = [
                        /^(Device|Country|Region|Department|Category|Product|Location|Time|Date|Year|Month|Status|Type|Customer|Sales|Revenue|Store|Visitor)(?:\s|$)/i,
                        /\b(Device|Country|Region|Department|Category|Product|Location|Time|Date|Year|Month|Status|Type|Customer|Sales|Revenue|Store|Visitor)\b/i
                    ];
                    
                    for (const pattern of filterPatterns) {
                        const match = text.match(pattern);
                        if (match) {
                            text = match[1];
                            break;
                        }
                    }
                    
                    // If still too long, take first meaningful words
                    if (text.length > 50) {
                        const meaningfulWords = text.split(/\s+/).filter(word => 
                            word.length > 2 && 
                            !['the', 'and', 'for', 'with', 'from', 'data', 'by', 'to'].includes(word.toLowerCase())
                        );
                        text = meaningfulWords.slice(0, 2).join(' ');
                    }
                }
            }
        }
        
        // PRIORITY 3: Use filter title if we found one and element text isn't good
        if (filterTitle && (!text || text === 'Filter' || text.length < 3)) {
            text = filterTitle;
            console.log(`✅ Using found filter title: "${text}"`);
        }
        
        // PRIORITY 4: Check parent elements for context
        const parentText = element.parentElement?.textContent?.trim() || '';
        const visualTitle = visualContainer?.querySelector('.visual-title, .visualTitle')?.textContent?.trim() || '';
        
        // Get the best description - prefer shorter, cleaner text
        const candidates = [text, visualTitle, parentText].filter(t => t && t.length > 0 && t.length < 100);
        const bestText = candidates.reduce((best, current) => {
            if (!best) return current;
            // Prefer shorter names that aren't generic
            if (current.length < best.length && current.length > 2 && !['Filter', 'Visual', 'Container'].includes(current)) {
                return current;
            }
            return best;
        }, '');
        
        if (!bestText || bestText.length < 2) return null;
        
        // Skip if it's just generic text
        const skipTexts = ['visual', 'container', 'filter', 'slicer', 'chart', 'data', 'press enter'];
        if (skipTexts.some(skip => bestText.toLowerCase().includes(skip)) && bestText.length < 15) return null;
        
        // Determine filter type based on multiple factors
        let filterType = 'unknown';
        const visualType = element.getAttribute('data-visual-type') || '';
        
        if (selector.includes('slicer') || visualType.includes('slicer') || element.classList.contains('slicer')) {
            filterType = 'slicer';
        } else if (selector.includes('date') || bestText.toLowerCase().includes('date')) {
            filterType = 'date';
        } else if (selector.includes('dropdown') || selector.includes('combobox') || element.getAttribute('role') === 'combobox') {
            filterType = 'dropdown';
        } else if (selector.includes('search') || element.tagName === 'INPUT') {
            filterType = 'search';
        } else if (selector.includes('visual') || element.closest('.visual-container')) {
            filterType = 'visual';
        } else if (selector.includes('filter')) {
            filterType = 'filter';
        }
        
        // Check if element is actually interactive
        const isInteractive = element.onclick || 
                             element.getAttribute('role') === 'button' ||
                             element.getAttribute('role') === 'combobox' ||
                             element.tagName === 'BUTTON' ||
                             element.tagName === 'INPUT' ||
                             element.style.cursor === 'pointer' ||
                             window.getComputedStyle(element).cursor === 'pointer';
        
        console.log(`🔍 Analyzing filter: "${bestText}" - Type: ${filterType} - Interactive: ${isInteractive}`);
        
        return {
            element: element,
            name: bestText,
            type: filterType,
            selector: selector,
            normalizedName: bestText.toLowerCase(),
            isInteractive: isInteractive,
            visualType: visualType
        };
    }
    
    // Extract filter criteria from command with ENHANCED parsing
    function extractFilterCriteria(command) {
        const criteria = { field: null, value: null };
        
        console.log(`🎯 PARSING COMMAND: "${command}"`);
        console.log(`📋 Command length: ${command.length}, Command type: ${typeof command}`);
        
        // ENHANCED patterns with better multi-word support
        const patterns = [
            // "Filter device category mobile" - handles multi-word field names
            /filter\s+(device\s+category|product\s+category|customer\s+name|store\s+location|time\s+period|date\s+range)\s+(.+)/i,
            
            // Common single-word patterns with improved value capture
            /filter\s+(device|category|region|country|product|customer|location|department|status|type)\s+(.+)/i,
            
            // "Filter Best customers 4th coffee" - multi-word filter names (general)
            /filter\s+([a-z]+(?:\s+[a-z]+){1,2})\s+([\w\s&.,-]+)$/i,
            
            // "Filter region Asia Pacific" - single word filter names  
            /filter\s+(\w+)\s+(.+)/i,
            
            // "Filter by Location New York"
            /filter\s+by\s+(.+?)\s+([\w\s&.,-]+)$/i,
            
            // "Show data for Region East"
            /show\s+data\s+for\s+(.+?)\s+([\w\s&.,-]+)$/i,
            
            // "Apply filter Category Electronics"
            /apply\s+filter\s+(.+?)\s+([\w\s&.,-]+)$/i,
            
            // "Set Location to New York"
            /set\s+(.+?)\s+to\s+(.+)/i,
            
            // "Region equals Asia Pacific"  
            /(.+?)\s+equals?\s+(.+)/i,
            
            // "Show Region Asia Pacific"
            /show\s+(.+?)\s+([\w\s&.,-]+)$/i
        ];
        
        for (let i = 0; i < patterns.length; i++) {
            const pattern = patterns[i];
            console.log(`🔍 Testing pattern ${i+1}: ${pattern}`);
            const match = command.match(pattern);
            if (match) {
                criteria.field = match[1].trim();
                criteria.value = match[2].trim();
                console.log(`✅ Pattern ${i+1} matched!`);
                console.log(`📋 Match groups: [0]="${match[0]}", [1]="${match[1]}", [2]="${match[2]}"`);
                console.log(`🎯 Extracted -> field="${criteria.field}", value="${criteria.value}"`);
                break;
            } else {
                console.log(`❌ Pattern ${i+1} did not match`);
            }
        }
        
        // ENHANCED field name normalization
        if (criteria.field) {
            const fieldLower = criteria.field.toLowerCase();
            
            // Map common variations to standard names - KEEP ORIGINAL FIELD NAMES
            const fieldMappings = {
                'device category': 'device category',
                'device': 'device category', 
                'product category': 'product',
                'product': 'product',
                'customer name': 'customer',
                'customer': 'customer',
                'region': 'region',
                'country': 'country', // Keep country as country, don't map to region
                'location': 'location', // Keep location separate from region
                'category': 'category',
                'department': 'department',
                'store': 'store'
            };
            
            // Check if we can map the field to a standard name
            const originalField = criteria.field; // Store the original field value
            for (const [pattern, standardName] of Object.entries(fieldMappings)) {
                if (fieldLower.includes(pattern) || pattern.includes(fieldLower)) {
                    criteria.field = standardName;
                    console.log(`🔄 Normalized field: "${originalField}" -> "${standardName}"`);
                    break;
                }
            }
        }
        
        console.log(`🎯 Final extracted criteria: field="${criteria.field}", value="${criteria.value}"`);
        return criteria;
    }
    
    // ENHANCED filter matching with SMART MAPPING for messy filter names
    function findMatchingFilter(fieldName, filterElements) {
        const fieldLower = fieldName.toLowerCase().trim();
        console.log(`🔍 Looking for filter matching: "${fieldName}" (normalized: "${fieldLower}")`);
        console.log(`📋 Available filters (${filterElements.length}):`);
        filterElements.forEach((f, i) => {
            console.log(`  ${i+1}. "${f.name}" (normalized: "${f.normalizedName}")`);
        });
        
        // Strategy 1: EXACT name match (highest priority) - case insensitive
        for (const filter of filterElements) {
            const filterLower = filter.normalizedName.toLowerCase();
            console.log(`🔍 Comparing "${fieldLower}" === "${filterLower}"`);
            if (filterLower === fieldLower) {
                console.log(`✅ EXACT match found: "${filter.name}"`);
                return filter;
            }
        }
        
        // Strategy 2: SMART MAPPING for common messy filter names
        const smartMappings = [
            // Device/Category mappings
            { searchFor: ['device', 'device category'], detectPattern: /desktop.*mobile.*tablet/i, description: 'Device Category (Desktop/Mobile/Tablet)' },
            { searchFor: ['device', 'device category'], detectPattern: /mobile.*desktop.*tablet/i, description: 'Device Category (Mobile/Desktop/Tablet)' },
            
            // Region/Location mappings  
            { searchFor: ['region', 'location', 'country'], detectPattern: /asia.*pacific.*europe.*north/i, description: 'Region (Asia Pacific/Europe/North America)' },
            { searchFor: ['region', 'location', 'country'], detectPattern: /europe.*asia.*america/i, description: 'Region (Europe/Asia/America)' },
            
            // Product/Category mappings
            { searchFor: ['product', 'category', 'product category'], detectPattern: /zoom.*lens.*accounting.*camera/i, description: 'Product Category' },
            { searchFor: ['product', 'category'], detectPattern: /electronics.*software.*hardware/i, description: 'Product Category' },
            
            // Customer mappings
            { searchFor: ['customer', 'customer name'], detectPattern: /coffee.*corp.*inc.*ltd/i, description: 'Customer' },
            { searchFor: ['customer', 'customer name'], detectPattern: /company.*corporation.*group/i, description: 'Customer' }
        ];
        
        for (const mapping of smartMappings) {
            if (mapping.searchFor.some(term => fieldLower.includes(term) || term.includes(fieldLower))) {
                console.log(`🧠 Checking smart mapping for "${fieldName}" -> looking for pattern: ${mapping.detectPattern}`);
                
                for (const filter of filterElements) {
                    if (mapping.detectPattern.test(filter.normalizedName)) {
                        console.log(`✅ SMART MAPPING match: "${fieldName}" -> "${filter.name}" (${mapping.description})`);
                        return filter;
                    }
                }
            }
        }
        
        // Strategy 3: Clean substring match (prefer shorter, cleaner names)
        const exactContains = [];
        for (const filter of filterElements) {
            if (filter.normalizedName.includes(fieldLower) || fieldLower.includes(filter.normalizedName)) {
                exactContains.push({
                    filter,
                    score: filter.name.length <= 20 ? 10 : 5, // Prefer shorter names
                    priority: filter.priority || 0
                });
                console.log(`🎯 Substring match: "${filter.name}" (score: ${exactContains[exactContains.length-1].score})`);
            }
        }
        
        if (exactContains.length > 0) {
            // Sort by score (prefer short names) and then by priority
            exactContains.sort((a, b) => (b.score + b.priority) - (a.score + a.priority));
            const best = exactContains[0];
            console.log(`✅ Best substring match: "${best.filter.name}" (score: ${best.score}, priority: ${best.priority})`);
            return best.filter;
        }
        
        // Strategy 4: Smart word matching (only for multi-word filters)
        if (fieldLower.includes(' ') || filterElements.some(f => f.name.includes(' '))) {
            const fieldWords = fieldLower.split(/\s+/).filter(word => word.length > 2);
            let bestMatch = null;
            let bestScore = 0;
            
            for (const filter of filterElements) {
                const filterWords = filter.normalizedName.split(/\s+/).filter(word => word.length > 2);
                let score = 0;
                
                // Count matching words
                for (const fieldWord of fieldWords) {
                    for (const filterWord of filterWords) {
                        if (filterWord.includes(fieldWord) || fieldWord.includes(filterWord)) {
                            score += 10;
                        }
                        if (filterWord === fieldWord) {
                            score += 20; // Exact word match gets higher score
                        }
                    }
                }
                
                if (score > bestScore && score > 20) { // Minimum threshold
                    bestScore = score;
                    bestMatch = filter;
                }
            }
            
            if (bestMatch) {
                console.log(`✅ Best word match found: "${bestMatch.name}" (score: ${bestScore}) for "${fieldName}"`);
                return bestMatch;
            }
        }
        
        // Strategy 5: Fuzzy matching - partial matches
        for (const filter of filterElements) {
            const filterName = filter.normalizedName;
            
            // Check if any significant part matches
            if (fieldLower.length > 4 && filterName.includes(fieldLower.substring(0, 4))) {
                console.log(`✅ Fuzzy match found: "${filter.name}" for "${fieldName}"`);
                return filter;
            }
        }
        
        console.log(`❌ No matching filter found for field: "${fieldName}"`);
        return null;
    }
    
    // Apply filter to Power BI element
    function applyFilter(filterElement, value, originalCommand) {
        console.log(`🔧 Applying filter "${value}" to "${filterElement.name}"`);
        
        try {
            // Scroll filter into view
            filterElement.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            setTimeout(() => {
                // Different strategies based on filter type
                if (filterElement.type === 'slicer') {
                    applySlicer(filterElement, value, originalCommand);
                } else if (filterElement.type === 'dropdown') {
                    applyDropdownFilter(filterElement, value, originalCommand);
                } else if (filterElement.type === 'search') {
                    applySearchFilter(filterElement, value, originalCommand);
                } else {
                    // Enhanced generic approach with BETTER validation
                    console.log(`🔧 Generic filter approach for "${filterElement.name}"`);
                    filterElement.element.click();
                    
                    // Provide immediate feedback
                    addMessage(`🔧 Opening "${filterElement.name}" filter...\n\n🔍 Searching for "${value}" with enhanced detection...`, 'bot');
                    
                    // Wait and then try to find the value automatically with validation
                    setTimeout(() => {
                        const allClickableElements = document.querySelectorAll('[role="option"], [role="checkbox"], button, .slicerItem, .slicerText, .ms-Button, [data-automation-id*="option"]');
                        let found = false;
                        let bestMatch = null;
                        let bestScore = 0;
                        
                        console.log(`🔍 Generic scan: Found ${allClickableElements.length} potential elements`);
                        
                        // Find best match instead of first match
                        for (const elem of allClickableElements) {
                            const elemText = elem.textContent?.trim() || '';
                            if (elemText && elemText.length > 1 && elemText.length < 200) {
                                const matchScore = calculateDynamicMatchScore(elemText, value);
                                console.log(`  📋 Element: "${elemText}" (score: ${matchScore})`);
                                
                                if (matchScore > bestScore && matchScore >= 50) {
                                    bestScore = matchScore;
                                    bestMatch = { element: elem, text: elemText, score: matchScore };
                                }
                            }
                        }
                        
                        if (bestMatch) {
                            console.log(`✅ Generic filter found match: "${bestMatch.text}" (score: ${bestMatch.score})`);
                            
                            bestMatch.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            setTimeout(() => {
                                bestMatch.element.click();
                                
                                // Use the enhanced validation system
                                setTimeout(() => {
                                    validateFilterApplication(bestMatch, filterElement, originalCommand, [], value);
                                }, 2000);
                                
                            }, 500);
                            found = true;
                        }
                        
                        if (!found) {
                            console.log(`❌ No suitable matches found in generic approach`);
                            addMessage(`⚠️ Could not automatically find "${value}" in "${filterElement.name}"\n\n🔧 Filter opened - please select manually, or try:\n• Check spelling: "${value}"\n• Use shorter names\n• Say "help" for more options`, 'bot');
                        }
                    }, 1500);
                }
            }, 1000);
            
        } catch (e) {
            console.log('❌ Error applying filter:', e.message);
            addMessage(`❌ Error applying filter to "${filterElement.name}".\n\n💡 Try applying the filter manually or refresh the page.`, 'bot');
        }
    }
    
    // UNIVERSAL DYNAMIC slicer filter - works with ANY Power BI slicer
    function applySlicer(filterElement, value, originalCommand) {
        console.log(`🔧 UNIVERSAL SLICER: Looking for "${value}" in "${filterElement.name}"`);
        
        // Step 1: Click the slicer to ensure it's active/expanded
        filterElement.element.click();
        
        // Step 2: Use advanced dynamic detection for ANY slicer structure
        setTimeout(() => {
            console.log(`🔍 DYNAMIC SCAN: Starting comprehensive search for "${value}"`);
            
            // Get all potentially clickable elements on the entire page
            const allElements = document.querySelectorAll('*');
            const candidates = [];
            
            // Collect all possible candidates
            for (const elem of allElements) {
                const elemText = (elem.textContent?.trim() || '').toLowerCase();
                const elemLabel = (elem.getAttribute('aria-label') || '').toLowerCase();
                const elemTitle = (elem.getAttribute('title') || '').toLowerCase();
                const allText = `${elemText} ${elemLabel} ${elemTitle}`;
                
                // Skip empty or very long elements
                if (!elemText || elemText.length > 200 || elemText.length < 2) continue;
                
                // Check if element might be clickable
                const isClickable = elem.onclick || 
                                  elem.getAttribute('role') === 'option' ||
                                  elem.getAttribute('role') === 'button' ||
                                  elem.getAttribute('role') === 'checkbox' ||
                                  elem.getAttribute('role') === 'menuitem' ||
                                  elem.tagName === 'BUTTON' ||
                                  elem.tagName === 'A' ||
                                  elem.classList.contains('slicer') ||
                                  elem.closest('.slicer') ||
                                  elem.closest('.visual-container') ||
                                  window.getComputedStyle(elem).cursor === 'pointer';
                
                if (isClickable) {
                    // Calculate match score for this element
                    const matchScore = calculateDynamicMatchScore(elemText, value);
                    if (matchScore > 0) {
                        candidates.push({
                            element: elem,
                            text: elemText,
                            score: matchScore,
                            fullText: allText
                        });
                    }
                }
            }
            
            // Sort candidates by match score
            candidates.sort((a, b) => b.score - a.score);
            
            console.log(`🎯 Found ${candidates.length} potential matches for "${value}":`);
            candidates.slice(0, 10).forEach((candidate, index) => {
                console.log(`  ${index + 1}. "${candidate.text}" (score: ${candidate.score})`);
            });
            
            // Try the best matches
            if (candidates.length > 0) {
                const bestCandidate = candidates[0];
                
                // Additional validation - make sure it's a reasonable match
                if (bestCandidate.score >= 50) {
                    console.log(`✅ BEST MATCH: "${bestCandidate.text}" (score: ${bestCandidate.score})`);
                    
                    // Use the enhanced validation system for high-confidence matches too
                    bestCandidate.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    
                    addMessage(`🎯 High-confidence match found: "${bestCandidate.text}"\n\n⏳ Applying filter with validation...`, 'bot');
                    
                    setTimeout(() => {
                        bestCandidate.element.click();
                        console.log(`🎯 Clicked on: "${bestCandidate.text}"`);
                        
                        // Use enhanced validation for best match too
                        setTimeout(() => {
                            validateFilterApplication(bestCandidate, filterElement, originalCommand, candidates.slice(1, 4), value);
                        }, 2000);
                        
                    }, 500);
                } else {
                    // Try multiple candidates if the best isn't confident enough
                    console.log(`🔍 Best match score too low (${bestCandidate.score}), trying top candidates...`);
                    
                    tryMultipleCandidates(candidates.slice(0, 3), value, filterElement, originalCommand);
                }
            } else {
                console.log(`❌ No clickable matches found for "${value}"`);
                
                // Show available options by scanning visible text
                showAvailableOptions(filterElement, value, originalCommand);
            }
            
        }, 2000); // Wait for slicer to fully expand
    }
    
    // Calculate dynamic match score for any text
    function calculateDynamicMatchScore(elemText, targetValue) {
        const elemLower = elemText.toLowerCase().trim();
        const targetLower = targetValue.toLowerCase().trim();
        let score = 0;
        
        // Exact match
        if (elemLower === targetLower) return 100;
        
        // Full contains match
        if (elemLower.includes(targetLower)) return 80;
        if (targetLower.includes(elemLower) && elemLower.length > 3) return 75;
        
        // Word-by-word matching
        const elemWords = elemLower.split(/\s+/).filter(w => w.length > 2);
        const targetWords = targetLower.split(/\s+/).filter(w => w.length > 2);
        
        let matchedWords = 0;
        for (const targetWord of targetWords) {
            for (const elemWord of elemWords) {
                if (elemWord.includes(targetWord) || targetWord.includes(elemWord)) {
                    matchedWords++;
                    score += 20;
                    break;
                }
            }
        }
        
        // Bonus for matching multiple words
        if (targetWords.length > 1 && matchedWords >= targetWords.length) {
            score += 30;
        }
        
        // Special handling for common patterns
        if (targetLower.includes('4th') && elemLower.includes('fourth')) score += 40;
        if (targetLower.includes('coffee') && elemLower.includes('coffee')) score += 40;
        if (targetLower.includes('customers') && elemLower.includes('customers')) score += 30;
        
        return score;
    }
    
    // Try multiple candidates in sequence with ENHANCED validation
    function tryMultipleCandidates(candidates, targetValue, filterElement, originalCommand) {
        if (candidates.length === 0) return;
        
        const candidate = candidates[0];
        console.log(`🔄 Trying candidate: "${candidate.text}" (score: ${candidate.score})`);
        
        // Scroll into view first
        candidate.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Give user immediate feedback
        addMessage(`🔧 Attempting to apply: ${filterElement.name} = "${candidate.text}"...\n\n⏳ Please wait while I confirm the filter is applied...`, 'bot');
        
        setTimeout(() => {
            // Try different click approaches for better compatibility
            console.log(`🖱️ Attempting to click: "${candidate.text}"`);
            
            // Method 1: Regular click
            candidate.element.click();
            
            // Method 2: Dispatch click event (more reliable for some Power BI elements)
            setTimeout(() => {
                const clickEvent = new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                });
                candidate.element.dispatchEvent(clickEvent);
                
                // Method 3: For checkboxes, ensure they're checked
                if (candidate.element.type === 'checkbox' && !candidate.element.checked) {
                    candidate.element.checked = true;
                    candidate.element.dispatchEvent(new Event('change', { bubbles: true }));
                }
                
                // Enhanced validation - wait and check if filter was applied
                setTimeout(() => {
                    validateFilterApplication(candidate, filterElement, originalCommand, candidates.slice(1), targetValue);
                }, 2000); // Wait longer for Power BI to process
                
            }, 300);
        }, 800);
    }
    
    // NEW: Enhanced filter validation function
    function validateFilterApplication(appliedCandidate, filterElement, originalCommand, remainingCandidates, targetValue) {
        console.log(`✅ Validation: Checking if filter "${appliedCandidate.text}" was applied...`);
        
        // Check multiple indicators that the filter might have been applied
        let filterApplied = false;
        let validationResults = [];
        
        // Validation 1: Check if element is now selected/active
        const isSelected = appliedCandidate.element.classList.contains('selected') ||
                          appliedCandidate.element.classList.contains('active') ||
                          appliedCandidate.element.getAttribute('aria-selected') === 'true' ||
                          appliedCandidate.element.getAttribute('aria-checked') === 'true' ||
                          (appliedCandidate.element.type === 'checkbox' && appliedCandidate.element.checked);
        
        if (isSelected) {
            validationResults.push('✅ Element appears selected');
            filterApplied = true;
        } else {
            validationResults.push('⚠️ Element may not be selected');
        }
        
        // Validation 2: Check for Power BI filter badges/indicators
        const filterBadges = document.querySelectorAll('.filter-badge, .applied-filter, [aria-label*="filter applied"], [title*="filter applied"]');
        if (filterBadges.length > 0) {
            validationResults.push(`✅ Found ${filterBadges.length} filter indicators`);
            filterApplied = true;
        }
        
        // Validation 3: Check for visual changes in the report area
        const visualContainers = document.querySelectorAll('.visual-container, .report-container');
        if (visualContainers.length > 0) {
            validationResults.push(`✅ Report visuals present (${visualContainers.length})`);
        }
        
        // Validation 4: Check URL for filter parameters (some Power BI setups use this)
        if (window.location.href.includes('filter') || window.location.href.includes(encodeURIComponent(appliedCandidate.text.toLowerCase()))) {
            validationResults.push('✅ Filter detected in URL');
            filterApplied = true;
        }
        
        console.log(`🔍 Validation results:`, validationResults);
        
        // Provide feedback based on validation
        if (filterApplied) {
            addMessage(`✅ Filter Successfully Applied!\n\n🎯 ${filterElement.name} = "${appliedCandidate.text}"\n\n📊 Your command: "${originalCommand}"\n🤖 Universal matching - works with ANY filter!\n\n${validationResults.join('\n')}`, 'bot');
        } else {
            console.log(`⚠️ Filter may not have been applied, trying enhanced methods...`);
            
            // Try enhanced application methods
            tryEnhancedFilterApplication(appliedCandidate, filterElement, originalCommand, remainingCandidates, targetValue);
        }
    }
    
    // NEW: Enhanced filter application with multiple strategies
    function tryEnhancedFilterApplication(candidate, filterElement, originalCommand, remainingCandidates, targetValue) {
        console.log(`🔧 Enhanced application for: "${candidate.text}"`);
        
        // Strategy 1: Double-click (some Power BI elements need this)
        candidate.element.dispatchEvent(new MouseEvent('dblclick', { bubbles: true, cancelable: true }));
        
        // Strategy 2: Keyboard interaction (Enter/Space)
        setTimeout(() => {
            candidate.element.focus();
            candidate.element.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
            candidate.element.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true }));
            
            // Strategy 3: Force change events
            setTimeout(() => {
                ['input', 'change', 'click', 'mousedown', 'mouseup'].forEach(eventType => {
                    candidate.element.dispatchEvent(new Event(eventType, { bubbles: true }));
                });
                
                // Final validation after all strategies
                setTimeout(() => {
                    const finalCheck = candidate.element.classList.contains('selected') ||
                                     candidate.element.getAttribute('aria-selected') === 'true' ||
                                     (candidate.element.type === 'checkbox' && candidate.element.checked);
                    
                    if (finalCheck) {
                        addMessage(`✅ Filter Applied (Enhanced Method)!\n\n🎯 ${filterElement.name} = "${candidate.text}"\n\n📊 Your command: "${originalCommand}"\n🤖 Used advanced Power BI compatibility mode!`, 'bot');
                    } else if (remainingCandidates.length > 0) {
                        console.log(`🔄 Trying next candidate...`);
                        addMessage(`🔄 Trying alternative match...\n\n⏳ Testing next best option for "${targetValue}"`, 'bot');
                        tryMultipleCandidates(remainingCandidates, targetValue, filterElement, originalCommand);
                    } else {
                        addMessage(`⚠️ Filter command completed but validation unclear.\n\n🎯 Attempted: ${filterElement.name} = "${candidate.text}"\n📊 Command: "${originalCommand}"\n\n💡 Check if the filter was applied to your Power BI report.\nIf not, try:\n• Refresh the page\n• Use exact filter names\n• Apply filters manually first to see available options`, 'bot');
                    }
                }, 1500);
            }, 500);
        }, 300);
    }
    
    // Show available options when no match is found
    function showAvailableOptions(filterElement, targetValue, originalCommand) {
        console.log(`🔍 Scanning for available options in "${filterElement.name}"`);
        
        // Get all text elements within reasonable proximity of the filter
        const nearbyElements = [];
        const allElements = document.querySelectorAll('*');
        
        for (const elem of allElements) {
            const elemText = elem.textContent?.trim() || '';
            if (elemText.length > 2 && elemText.length < 100) {
                // Check if element is near the filter or contains filter-like content
                if (elem.closest('.visual-container') || 
                    elem.closest('.slicer') ||
                    elemText.includes('customers') ||
                    elemText.includes('coffee') ||
                    elemText.includes('corp') ||
                    elemText.includes('inc')) {
                    nearbyElements.push(elemText);
                }
            }
        }
        
        // Remove duplicates and show options
        const uniqueOptions = [...new Set(nearbyElements)].slice(0, 10);
        
        let message = `❌ Could not find "${targetValue}" in the filter.\n\n🔍 Available options might include:\n`;
        uniqueOptions.forEach(option => {
            message += `• ${option}\n`;
        });
        message += `\n💡 Try:\n• Check spelling\n• Use shorter names\n• "Fourth Coffee" instead of "4th coffee"\n• Say "help" for more commands`;
        
        addMessage(message, 'bot');
    }
    
    // Enhanced value matching function
    function isValueMatch(itemText, targetValue) {
        const itemLower = itemText.toLowerCase().trim();
        const targetLower = targetValue.toLowerCase().trim();
        
        // Exact match
        if (itemLower === targetLower) return true;
        
        // Contains match
        if (itemLower.includes(targetLower)) return true;
        
        // Handle "Asia Pacific" case - check if item contains both words
        const targetWords = targetLower.split(/\s+/);
        if (targetWords.length > 1) {
            const allWordsPresent = targetWords.every(word => itemLower.includes(word));
            if (allWordsPresent) return true;
        }
        
        // Reverse contains (target contains item)
        if (targetLower.includes(itemLower) && itemLower.length > 3) return true;
        
        return false;
    }
    
    // ENHANCED dropdown filter - fully automated
    function applyDropdownFilter(filterElement, value, originalCommand) {
        console.log(`🔧 SMART DROPDOWN: Looking for "${value}" in "${filterElement.name}"`);
        
        // Click to open dropdown
        filterElement.element.click();
        
        setTimeout(() => {
            // Enhanced selectors for dropdown options
            const optionSelectors = [
                '[role="option"]', '[role="menuitem"]', '[role="checkbox"]',
                '.dropdown-item', '.select-option', '.menu-item',
                'li', 'button', '[data-automation-id*="option"]'
            ];
            
            let found = false;
            
            for (const selector of optionSelectors) {
                if (found) break;
                
                const options = document.querySelectorAll(selector);
                console.log(`🔍 Checking ${options.length} dropdown options with selector: ${selector}`);
                
                for (const option of options) {
                    const optionText = option.textContent?.trim() || option.getAttribute('aria-label') || '';
                    console.log(`  📋 Option: "${optionText}"`);
                    
                    if (optionText && isValueMatch(optionText, value)) {
                        console.log(`✅ DROPDOWN MATCH: "${optionText}"`);
                        option.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        
                        addMessage(`🎯 Found dropdown option: "${optionText}"\n\n⏳ Applying with validation...`, 'bot');
                        
                        setTimeout(() => {
                            option.click();
                            
                            // Use enhanced validation for dropdown too
                            const candidateMatch = { element: option, text: optionText, score: 100 };
                            setTimeout(() => {
                                validateFilterApplication(candidateMatch, filterElement, originalCommand, [], value);
                            }, 1500);
                        }, 500);
                        found = true;
                        break;
                    }
                }
            }
            
            if (!found) {
                addMessage(`❌ Could not find "${value}" in dropdown options.\n\n� The dropdown is open - checking all available options...\n💡 Make sure spelling is correct.`, 'bot');
            }
        }, 1000);
    }
    
    // Apply search filter
    function applySearchFilter(filterElement, value, originalCommand) {
        // Clear existing value and type new value
        filterElement.element.focus();
        filterElement.element.value = '';
        filterElement.element.value = value;
        
        // Trigger input events
        filterElement.element.dispatchEvent(new Event('input', { bubbles: true }));
        filterElement.element.dispatchEvent(new Event('change', { bubbles: true }));
        
        // Press Enter to apply
        setTimeout(() => {
            filterElement.element.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
            addMessage(`✅ Applied search filter: "${value}"\n\n🎯 Your command: "${originalCommand}"\n📊 Search filter has been applied.`, 'bot');
        }, 300);
    }
    
    // Extract filter name to reset from command
    function extractFilterNameToReset(command) {
        console.log(`🔍 Extracting filter name to reset from: "${command}"`);
        
        const patterns = [
            // "reset region filter" -> "region"
            /reset\s+(.+?)\s+filter/i,
            // "clear region filter" -> "region"  
            /clear\s+(.+?)\s+filter/i,
            // "remove region filter" -> "region"
            /remove\s+(.+?)\s+filter/i,
            // "reset region" -> "region"
            /reset\s+(.+)/i,
            // "clear region" -> "region"
            /clear\s+(.+)/i
        ];
        
        for (let i = 0; i < patterns.length; i++) {
            const pattern = patterns[i];
            console.log(`🔍 Testing pattern ${i + 1}: ${pattern}`);
            const match = command.match(pattern);
            if (match) {
                const filterName = match[1].trim();
                console.log(`✅ SUCCESS! Extracted filter name: "${filterName}" using pattern: ${pattern}`);
                console.log(`✅ Full match array:`, match);
                return filterName;
            } else {
                console.log(`❌ Pattern ${i + 1} did not match`);
            }
        }
        
        console.log(`❌ No filter name extracted from: "${command}"`);
        return null;
    }
    
    // ENHANCED reset individual filter - finds clear buttons automatically
    function resetIndividualFilter(filterElement, originalCommand) {
        console.log(`🔄 Resetting filter: "${filterElement.name}"`);
        
        try {
            // Strategy 1: Look for clear buttons in the entire document
            const clearButtonSelectors = [
                // Text-based search for clear buttons
                '*[textContent*="Clear filter"]',
                '*[aria-label*="Clear filter"]',
                '*[title*="Clear filter"]',
                
                // Generic clear button selectors
                '.clear-button', '.reset-button', '.clear-filter',
                '[title*="Clear"]', '[aria-label*="Clear"]', '[title*="Reset"]',
                'button[data-automation-id*="clear"]', 'button[data-automation-id*="reset"]'
            ];
            
            let resetButton = null;
            
            // First try to find clear button within or near the filter element
            for (const selector of clearButtonSelectors) {
                // Look within the filter element
                resetButton = filterElement.element.querySelector(selector);
                if (resetButton) break;
                
                // Look in parent containers
                const parent = filterElement.element.closest('.visual-container, .filter-container, .slicer-container');
                if (parent) {
                    resetButton = parent.querySelector(selector);
                    if (resetButton) break;
                }
            }
            
            // Strategy 2: Search the entire document for clear buttons related to this filter
            if (!resetButton) {
                console.log(`🔍 Searching entire document for "${filterElement.name}" clear button...`);
                
                const allButtons = document.querySelectorAll('button, [role="button"], a, [onclick]');
                for (const button of allButtons) {
                    const buttonText = button.textContent?.trim().toLowerCase() || '';
                    const buttonLabel = button.getAttribute('aria-label')?.toLowerCase() || '';
                    const buttonTitle = button.getAttribute('title')?.toLowerCase() || '';
                    
                    const allText = `${buttonText} ${buttonLabel} ${buttonTitle}`.toLowerCase();
                    
                    // Check if button is related to clearing this specific filter
                    if ((allText.includes('clear') || allText.includes('reset')) && 
                        (allText.includes('filter') || allText.includes(filterElement.name.toLowerCase()))) {
                        resetButton = button;
                        console.log(`✅ Found clear button: "${button.textContent || button.getAttribute('aria-label')}"`);
                        break;
                    }
                }
            }
            
            // Strategy 3: Click the filter and then look for clear options
            if (resetButton) {
                resetButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
                setTimeout(() => {
                    resetButton.click();
                    console.log(`✅ Clicked reset button for "${filterElement.name}"`);
                    addMessage(`🔄 Reset filter: "${filterElement.name}"\n\n✅ Filter cleared successfully - showing all data now!`, 'bot');
                }, 500);
            } else {
                console.log(`🔍 No direct clear button found, trying interactive reset for "${filterElement.name}"`);
                
                // Click the slicer to activate it, then look for clear options
                filterElement.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                filterElement.element.click();
                
                setTimeout(() => {
                    // After clicking, search again for clear buttons that might have appeared
                    const dynamicClearButtons = document.querySelectorAll('[title*="Clear"], [aria-label*="Clear"], .clear-button, .reset-button');
                    
                    for (const clearBtn of dynamicClearButtons) {
                        const btnText = clearBtn.textContent?.toLowerCase() || clearBtn.getAttribute('aria-label')?.toLowerCase() || '';
                        if (btnText.includes('clear') || btnText.includes('reset')) {
                            clearBtn.click();
                            addMessage(`🔄 Reset filter: "${filterElement.name}"\n\n✅ Found and clicked clear button automatically!`, 'bot');
                            return;
                        }
                    }
                    
                    // If still no clear button found, try right-click for context menu
                    filterElement.element.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true }));
                    
                    setTimeout(() => {
                        // Look for context menu clear options
                        const contextMenuItems = document.querySelectorAll('[role="menuitem"], .context-menu-item');
                        for (const item of contextMenuItems) {
                            const itemText = item.textContent?.toLowerCase() || '';
                            if (itemText.includes('clear') || itemText.includes('reset')) {
                                item.click();
                                addMessage(`🔄 Reset filter: "${filterElement.name}"\n\n✅ Used context menu to clear filter!`, 'bot');
                                return;
                            }
                        }
                        
                        addMessage(`🔄 Activated "${filterElement.name}" filter.\n\n💡 Look for clear/reset options that appeared, or:\n• Try "Reset all filters" command\n• Manually deselect items in the filter`, 'bot');
                    }, 1000);
                    
                }, 1000);
            }
            
        } catch (e) {
            console.log('❌ Error resetting filter:', e.message);
            addMessage(`❌ Error resetting "${filterElement.name}" filter.\n\n💡 Try "Reset all filters" or reset manually.`, 'bot');
        }
    }
    
    // UNIVERSAL reset button scanner - finds ANY reset option
    function scanUniversalResetButtons() {
        console.log('🔍 UNIVERSAL RESET SCAN: Looking for ALL types of reset buttons...');
        const resetButtons = [];
        
        // Get ALL elements on the page
        const allElements = document.querySelectorAll('*');
        
        for (const element of allElements) {
            const text = element.textContent?.trim() || '';
            const ariaLabel = element.getAttribute('aria-label') || '';
            const title = element.getAttribute('title') || '';
            const allText = `${text} ${ariaLabel} ${title}`.toLowerCase();
            
            // Skip empty or very long elements
            if (!allText || allText.length > 500) continue;
            
            // Check if element contains reset-related keywords
            const resetKeywords = [
                'reset', 'clear', 'remove all', 'reset all', 'clear all',
                'reset filters', 'clear filters', 'reset slicers',
                'remove filters', 'reset to default', 'clear selections',
                'reset view', 'clear all filters'
            ];
            
            let isResetRelated = false;
            let matchedKeywords = [];
            
            for (const keyword of resetKeywords) {
                if (allText.includes(keyword)) {
                    isResetRelated = true;
                    matchedKeywords.push(keyword);
                }
            }
            
            if (isResetRelated) {
                // Check if element is likely clickable
                const isClickable = element.onclick ||
                                  element.getAttribute('role') === 'button' ||
                                  element.getAttribute('role') === 'menuitem' ||
                                  element.tagName === 'BUTTON' ||
                                  element.tagName === 'A' ||
                                  element.classList.contains('button') ||
                                  window.getComputedStyle(element).cursor === 'pointer';
                
                if (isClickable || element.tagName === 'BUTTON' || element.getAttribute('role') === 'button') {
                    const resetInfo = {
                        element: element,
                        text: text || ariaLabel || title,
                        fullText: allText,
                        keywords: matchedKeywords,
                        isHighPriority: allText.includes('reset all') || 
                                       allText.includes('clear all') || 
                                       allText.includes('reset filters')
                    };
                    
                    resetButtons.push(resetInfo);
                    console.log(`🔍 Found reset option: "${resetInfo.text}" (keywords: ${matchedKeywords.join(', ')})`);
                }
            }
        }
        
        console.log(`🔄 SCAN COMPLETE: Found ${resetButtons.length} potential reset options`);
        
        // Sort by priority (high priority first)
        resetButtons.sort((a, b) => {
            if (a.isHighPriority && !b.isHighPriority) return -1;
            if (!a.isHighPriority && b.isHighPriority) return 1;
            return b.keywords.length - a.keywords.length; // More keywords = higher priority
        });
        
        return resetButtons;
    }
    
    // Find the BEST reset all button with intelligent scoring
    function findBestResetAllButton(resetButtons) {
        if (resetButtons.length === 0) return null;
        
        console.log('🎯 Evaluating reset button candidates:');
        
        // Score each button based on how likely it is to reset ALL filters
        const scoredButtons = resetButtons.map(button => {
            let score = 0;
            const text = button.fullText.toLowerCase();
            
            // High-value phrases
            if (text.includes('reset all')) score += 100;
            if (text.includes('clear all')) score += 100;
            if (text.includes('reset filters')) score += 90;
            if (text.includes('clear filters')) score += 90;
            if (text.includes('reset slicers')) score += 85;
            if (text.includes('remove all filters')) score += 95;
            if (text.includes('clear selections')) score += 80;
            
            // Medium-value phrases  
            if (text.includes('reset') && text.includes('filter')) score += 70;
            if (text.includes('clear') && text.includes('filter')) score += 70;
            if (text.includes('reset to default')) score += 60;
            if (text.includes('reset view')) score += 50;
            
            // Bonus for being explicitly marked as high priority
            if (button.isHighPriority) score += 50;
            
            // Penalty for very long text (likely not a button)
            if (text.length > 200) score -= 30;
            
            console.log(`  📊 "${button.text}" - Score: ${score}`);
            
            return { ...button, score };
        });
        
        // Sort by score and return the best one
        scoredButtons.sort((a, b) => b.score - a.score);
        
        if (scoredButtons.length > 0 && scoredButtons[0].score > 50) {
            console.log(`✅ Best reset option: "${scoredButtons[0].text}" (score: ${scoredButtons[0].score})`);
            return scoredButtons[0];
        }
        
        console.log('❌ No high-confidence reset button found');
        return null;
    }
    
    // Reset all filters individually
    function resetAllFiltersIndividually() {
        console.log('🔄 Attempting to reset all filters individually...');
        
        const filterElements = scanPowerBIFilters();
        let resetCount = 0;
        
        filterElements.forEach((filter, index) => {
            setTimeout(() => {
                resetIndividualFilter(filter, 'Reset All Filters');
                resetCount++;
                
                if (resetCount === filterElements.length) {
                    setTimeout(() => {
                        addMessage(`🔄 Attempted to reset all ${filterElements.length} filters individually.\n\n✅ All filters should now be cleared.`, 'bot');
                    }, 1000);
                }
            }, index * 1000); // Stagger resets to avoid conflicts
        });
        
        if (filterElements.length === 0) {
            addMessage('🔄 No filters found to reset.\n\n💡 Make sure you\'re on a report page with active filters.', 'bot');
        }
    }
    
    // Show available filters to user with enhanced display
    function showAvailableFilters(filterElements, searchedField) {
        let message = `🔍 Filter "${searchedField}" not found.\n\n`;
        
        if (filterElements.length > 0) {
            // Group filters by priority and clean up display
            const highPriorityFilters = filterElements.filter(f => (f.priority || 0) >= 8);
            const otherFilters = filterElements.filter(f => (f.priority || 0) < 8);
            
            if (highPriorityFilters.length > 0) {
                message += `🎯 **Primary Filters** (${highPriorityFilters.length}):\n`;
                highPriorityFilters.forEach(filter => {
                    const cleanName = filter.name.length > 30 ? filter.name.substring(0, 30) + '...' : filter.name;
                    message += `• **${cleanName}**\n`;
                });
                message += `\n`;
            }
            
            if (otherFilters.length > 0 && otherFilters.length <= 10) {
                message += `📋 Other Filters (${otherFilters.length}):\n`;
                otherFilters.forEach(filter => {
                    const cleanName = filter.name.length > 25 ? filter.name.substring(0, 25) + '...' : filter.name;
                    message += `• ${cleanName}\n`;
                });
                message += `\n`;
            }
            
            message += `💡 **Try these clear commands:**\n`;
            const sampleFilters = highPriorityFilters.length > 0 ? highPriorityFilters : filterElements;
            sampleFilters.slice(0, 3).forEach(filter => {
                const filterName = filter.name.split(' ')[0].toLowerCase();
                message += `• "Clear ${filterName} filter"\n`;
                message += `• "Reset ${filterName} filter"\n`;
            });
            
            message += `\n🔧 **Or apply filters:**\n`;
            sampleFilters.slice(0, 2).forEach(filter => {
                const filterName = filter.name.split(' ')[0];
                message += `• "Filter by ${filterName} [value]"\n`;
            });
        } else {
            message += `❌ No filters detected on this page.\n\n`;
            message += `💡 **Troubleshooting:**\n`;
            message += `• Navigate to a Power BI report with slicers\n`;
            message += `• Wait for the page to fully load\n`;
            message += `• Try refreshing the page\n`;
            message += `• Make sure you're on the right report tab`;
        }
        
        addMessage(message, 'bot');
    }

    // ========================================
    // POWER BI EXPORT FUNCTIONS
    // ========================================
    
    // Handle export commands like "Export sentiment by product category visual" or "Download data to Excel"
    function handleExportCommand(normalizedCommand, originalCommand) {
        console.log(`📤 STARTING handleExportCommand`);
        console.log(`📋 Original command: "${originalCommand}"`);
        console.log(`📋 Normalized command: "${normalizedCommand}"`);
        
        try {
            // Extract export criteria from the command
            console.log(`🎯 Step 1: Extracting export criteria...`);
            const exportCriteria = extractExportCriteria(normalizedCommand);
            console.log(`✅ Export criteria extracted:`, exportCriteria);
            
            // Update user with progress
            setTimeout(() => {
                if (exportCriteria.visualName) {
                    addMessage(`📊 Looking for "${exportCriteria.visualName}" visual to export...\n\n🔍 Scanning Power BI visuals...`, 'bot');
                } else {
                    addMessage(`📊 Scanning for exportable visuals...\n\n🔍 Looking for export options...`, 'bot');
                }
            }, 100);
            
            // Scan for Power BI visuals that can be exported
            console.log(`🎯 Step 2: Scanning for Power BI visuals...`);
            const exportableVisuals = scanPowerBIVisuals();
            console.log(`✅ Visual scan complete: ${exportableVisuals.length} visuals found`);
            
            if (exportCriteria.visualName) {
                // Find specific visual to export
                console.log(`🎯 Step 3: Finding visual "${exportCriteria.visualName}"...`);
                const matchingVisual = findMatchingVisual(exportCriteria.visualName, exportableVisuals);
                
                if (matchingVisual) {
                    console.log(`✅ Found matching visual: "${matchingVisual.name}"`);
                    exportSpecificVisual(matchingVisual, exportCriteria.format, originalCommand);
                } else {
                    console.log(`❌ No matching visual found for: "${exportCriteria.visualName}"`);
                    showAvailableVisualsForExport(exportableVisuals, exportCriteria.visualName);
                }
            } else {
                // Show all available export options
                console.log(`🎯 Step 3: Showing all export options...`);
                showAvailableVisualsForExport(exportableVisuals, null);
            }
            
        } catch (error) {
            console.error('❌ Error in handleExportCommand:', error);
            addMessage(`❌ Error processing export command: ${error.message}\n\nPlease try again or check the browser console for details.`, 'bot');
        }
    }
    
    // Extract export criteria from command
    function extractExportCriteria(command) {
        const criteria = { visualName: null, format: 'excel' };
        
        console.log(`🎯 PARSING EXPORT COMMAND: "${command}"`);
        
        // Detect export format
        if (command.includes('csv')) {
            criteria.format = 'csv';
        } else if (command.includes('excel') || command.includes('xlsx')) {
            criteria.format = 'excel';
        } else if (command.includes('pdf')) {
            criteria.format = 'pdf';
        } else if (command.includes('image') || command.includes('png') || command.includes('jpg')) {
            criteria.format = 'image';
        }
        
        // Enhanced patterns to extract visual names - handle various formats
        const patterns = [
            // "Exports sentiment by product category. Visual." - handles periods and plural
            /exports?\s+(.+?)\.\s*visual\.?/i,
            // "Export sentiment by product category visual" 
            /exports?\s+(.+?)\s+visual\.?/i,
            // "Export sentiment by product category"
            /exports?\s+(.+?)(?:\s+to\s+(?:excel|csv|pdf))?\.?$/i,
            // "Download sentiment by product category visual"
            /downloads?\s+(.+?)\s+visual\.?/i,
            // "Download sentiment by product category"
            /downloads?\s+(.+?)(?:\s+to\s+(?:excel|csv|pdf))?\.?$/i,
            // "Save sentiment by product category to excel"
            /saves?\s+(.+?)\s+to\s+(?:excel|csv|pdf)/i,
            // Handle "Visual" at the end with periods
            /(?:export|exports|download|downloads|save|saves)\s+(.+?)\s*\.?\s*visual\.?/i,
            // General pattern for visual names (fallback)
            /(?:export|exports|download|downloads|save|saves)\s+(.+?)\.?$/i
        ];
        
        for (let i = 0; i < patterns.length; i++) {
            const pattern = patterns[i];
            console.log(`🔍 Testing pattern ${i+1}: ${pattern}`);
            const match = command.match(pattern);
            if (match) {
                criteria.visualName = match[1].trim();
                console.log(`✅ Pattern ${i+1} matched!`);
                console.log(`📋 Match groups: [0]="${match[0]}", [1]="${match[1]}"`);
                console.log(`🎯 Extracted visual name: "${criteria.visualName}"`);
                break;
            } else {
                console.log(`❌ Pattern ${i+1} did not match`);
            }
        }
        
        // Clean up the visual name with enhanced cleanup
        if (criteria.visualName) {
            criteria.visualName = criteria.visualName
                // Remove trailing words
                .replace(/\s+(visual|chart|graph|report|data)\.?$/i, '')
                // Remove leading articles
                .replace(/^(the|a|an)\s+/i, '')
                // Remove periods and extra spaces
                .replace(/\./g, '')
                .replace(/\s+/g, ' ')
                .trim();
            
            console.log(`🧹 Cleaned visual name: "${criteria.visualName}"`);
        }
        
        console.log(`🎯 Final extracted criteria: visualName="${criteria.visualName}", format="${criteria.format}"`);
        return criteria;
    }
    
    // Scan for Power BI visuals that can be exported
    function scanPowerBIVisuals() {
        console.log('🔍 Scanning for Power BI visuals that can be exported...');
        
        const visuals = [];
        
        // Enhanced Power BI visual selectors
        const visualSelectors = [
            '.visual-container-component', '.visual-container', '.visualContainer',
            '.visual', '.visuals', '.reportVisual', '.visual-modern',
            '[data-automation-id*="visual"]', '[data-testid*="visual"]',
            '.chart-container', '.chart', '.graph-container', '.graph',
            '.visual-title', '.visualTitle', '.chart-title', '.title-text',
            '.visual-header', '.visualHeader', '.vcHeaderText',
            '[data-visual-type]', '.pivot-table', '.matrix', '.table-visual'
        ];
        
        const foundVisuals = new Map(); // Use Map to avoid duplicates
        
        for (const selector of visualSelectors) {
            try {
                const elements = document.querySelectorAll(selector);
                console.log(`📋 Found ${elements.length} elements for selector: ${selector}`);
                
                elements.forEach(element => {
                    const visualInfo = analyzeVisualElement(element, selector);
                    if (visualInfo && !foundVisuals.has(visualInfo.name.toLowerCase())) {
                        foundVisuals.set(visualInfo.name.toLowerCase(), visualInfo);
                        visuals.push(visualInfo);
                        console.log(`📊 Found exportable visual: "${visualInfo.name}" (${visualInfo.type})`);
                    }
                });
            } catch (e) {
                console.log(`⚠️ Error scanning selector ${selector}:`, e.message);
            }
        }
        
        console.log(`📊 Total exportable visuals found: ${visuals.length}`);
        return visuals;
    }
    
    // Analyze visual element to extract name and export capabilities
    function analyzeVisualElement(element, selector) {
        // Try to find visual title/name
        let visualName = '';
        let visualType = 'visual';
        
        // Look for titles in various locations
        const titleSelectors = [
            '.visual-title', '.visualTitle', '.chart-title', '.title-text',
            '.visual-header', '.visualHeader', '.vcHeaderText',
            'h1', 'h2', 'h3', 'h4', '[role="heading"]',
            '.slicer-header', '.slicerHeaderText'
        ];
        
        for (const titleSelector of titleSelectors) {
            const titleElement = element.querySelector(titleSelector);
            if (titleElement) {
                const title = titleElement.textContent?.trim();
                if (title && title.length > 0 && title.length < 100) {
                    visualName = title;
                    console.log(`📋 Found title using ${titleSelector}: "${title}"`);
                    break;
                }
            }
        }
        
        // If no title found, try to extract from data attributes or parent elements
        if (!visualName) {
            const dataTitle = element.getAttribute('data-title') || 
                            element.getAttribute('aria-label') ||
                            element.getAttribute('title');
            if (dataTitle) {
                visualName = dataTitle;
                console.log(`📋 Found title from attributes: "${visualName}"`);
            }
        }
        
        // If still no name, try to infer from content or position
        if (!visualName) {
            // Look for distinctive content that might indicate the visual type
            const textContent = element.textContent?.trim() || '';
            
            // Try to identify visual type from content patterns
            if (textContent.includes('sentiment') && textContent.includes('product')) {
                visualName = 'Sentiment by Product Category';
            } else if (textContent.includes('sales') && textContent.includes('region')) {
                visualName = 'Sales by Region';
            } else if (textContent.includes('revenue') && textContent.includes('time')) {
                visualName = 'Revenue Over Time';
            } else {
                // Generic naming based on position
                const allVisuals = document.querySelectorAll('.visual-container');
                const visualIndex = Array.from(allVisuals).indexOf(element) + 1;
                visualName = `Visual ${visualIndex}`;
            }
            console.log(`📋 Generated visual name: "${visualName}"`);
        }
        
        // Determine visual type
        if (element.classList.contains('slicer') || selector.includes('slicer')) {
            visualType = 'slicer';
        } else if (element.classList.contains('table') || selector.includes('table')) {
            visualType = 'table';
        } else if (element.classList.contains('chart') || selector.includes('chart')) {
            visualType = 'chart';
        } else {
            visualType = 'visual';
        }
        
        // Check if visual has export capabilities (look for context menu or export buttons)
        const hasExportCapability = checkVisualExportCapability(element);
        
        return {
            element: element,
            name: visualName,
            type: visualType,
            normalizedName: visualName.toLowerCase(),
            selector: selector,
            hasExportCapability: hasExportCapability
        };
    }
    
    // Check if a visual has export capabilities
    function checkVisualExportCapability(visualElement) {
        // Look for export buttons or context menu indicators
        const exportIndicators = [
            '[title*="export"]', '[aria-label*="export"]',
            '[title*="download"]', '[aria-label*="download"]',
            '.export-button', '.download-button', 
            '[data-automation-id*="export"]', '[data-testid*="export"]',
            '.context-menu', '.more-options', '.visual-menu'
        ];
        
        for (const selector of exportIndicators) {
            if (visualElement.querySelector(selector)) {
                return true;
            }
        }
        
        // Most Power BI visuals support export via right-click context menu
        return true; // Assume all visuals can be exported
    }
    
    // Find matching visual for export
    function findMatchingVisual(visualName, visuals) {
        const nameLower = visualName.toLowerCase().trim();
        console.log(`🔍 Looking for visual matching: "${visualName}" (normalized: "${nameLower}")`);
        console.log(`📋 Available visuals (${visuals.length}):`);
        visuals.forEach((v, i) => {
            console.log(`  ${i+1}. "${v.name}" (normalized: "${v.normalizedName}")`);
        });
        
        // Strategy 1: Exact match
        for (const visual of visuals) {
            if (visual.normalizedName === nameLower) {
                console.log(`✅ EXACT match found: "${visual.name}"`);
                return visual;
            }
        }
        
        // Strategy 2: Enhanced substring matching with aggressive keyword matching
        const keywords = nameLower.split(/\s+/).filter(word => word.length > 2);
        let bestMatch = null;
        let bestScore = 0;
        
        console.log(`🔍 Searching with keywords: [${keywords.join(', ')}]`);
        
        for (const visual of visuals) {
            let score = 0;
            const visualWords = visual.normalizedName.split(/\s+/);
            
            console.log(`🔍 Checking visual "${visual.name}" with words: [${visualWords.join(', ')}]`);
            
            // Count matching keywords
            let matchedKeywords = 0;
            for (const keyword of keywords) {
                let keywordMatched = false;
                
                for (const visualWord of visualWords) {
                    if (visualWord.includes(keyword) || keyword.includes(visualWord)) {
                        score += keyword === visualWord ? 20 : 10;
                        keywordMatched = true;
                        console.log(`  ✅ Keyword "${keyword}" matches word "${visualWord}" (score +${keyword === visualWord ? 20 : 10})`);
                    }
                }
                
                // Also check if the keyword appears anywhere in the visual name
                if (visual.normalizedName.includes(keyword)) {
                    score += 5;
                    keywordMatched = true;
                    console.log(`  ✅ Keyword "${keyword}" found in full name (score +5)`);
                }
                
                if (keywordMatched) {
                    matchedKeywords++;
                }
            }
            
            // Bonus for matching most/all keywords
            const keywordCoverage = matchedKeywords / keywords.length;
            if (keywordCoverage >= 0.7) { // Match at least 70% of keywords
                score += 20;
                console.log(`  🎯 Good keyword coverage: ${matchedKeywords}/${keywords.length} = ${Math.round(keywordCoverage * 100)}% (bonus +20)`);
            }
            
            console.log(`  📊 Total score for "${visual.name}": ${score}`);
            
            if (score > bestScore && score > 15) { // Lower threshold for better matching
                bestScore = score;
                bestMatch = visual;
            }
        }
        
        if (bestMatch) {
            console.log(`✅ Best match found: "${bestMatch.name}" (score: ${bestScore})`);
            return bestMatch;
        }
        
        // Strategy 3: Fuzzy matching - look for any visual that contains key terms
        console.log(`🔍 Strategy 3: Fuzzy matching for key terms...`);
        for (const keyword of keywords) {
            if (keyword.length > 4) { // Only use longer keywords for fuzzy matching
                for (const visual of visuals) {
                    if (visual.normalizedName.includes(keyword)) {
                        console.log(`✅ Fuzzy match found: "${visual.name}" contains keyword "${keyword}"`);
                        return visual;
                    }
                }
            }
        }
        
        // Strategy 4: Partial phrase matching
        console.log(`🔍 Strategy 4: Partial phrase matching...`);
        if (keywords.length >= 2) {
            // Try combinations of keywords
            for (let i = 0; i < keywords.length - 1; i++) {
                const phrase = keywords[i] + ' ' + keywords[i + 1];
                for (const visual of visuals) {
                    if (visual.normalizedName.includes(phrase)) {
                        console.log(`✅ Partial phrase match found: "${visual.name}" contains "${phrase}"`);
                        return visual;
                    }
                }
            }
        }
        
        console.log(`❌ No matching visual found for: "${visualName}"`);
        return null;
    }
    
    // Export specific visual with enhanced debugging and multiple strategies
    function exportSpecificVisual(visual, format, originalCommand) {
        console.log(`📤 STARTING exportSpecificVisual for: "${visual.name}" to ${format}`);
        console.log(`📋 Visual element:`, visual.element);
        console.log(`📋 Visual selector: ${visual.selector}`);
        
        addMessage(`✅ Found "${visual.name}" visual!\n\n📤 Attempting to export to ${format.toUpperCase()}...`, 'bot');
        
        try {
            // Scroll visual into view and highlight it immediately
            visual.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            highlightVisual(visual);
            
            // IMPORTANT: Hover over the visual to reveal hidden export buttons
            console.log(`🎯 Step 0: Hovering over visual to reveal hidden controls...`);
            const hoverEvent = new MouseEvent('mouseover', {
                bubbles: true,
                cancelable: true,
                view: window,
                clientX: visual.element.getBoundingClientRect().left + visual.element.getBoundingClientRect().width / 2,
                clientY: visual.element.getBoundingClientRect().top + visual.element.getBoundingClientRect().height / 2
            });
            visual.element.dispatchEvent(hoverEvent);
            
            // Also try hovering on visual header area specifically
            const visualHeader = visual.element.querySelector('.visual-header, .visualHeader, .chart-header');
            if (visualHeader) {
                console.log(`🎯 Also hovering over visual header to reveal more options...`);
                visualHeader.dispatchEvent(hoverEvent);
            }
            
            setTimeout(async () => {
                console.log(`🎯 Step 1: Trying enhanced direct export button...`);
                const directExportResult = await tryDirectExportButton(visual, format);
                console.log(`📋 Direct export result:`, directExportResult);
                
                if (directExportResult && directExportResult.success) {
                    console.log(`✅ Export initiated via direct button: ${directExportResult.method}`);
                    addMessage(`✅ Export initiated for "${visual.name}"!\n\n📤 Method: ${directExportResult.method}\n\n📥 Check your downloads folder for the ${format.toUpperCase()} file.\n\n⏰ If no file appears in 15 seconds, try the manual instructions below.`, 'bot');
                    return;
                }
                
                console.log(`🎯 Step 2: Trying context menu export...`);
                tryContextMenuExportAsync(visual, format).then(contextMenuResult => {
                    console.log(`📋 Context menu export result: ${contextMenuResult}`);
                    
                    if (contextMenuResult) {
                        console.log(`✅ Export initiated via context menu`);
                        addMessage(`✅ Export initiated for "${visual.name}" via context menu!\n\n📥 Check your downloads folder for the ${format.toUpperCase()} file.\n\n⏰ If no file appears in 10 seconds, the export may not have worked.`, 'bot');
                    } else {
                        console.log(`🎯 Step 3: Trying Power BI visual menu...`);
                        const visualMenuResult = tryPowerBIVisualMenu(visual, format);
                        
                        if (visualMenuResult) {
                            console.log(`✅ Export initiated via Power BI visual menu`);
                            addMessage(`✅ Export initiated for "${visual.name}" via visual menu!\n\n📥 Check your downloads folder for the ${format.toUpperCase()} file.`, 'bot');
                        } else {
                            console.log(`⚠️ All automatic export methods failed, showing manual instructions`);
                            addMessage(`🔍 Found "${visual.name}" visual (highlighted in red), but couldn't automatically export it.\n\n📋 **Manual Export Instructions:**\n\n1️⃣ Right-click on the highlighted visual\n2️⃣ Select "Export data" or "Export to Excel"\n3️⃣ Choose your preferred format\n4️⃣ Click "Export"\n\n💡 **Alternative Methods:**\n• Look for three-dot menu (...) on the visual\n• Hover over the visual to see export icons\n• Check if there's a "More options" button\n\n🔍 **Debug Info:**\nVisual: ${visual.name}\nElement: ${visual.element.tagName}\nClasses: ${visual.element.className}`, 'bot');
                        }
                    }
                }).catch(error => {
                    console.error(`❌ Error in context menu export:`, error);
                    addMessage(`❌ Error during export process: ${error.message}\n\nPlease try manual export by right-clicking on the highlighted visual.`, 'bot');
                });
                
            }, 1000);
        } catch (error) {
            console.error(`❌ Error exporting visual:`, error);
            addMessage(`❌ Error exporting "${visual.name}": ${error.message}\n\nPlease try the manual export method by right-clicking on the visual.`, 'bot');
        }
    }
    
    // Try to find and click direct export button with enhanced debugging
    async function tryDirectExportButton(visual, format) {
        console.log(`🔍 ENHANCED SEARCH for direct export buttons in visual: "${visual.name}"`);
        console.log(`📋 Visual element classes: "${visual.element.className}"`);
        console.log(`📋 Visual element tag: "${visual.element.tagName}"`);
        
        const exportSelectors = [
            // Standard Power BI export buttons
            '[title*="export"]', '[aria-label*="export"]',
            '[title*="Export"]', '[aria-label*="Export"]',
            '[title*="download"]', '[aria-label*="download"]',
            '[title*="Download"]', '[aria-label*="Download"]',
            '[data-automation-id*="export"]', '[data-testid*="export"]',
            
            // More options and three-dot menus (very common in Power BI)
            '[aria-label*="More options"]', '[title*="More options"]',
            '[aria-label*="more options"]', '[title*="more options"]', 
            '[aria-label*="More actions"]', '[title*="More actions"]',
            '[aria-label*="..."]', '[title*="..."]',
            '.more-options', '.ellipsis', '.three-dot-menu',
            '[class*="more-options"]', '[class*="ellipsis"]',
            '[data-automation-id*="more"]', '[data-automation-id*="menu"]',
            
            // Visual header and action buttons
            '.visual-header-action-button', '.visual-menu-button',
            '.visual-header button', '.visualHeader button',
            '.chart-header button', '.visual-title-container button',
            
            // Angular/Power BI specific for ng-star-inserted components
            '.visual-container-component button', 
            '.ng-star-inserted button',
            'button[class*="visual-"]', 'button[class*="chart-"]',
            
            // Direct export buttons
            '.export-button', '.download-button', '.save-button',
            'button[class*="export"]', 'button[class*="download"]'
        ];
        
        console.log(`📋 Checking ${exportSelectors.length} export button selectors...`);
        
        // Search containers in order of preference
        const searchContainers = [
            { element: visual.element, name: 'Visual element itself' },
            { element: visual.element.querySelector('.visual-header'), name: 'Visual header' },
            { element: visual.element.querySelector('.visualHeader'), name: 'Visual header (alt)' },
            { element: visual.element.parentElement, name: 'Parent element' },
            { element: visual.element.closest('.visual-container'), name: 'Visual container' },
            { element: visual.element.closest('.visual-container-component'), name: 'Visual container component' }
        ].filter(container => container.element);
        
        console.log(`🔍 Searching in ${searchContainers.length} containers...`);
        
        for (let containerIndex = 0; containerIndex < searchContainers.length; containerIndex++) {
            const container = searchContainers[containerIndex];
            console.log(`🔍 Container ${containerIndex + 1}: ${container.name} - Classes: "${container.element.className}"`);
            
            for (let i = 0; i < exportSelectors.length; i++) {
                const selector = exportSelectors[i];
                
                const buttons = container.element.querySelectorAll(selector);
                if (buttons.length > 0) {
                    console.log(`✅ Found ${buttons.length} button(s) with selector: ${selector} in ${container.name}`);
                    
                    for (let buttonIndex = 0; buttonIndex < buttons.length; buttonIndex++) {
                        const button = buttons[buttonIndex];
                        
                        // Check if button is visible
                        const isVisible = button.offsetWidth > 0 && button.offsetHeight > 0;
                        const buttonText = button.textContent?.trim() || '';
                        const ariaLabel = button.getAttribute('aria-label') || '';
                        const title = button.getAttribute('title') || '';
                        
                        console.log(`📋 Button ${buttonIndex + 1} details:`, {
                            text: buttonText,
                            ariaLabel: ariaLabel,
                            title: title,
                            className: button.className,
                            visible: isVisible,
                            tagName: button.tagName
                        });
                        
                        if (!isVisible) {
                            console.log(`⚠️ Skipping invisible button`);
                            continue;
                        }
                        
                        try {
                            console.log(`🖱️ Attempting to click button...`);
                            
                            // Scroll into view and focus
                            button.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            await delay(200);
                            
                            // Hover to potentially reveal more options
                            const hoverEvent = new MouseEvent('mouseover', {
                                bubbles: true,
                                cancelable: true,
                                view: window
                            });
                            button.dispatchEvent(hoverEvent);
                            await delay(300);
                            
                            // Click the button
                            await simulateClick(button);
                            await delay(1000); // Wait for potential menu to appear
                            
                            console.log(`✅ Successfully clicked button, checking for menus...`);
                            
                            // Check for export menus or dialogs that might have appeared
                            const menuSelectors = [
                                '[role="menu"]', '[role="dialog"]', 
                                '.context-menu', '.export-menu', '.dropdown-menu',
                                '.popup-menu', '[class*="menu"]', '[class*="contextual"]',
                                '[data-automation-id*="menu"]', '[data-automation-id*="export"]'
                            ];
                            
                            let foundMenu = false;
                            for (const menuSelector of menuSelectors) {
                                const menu = document.querySelector(menuSelector);
                                if (menu && menu.offsetWidth > 0 && menu.offsetHeight > 0) {
                                    console.log(`✅ Found menu with selector: ${menuSelector}`);
                                    foundMenu = true;
                                    
                                    // Look for Excel/CSV export options
                                    const exportOptions = menu.querySelectorAll('*');
                                    for (const option of exportOptions) {
                                        const optionText = option.textContent?.toLowerCase() || '';
                                        const optionAriaLabel = option.getAttribute('aria-label')?.toLowerCase() || '';
                                        
                                        if ((optionText.includes('excel') || optionText.includes('.xlsx') ||
                                            optionText.includes('export data') || optionText.includes('export to excel') ||
                                            optionAriaLabel.includes('excel') || optionAriaLabel.includes('xlsx')) &&
                                            option.offsetWidth > 0 && option.offsetHeight > 0) {
                                            
                                            console.log(`� Clicking Excel export option: "${option.textContent?.trim()}"`);
                                            await delay(200);
                                            await simulateClick(option);
                                            await delay(2000); // Wait for export to process
                                            return { success: true, method: `Direct export → Excel via ${container.name}` };
                                        }
                                    }
                                    
                                    // Try general export if no Excel found
                                    for (const option of exportOptions) {
                                        const optionText = option.textContent?.toLowerCase() || '';
                                        const optionAriaLabel = option.getAttribute('aria-label')?.toLowerCase() || '';
                                        
                                        if ((optionText.includes('export') || optionText.includes('download') ||
                                            optionAriaLabel.includes('export') || optionAriaLabel.includes('download')) &&
                                            option.offsetWidth > 0 && option.offsetHeight > 0 && 
                                            !optionText.includes('cancel')) {
                                            
                                            console.log(`📤 Clicking general export option: "${option.textContent?.trim()}"`);
                                            await delay(200);
                                            await simulateClick(option);
                                            await delay(2000);
                                            return { success: true, method: `Direct export → General via ${container.name}` };
                                        }
                                    }
                                    break;
                                }
                            }
                            
                            if (foundMenu) {
                                return { success: true, method: `Menu opened via ${container.name} (manual selection needed)` };
                            } else {
                                // Button might have triggered direct export
                                console.log(`ℹ️ No menu detected, button may have triggered direct export`);
                                return { success: true, method: `Direct export click via ${container.name}` };
                            }
                            
                        } catch (clickError) {
                            console.error(`❌ Error clicking button in ${container.name}:`, clickError);
                        }
                    }
                }
            }
        }
        
        console.log(`❌ No export buttons found in any container`);
        return { success: false, method: 'Direct export button search failed' };
    }
    
    // Try context menu export with proper async handling
    async function tryContextMenuExportAsync(visual, format) {
        return new Promise((resolve) => {
            try {
                console.log(`🔍 TRYING context menu export for: "${visual.name}"`);
                
                // Right-click on the visual to open context menu
                const rect = visual.element.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                
                console.log(`📋 Right-clicking at position: (${centerX}, ${centerY})`);
                
                const rightClickEvent = new MouseEvent('contextmenu', {
                    bubbles: true,
                    cancelable: true,
                    clientX: centerX,
                    clientY: centerY,
                    button: 2
                });
                
                visual.element.dispatchEvent(rightClickEvent);
                console.log(`✅ Right-click event dispatched`);
                
                // Wait for context menu and try to find export option
                setTimeout(() => {
                    console.log(`🔍 Looking for context menu...`);
                    
                    const contextMenuSelectors = [
                        '[role="menu"]', '.context-menu', '.popup-menu', '.contextual-menu',
                        '[aria-label*="context"]', '[data-automation-id*="menu"]',
                        '.ms-ContextualMenu', '.visual-context-menu', '.power-bi-menu'
                    ];
                    
                    let foundMenu = false;
                    
                    for (const menuSelector of contextMenuSelectors) {
                        const contextMenu = document.querySelector(menuSelector);
                        if (contextMenu) {
                            foundMenu = true;
                            console.log(`✅ Found context menu with selector: ${menuSelector}`);
                            console.log(`📋 Menu content preview: "${contextMenu.textContent?.substring(0, 100)}..."`);
                            
                            // Look for export option in context menu with multiple patterns
                            const exportSelectors = [
                                '[title*="export"]', '[aria-label*="export"]',
                                '[title*="download"]', '[aria-label*="download"]',
                                '[title*="Export"]', '[aria-label*="Export"]',
                                '*[textContent*="Export"]', '*[textContent*="export"]',
                                '*[textContent*="Download"]', '*[textContent*="download"]'
                            ];
                            
                            for (const exportSelector of exportSelectors) {
                                const exportOption = contextMenu.querySelector(exportSelector);
                                if (exportOption) {
                                    console.log(`✅ Found export option: ${exportSelector}`);
                                    console.log(`📋 Export option text: "${exportOption.textContent?.trim()}"`);
                                    
                                    try {
                                        exportOption.click();
                                        console.log(`✅ Successfully clicked export option`);
                                        resolve(true);
                                        return;
                                    } catch (clickError) {
                                        console.error(`❌ Error clicking export option:`, clickError);
                                    }
                                }
                            }
                            
                            // Also search by text content
                            const allMenuItems = contextMenu.querySelectorAll('*');
                            for (const item of allMenuItems) {
                                const text = item.textContent?.toLowerCase() || '';
                                if (text.includes('export') || text.includes('download')) {
                                    console.log(`🔍 Found potential export item by text: "${text}"`);
                                    try {
                                        item.click();
                                        console.log(`✅ Clicked export item by text`);
                                        resolve(true);
                                        return;
                                    } catch (clickError) {
                                        console.error(`❌ Error clicking text export item:`, clickError);
                                    }
                                }
                            }
                        }
                    }
                    
                    if (!foundMenu) {
                        console.log(`❌ No context menu found`);
                    } else {
                        console.log(`❌ Context menu found but no export options`);
                    }
                    
                    resolve(false);
                }, 1000); // Wait longer for menu to appear
                
            } catch (error) {
                console.error(`❌ Error with context menu export:`, error);
                resolve(false);
            }
        });
    }
    
    // Add new method to try Power BI visual menu (three dots)
    function tryPowerBIVisualMenu(visual, format) {
        console.log(`🔍 TRYING Power BI visual menu for: "${visual.name}"`);
        
        // Look for Power BI visual menu buttons (three dots, more options, etc.)
        const menuSelectors = [
            '.visual-header .more-options', '.visual-header .ellipsis',
            '[data-automation-id*="more"]', '[aria-label*="More"]',
            '.three-dot-menu', '.visual-menu', '.chart-menu',
            '[title*="More options"]', '[title*="Visual actions"]'
        ];
        
        for (const selector of menuSelectors) {
            console.log(`🔍 Checking menu selector: ${selector}`);
            const menuButton = visual.element.querySelector(selector) || 
                              visual.element.parentElement?.querySelector(selector);
            
            if (menuButton) {
                console.log(`✅ Found visual menu button: ${selector}`);
                try {
                    menuButton.click();
                    
                    // Wait for menu to appear and look for export
                    setTimeout(() => {
                        const exportItems = document.querySelectorAll(
                            '[role="menuitem"], [role="button"], .menu-item'
                        );
                        
                        for (const item of exportItems) {
                            const text = item.textContent?.toLowerCase() || '';
                            if (text.includes('export') || text.includes('download')) {
                                console.log(`✅ Found export in visual menu: "${text}"`);
                                item.click();
                                return true;
                            }
                        }
                    }, 500);
                    
                    return true;
                } catch (error) {
                    console.error(`❌ Error clicking visual menu:`, error);
                }
            }
        }
        
        console.log(`❌ No Power BI visual menu found`);
        return false;
    }
    
    // Highlight visual for user visibility with enhanced effects
    function highlightVisual(visual) {
        console.log(`🎨 Highlighting visual: "${visual.name}"`);
        
        const originalBorder = visual.element.style.border;
        const originalBoxShadow = visual.element.style.boxShadow;
        const originalBackground = visual.element.style.background;
        const originalZIndex = visual.element.style.zIndex;
        
        // Add strong highlight with animation
        visual.element.style.border = '4px solid #ff4444';
        visual.element.style.boxShadow = '0 0 30px rgba(255, 68, 68, 0.8), inset 0 0 20px rgba(255, 68, 68, 0.2)';
        visual.element.style.background = 'rgba(255, 68, 68, 0.1)';
        visual.element.style.zIndex = '9999';
        visual.element.style.transition = 'all 0.3s ease';
        
        // Add pulsing animation
        let pulseCount = 0;
        const pulseInterval = setInterval(() => {
            pulseCount++;
            if (pulseCount > 6) { // Pulse 3 times
                clearInterval(pulseInterval);
                return;
            }
            
            if (pulseCount % 2 === 0) {
                visual.element.style.boxShadow = '0 0 40px rgba(255, 68, 68, 1), inset 0 0 30px rgba(255, 68, 68, 0.3)';
            } else {
                visual.element.style.boxShadow = '0 0 20px rgba(255, 68, 68, 0.6), inset 0 0 10px rgba(255, 68, 68, 0.1)';
            }
        }, 400);
        
        // Remove highlight after 10 seconds (longer than before)
        setTimeout(() => {
            visual.element.style.border = originalBorder;
            visual.element.style.boxShadow = originalBoxShadow;
            visual.element.style.background = originalBackground;
            visual.element.style.zIndex = originalZIndex;
            visual.element.style.transition = '';
            console.log(`🎨 Highlight removed from visual: "${visual.name}"`);
        }, 10000);
    }
    
    // Show available visuals for export
    function showAvailableVisualsForExport(visuals, requestedName) {
        if (visuals.length === 0) {
            addMessage(`❌ No exportable visuals found on this page.\n\n💡 Make sure you're on a Power BI report with visual charts, tables, or graphs.`, 'bot');
            return;
        }
        
        let message = '';
        
        if (requestedName) {
            message += `❌ Could not find "${requestedName}" visual.\n\n`;
        }
        
        message += `📊 **Available Visuals for Export** (${visuals.length}):\n\n`;
        
        visuals.forEach((visual, index) => {
            message += `${index + 1}️⃣ **${visual.name}** (${visual.type})\n`;
        });
        
        message += `\n💡 **Try these export commands:**\n`;
        visuals.slice(0, 3).forEach(visual => {
            const cleanName = visual.name.replace(/visual \d+/i, '').trim();
            if (cleanName) {
                message += `• "Export ${cleanName}"\n`;
                message += `• "Download ${cleanName} to Excel"\n`;
            }
        });
        
        message += `\n🔧 **Or manually export:**\n`;
        message += `1️⃣ Right-click on any visual\n`;
        message += `2️⃣ Select "Export data" or "Export to Excel"\n`;
        message += `3️⃣ Choose format (Excel, CSV, etc.)\n`;
        message += `4️⃣ Click "Export"`;
        
        addMessage(message, 'bot');
    }
    
    // Make chatbot draggable
    function makeDraggable() {
        const header = document.querySelector('.chatbot-header');
        const chatbot = document.getElementById('enhanced-powerbi-chatbot');
        let isDragging = false;
        let startX, startY, startLeft, startTop;
        
        header.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            const rect = chatbot.getBoundingClientRect();
            startLeft = rect.left;
            startTop = rect.top;
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });
        
        const onMouseMove = (e) => {
            if (!isDragging) return;
            const deltaX = e.clientX - startX;
            const deltaY = e.clientY - startY;
            chatbot.style.left = (startLeft + deltaX) + 'px';
            chatbot.style.top = (startTop + deltaY) + 'px';
            chatbot.style.right = 'auto';
            chatbot.style.bottom = 'auto';
        };
        
        const onMouseUp = () => {
            isDragging = false;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
    }

    // Main initialization
    function initializeChatbot() {
        console.log('🔍 Checking if on Power BI page...');
        
        if (!isPowerBIPage()) {
            console.log('❌ Not on a Power BI page, chatbot will not load');
            return;
        }

        console.log('✅ Power BI page detected');

        // Wait for page to load
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setTimeout(createEnhancedChatbot, 2000);
            });
        } else {
            setTimeout(createEnhancedChatbot, 2000);
        }

        // Also try after a longer delay for dynamic content
        setTimeout(createEnhancedChatbot, 5000);
    }

    // ========================================
    // UTILITY HELPER FUNCTIONS
    // ========================================
    
    // Simulate a mouse click with proper event handling
    async function simulateClick(element) {
        if (!element) return false;
        
        try {
            // Create and dispatch mouse events
            const mouseEvents = ['mouseover', 'mousedown', 'mouseup', 'click'];
            
            for (const eventType of mouseEvents) {
                const event = new MouseEvent(eventType, {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                    clientX: element.getBoundingClientRect().left + element.getBoundingClientRect().width / 2,
                    clientY: element.getBoundingClientRect().top + element.getBoundingClientRect().height / 2
                });
                element.dispatchEvent(event);
                
                // Small delay between events
                if (eventType !== 'click') {
                    await delay(50);
                }
            }
            
            // Also try the direct click method as fallback
            element.click();
            
            console.log(`✅ Successfully simulated click on element`);
            return true;
        } catch (error) {
            console.error(`❌ Error simulating click:`, error);
            
            // Fallback to simple click
            try {
                element.click();
                return true;
            } catch (fallbackError) {
                console.error(`❌ Fallback click also failed:`, fallbackError);
                return false;
            }
        }
    }
    
    // Delay utility function
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // Make the chatbot draggable
    function makeDraggable() {
        const chatbot = document.getElementById('enhanced-powerbi-chatbot');
        const header = chatbot.querySelector('.chatbot-header');
        
        let isDragging = false;
        let currentX;
        let currentY;
        let initialX;
        let initialY;
        let xOffset = 0;
        let yOffset = 0;

        header.addEventListener('mousedown', dragStart);
        document.addEventListener('mousemove', drag);
        document.addEventListener('mouseup', dragEnd);

        function dragStart(e) {
            if (e.target.tagName === 'BUTTON') return; // Don't drag when clicking buttons
            
            initialX = e.clientX - xOffset;
            initialY = e.clientY - yOffset;

            if (e.target === header) {
                isDragging = true;
                header.style.cursor = 'grabbing';
            }
        }

        function drag(e) {
            if (isDragging) {
                e.preventDefault();
                
                currentX = e.clientX - initialX;
                currentY = e.clientY - initialY;

                xOffset = currentX;
                yOffset = currentY;

                chatbot.style.transform = `translate(${currentX}px, ${currentY}px)`;
            }
        }

        function dragEnd() {
            initialX = currentX;
            initialY = currentY;

            isDragging = false;
            header.style.cursor = 'move';
        }
    }

    // ========================================
    // TABLE COLUMN SELECTION FUNCTIONS
    // ========================================
    
    // Handle commands to select specific columns from table visuals
    async function handleTableColumnSelection(normalizedCommand, originalCommand) {
        console.log(`📊 STARTING handleTableColumnSelection`);
        console.log(`📋 Original command: "${originalCommand}"`);
        console.log(`📋 Normalized command: "${normalizedCommand}"`);
        
        try {
            // Step 1: Find all table visuals on the current page
            const tableVisuals = await findTableVisuals();
            console.log(`📊 Found ${tableVisuals.length} table visual(s) on the page`);
            
            if (tableVisuals.length === 0) {
                addMessage(`❌ No table visuals found on this page. Please navigate to a page with tables first.`, 'bot');
                return;
            }
            
            // Step 2: Extract target table name and column numbers/names from the command
            const { targetTable, columnRequests } = extractTableAndColumnInfo(normalizedCommand);
            console.log(`🎯 Target table: "${targetTable || 'any table'}"`);
            console.log(`🎯 Column requests:`, columnRequests);
            
            if (columnRequests.length === 0) {
                addMessage(`❓ I couldn't determine which columns you want to see. Please specify column numbers or names.
                
📝 Examples:
• "Select columns 1, 3, 5 from Sales Table"
• "Show columns Product, Price, Quantity in Revenue visual"`, 'bot');
                return;
            }
            
            // Step 3: Find the matching table visual based on name (if provided)
            let targetVisual = null;
            
            if (targetTable) {
                // Find by name
                targetVisual = findTableVisualByName(tableVisuals, targetTable);
                
                if (!targetVisual) {
                    // If we couldn't find an exact match, show available tables
                    const availableTables = tableVisuals.map(v => v.title).filter(Boolean);
                    
                    addMessage(`❌ I couldn't find a table visual named "${targetTable}".
                    
📊 Available tables on this page:
${formatTableList(availableTables)}

✅ Try: "Select column 1 from ${availableTables[0] || 'Table'}"`, 'bot');
                    return;
                }
            } else if (tableVisuals.length === 1) {
                // If only one table and no name specified, use that one
                targetVisual = tableVisuals[0];
            } else {
                // Multiple tables but no specific one requested
                const availableTables = tableVisuals.map(v => v.title).filter(Boolean);
                
                addMessage(`❓ I found ${tableVisuals.length} table visuals on this page. Please specify which one:
                
📊 Available tables:
${formatTableList(availableTables)}

✅ Try: "Select column 1 from ${availableTables[0] || 'Table'}"`, 'bot');
                return;
            }
            
            // Step 4: Apply column selection to the target table
            console.log(`🎯 Target visual identified: "${targetVisual.title || 'Unnamed table'}"`);
            
            const result = await selectTableColumns(targetVisual, columnRequests);
            
            if (result.success) {
                let successMessage = `✅ Success! Column selection applied to "${targetVisual.title || 'table'}".\n\n`;
                
                if (result.selectedColumns.length === 1) {
                    successMessage += `📊 Now showing the "${result.selectedColumns[0]}" column only.\n\n`;
                } else {
                    successMessage += `📊 Now showing columns: ${result.selectedColumns.join(', ')}\n\n`;
                }
                
                successMessage += `� Found ${targetVisual.headers.length} total columns in the table.\n`;
                successMessage += `💡 All other columns are now hidden.`;
                
                addMessage(successMessage, 'bot');
            } else {
                addMessage(`❌ Error applying column selection: ${result.error}

💡 Try specifying columns by number (e.g., "columns 1, 2, 3") or by exact name.`, 'bot');
            }
        } catch (error) {
            console.error(`❌ Error in handleTableColumnSelection:`, error);
            addMessage(`❌ Error processing column selection: ${error.message}

💡 This feature works best with standard Power BI table visuals.`, 'bot');
        }
    }
    
    // Find all table visuals on the current Power BI page
    async function findTableVisuals() {
        console.log(`🔍 Looking for table visuals on page...`);
        
        const tableVisuals = [];
        
        // APPROACH 1: Look for standard Power BI table visual containers
        const visualContainers = document.querySelectorAll('.visualContainer, .visual-container, [data-automation-id*="visual"]');
        console.log(`🔍 Found ${visualContainers.length} visual containers to check`);
        
        for (const container of visualContainers) {
            try {
                // Check if this container has a table
                const hasTable = container.querySelector('div.tableEx, table, .pivotTable, [class*="tableVisual"], [class*="gridVisual"]');
                
                if (hasTable) {
                    console.log(`✅ Found table visual in container:`, container);
                    
                    // Try to get the title from various potential elements
                    let title = null;
                    const titleElements = [
                        container.querySelector('.visualTitle'),
                        container.querySelector('[class*="title"]'),
                        container.querySelector('[aria-label*="table"]'),
                        container.querySelector('[data-automation-id*="title"]'),
                        container.closest('[aria-label]')
                    ];
                    
                    for (const element of titleElements) {
                        if (element && element.textContent.trim()) {
                            title = element.textContent.trim();
                            break;
                        } else if (element && element.getAttribute('aria-label')) {
                            title = element.getAttribute('aria-label').trim();
                            break;
                        }
                    }
                    
                    // Get column headers
                    const headerElements = container.querySelectorAll('th, .headerCell, [role="columnheader"], [class*="headerCell"]');
                    const headers = Array.from(headerElements).map(el => el.textContent.trim()).filter(Boolean);
                    
                    console.log(`📊 Table title: "${title || 'Unnamed'}" with ${headers.length} detected columns`);
                    console.log(`📊 Column headers:`, headers.slice(0, 5).join(', ') + (headers.length > 5 ? '...' : ''));
                    
                    tableVisuals.push({
                        element: container,
                        hasTable: true,
                        title: title || null,
                        headers: headers,
                        tableElement: hasTable
                    });
                }
            } catch (error) {
                console.error(`❌ Error checking container for table:`, error);
            }
        }
        
        // APPROACH 2: Look for table-like structures anywhere on the page
        if (tableVisuals.length === 0) {
            console.log(`🔍 No standard table visuals found, looking for generic tables...`);
            
            const tables = document.querySelectorAll('table');
            for (const table of tables) {
                try {
                    // Check if this looks like a data table (not a layout table)
                    const rows = table.querySelectorAll('tr');
                    if (rows.length > 1) {
                        const headerCells = rows[0].querySelectorAll('th, td');
                        if (headerCells.length > 1) {
                            const headers = Array.from(headerCells).map(el => el.textContent.trim()).filter(Boolean);
                            
                            console.log(`📊 Generic table with ${headers.length} detected columns`);
                            
                            // Try to find a title for this table
                            const possibleTitles = [
                                table.getAttribute('aria-label'),
                                table.getAttribute('title'),
                                table.caption?.textContent,
                                table.closest('[aria-label]')?.getAttribute('aria-label')
                            ];
                            
                            const title = possibleTitles.filter(Boolean)[0] || null;
                            
                            tableVisuals.push({
                                element: table,
                                hasTable: true,
                                title: title,
                                headers: headers,
                                tableElement: table
                            });
                        }
                    }
                } catch (error) {
                    console.error(`❌ Error checking generic table:`, error);
                }
            }
        }
        
        return tableVisuals;
    }
    
    // Find a specific table visual by name
    function findTableVisualByName(tableVisuals, targetName) {
        console.log(`🔍 Looking for table named "${targetName}" among ${tableVisuals.length} tables`);
        
        // Handle special cases
        if (!targetName || targetName.trim() === "") {
            console.log(`🔍 No specific table name provided, will select first table if available`);
            return tableVisuals.length > 0 ? tableVisuals[0] : null;
        }
        
        // Clean and normalize the target name
        const targetLower = targetName.toLowerCase().trim();
        
        // First try exact match
        for (const visual of tableVisuals) {
            if (visual.title && visual.title.toLowerCase() === targetLower) {
                console.log(`✅ Found exact match: "${visual.title}"`);
                return visual;
            }
        }
        
        // Then try contains match
        for (const visual of tableVisuals) {
            if (visual.title && visual.title.toLowerCase().includes(targetLower)) {
                console.log(`✅ Found partial match: "${visual.title}" contains "${targetName}"`);
                return visual;
            }
        }
        
        // Then try reverse contains (target contains visual title)
        for (const visual of tableVisuals) {
            if (visual.title && targetLower.includes(visual.title.toLowerCase())) {
                console.log(`✅ Found reverse match: "${targetName}" contains "${visual.title}"`);
                return visual;
            }
        }
        
        // Then try fuzzy match (word intersection)
        const targetWords = targetLower.split(/\s+/).filter(w => w.length > 1); // Allow shorter words
        
        for (const visual of tableVisuals) {
            if (!visual.title) continue;
            
            const titleWords = visual.title.toLowerCase().split(/\s+/).filter(w => w.length > 1);
            const matchingWords = targetWords.filter(w => titleWords.some(tw => tw.includes(w) || w.includes(tw)));
            
            if (matchingWords.length > 0 && matchingWords.length >= targetWords.length / 2) {
                console.log(`✅ Found fuzzy match: "${visual.title}" matches words: ${matchingWords.join(', ')}`);
                return visual;
            }
        }
        
        console.log(`❌ No table visual found with name similar to "${targetName}"`);
        return null;
    }
    
    // Extract table name and column info from command
    function extractTableAndColumnInfo(command) {
        console.log(`🔍 Extracting table and column info from: "${command}"`);
        
        // Extract target table name
        let targetTable = null;
        let fromMatch = command.match(/from\s+(.+?)($|\s+(?:column|select|show))/i);
        let inMatch = command.match(/in\s+(.+?)($|\s+(?:column|select|show))/i);
        let visualMatch = command.match(/visual\s+(.+?)($|\s+(?:column|select|show))/i);
        
        if (fromMatch) targetTable = fromMatch[1].trim();
        else if (inMatch) targetTable = inMatch[1].trim();
        else if (visualMatch) targetTable = visualMatch[1].trim();
        
        // Extract column requests (by number or by name)
        const columnRequests = [];
        
        // Look for column numbers (e.g. "columns 1, 2, 3")
        const numberMatches = command.match(/column[s]?\s+(\d+(?:\s*,\s*\d+)*)/ig);
        if (numberMatches) {
            for (const match of numberMatches) {
                const numbers = match.replace(/column[s]?\s+/i, '')
                    .split(',')
                    .map(n => parseInt(n.trim(), 10))
                    .filter(n => !isNaN(n));
                
                columnRequests.push(...numbers.map(n => ({ type: 'number', value: n })));
            }
        }
        
        // Look for column names (e.g. "columns Product, Price")
        // This is trickier because we don't know the column names beforehand
        // We'll look for patterns like "columns X, Y, Z from" or "columns X Y Z in"
        if (columnRequests.length === 0) {
            let namesMatch = command.match(/column[s]?\s+([^,]+(?:\s*,\s*[^,]+)*)\s+(?:from|in|visual)/i);
            if (namesMatch) {
                const columnNames = namesMatch[1].split(',').map(name => name.trim()).filter(Boolean);
                columnRequests.push(...columnNames.map(name => ({ type: 'name', value: name })));
            }
        }
        
        // Handle simple column selection commands (e.g., "select Region from Sales Table")
        // that don't include the word "column"
        if (columnRequests.length === 0) {
            const selectMatch = command.match(/(?:select|show)\s+([^,]+(?:\s*,\s*[^,]+)*)\s+(?:from|in)/i);
            if (selectMatch) {
                const columnNames = selectMatch[1].split(',').map(name => name.trim()).filter(Boolean);
                
                // Filter out common words that might be mistaken for column names
                const commonWords = ['the', 'all', 'only', 'just', 'these', 'those', 'some'];
                const filteredNames = columnNames.filter(name => !commonWords.includes(name.toLowerCase()));
                
                if (filteredNames.length > 0) {
                    console.log(`🎯 Found column names in simple command: ${filteredNames.join(', ')}`);
                    columnRequests.push(...filteredNames.map(name => ({ type: 'name', value: name })));
                }
            }
        }
        
        console.log(`🎯 Extracted table: "${targetTable || 'any'}"`);
        console.log(`🎯 Extracted column requests:`, columnRequests.map(c => 
            c.type === 'number' ? `Column #${c.value}` : `Column "${c.value}"`).join(', '));
        
        return { targetTable, columnRequests };
    }
    
    // Apply column selection to table visual
    async function selectTableColumns(tableVisual, columnRequests) {
        console.log(`🎯 Selecting columns for table: "${tableVisual.title || 'Unnamed'}"`);
        console.log(`🎯 Available columns:`, tableVisual.headers);
        
        try {
            // First, identify which columns we need to keep visible
            const columnsToShow = [];
            const selectedColumnNames = [];
            
            // Process column requests
            for (const request of columnRequests) {
                if (request.type === 'number') {
                    // Column by index (1-based to 0-based)
                    const index = request.value - 1;
                    if (index >= 0 && index < tableVisual.headers.length) {
                        columnsToShow.push(index);
                        selectedColumnNames.push(tableVisual.headers[index] || `Column ${request.value}`);
                        console.log(`✅ Will show column #${request.value}: "${tableVisual.headers[index] || 'unnamed'}"`);
                    } else {
                        console.log(`❌ Column #${request.value} is out of range (max: ${tableVisual.headers.length})`);
                    }
                } else {
                    // Column by name
                    const nameToFind = request.value.toLowerCase();
                    const matchIndex = tableVisual.headers.findIndex(h => 
                        h.toLowerCase() === nameToFind || h.toLowerCase().includes(nameToFind));
                    
                    if (matchIndex >= 0) {
                        columnsToShow.push(matchIndex);
                        selectedColumnNames.push(tableVisual.headers[matchIndex]);
                        console.log(`✅ Will show column "${tableVisual.headers[matchIndex]}"`);
                    } else {
                        console.log(`❌ Could not find column named "${request.value}"`);
                    }
                }
            }
            
            if (columnsToShow.length === 0) {
                return { 
                    success: false, 
                    error: "None of the requested columns could be found in the table"
                };
            }
            
            // Now apply the column visibility
            const table = tableVisual.tableElement;
            const container = tableVisual.element;
            
            // METHOD 1: Try to use Power BI's own column visibility toggles if available
            const headerCheckboxes = container.querySelectorAll('[class*="headerCheckbox"], [class*="columnHeaderCheckbox"]');
            if (headerCheckboxes && headerCheckboxes.length > 0) {
                console.log(`🔍 Found ${headerCheckboxes.length} column header checkboxes`);
                
                // First, uncheck all to hide all columns
                for (let i = 0; i < headerCheckboxes.length; i++) {
                    const isChecked = headerCheckboxes[i].getAttribute('aria-checked') === 'true' ||
                                    headerCheckboxes[i].checked;
                    
                    if (isChecked) {
                        console.log(`🔍 Unchecking checkbox for column ${i}`);
                        headerCheckboxes[i].click();
                        // Give some time for UI to update
                        await new Promise(resolve => setTimeout(resolve, 100));
                    }
                }
                
                // Then check only the ones we want to show
                for (const colIndex of columnsToShow) {
                    if (colIndex < headerCheckboxes.length) {
                        console.log(`🔍 Checking checkbox for column ${colIndex}`);
                        headerCheckboxes[colIndex].click();
                        // Give some time for UI to update
                        await new Promise(resolve => setTimeout(resolve, 100));
                    }
                }
            }
            // METHOD 2: Use CSS to hide/show columns
            else {
                console.log(`🔍 No checkboxes found, using CSS to hide/show columns`);
                
                // Create a style element if not already present
                let styleId = `chatbot-table-column-style-${Date.now()}`;
                let styleEl = document.getElementById(styleId);
                
                if (!styleEl) {
                    styleEl = document.createElement('style');
                    styleEl.id = styleId;
                    document.head.appendChild(styleEl);
                }
                
                // Get all columns in the table
                const allColumnIndices = Array.from({ length: tableVisual.headers.length }, (_, i) => i);
                
                // Determine columns to hide
                const columnsToHide = allColumnIndices.filter(i => !columnsToShow.includes(i));
                console.log(`🔍 Hiding columns:`, columnsToHide);
                
                // Generate CSS to hide columns
                let css = '';
                
                // Target Power BI table structures
                if (container.querySelector('.tableEx')) {
                    columnsToHide.forEach(colIndex => {
                        css += `.tableEx [data-colindex="${colIndex}"] { display: none !important; }\n`;
                        css += `.tableEx [aria-colindex="${colIndex+1}"] { display: none !important; }\n`;
                    });
                }
                // Target regular HTML tables
                else {
                    columnsToHide.forEach(colIndex => {
                        css += `table th:nth-child(${colIndex+1}), table td:nth-child(${colIndex+1}) { display: none !important; }\n`;
                    });
                }
                
                styleEl.textContent = css;
                console.log(`✅ Applied CSS to hide columns:`, css);
            }
            
            return {
                success: true,
                selectedColumns: selectedColumnNames
            };
        } catch (error) {
            console.error(`❌ Error selecting columns:`, error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    // Format a list of tables for display
    function formatTableList(tables) {
        if (!tables || tables.length === 0) {
            return "• No named tables found";
        }
        
        return tables.map(t => `• "${t}"`).join('\n');
    }
    
    // ========================================
    // VISUAL RESET FUNCTIONS
    // ========================================
    
    // Extract visual name from reset command
    function extractVisualNameToReset(command) {
        console.log(`🔍 Extracting visual name from reset command: "${command}"`);
        
        // Check for the case where the command is just "reset table visual" or similar
        const genericResetPattern = /^(reset|restore)\s+(table|visual|table visual)$/i;
        if (genericResetPattern.test(command.trim())) {
            console.log(`🎯 Generic reset command detected, will target any table visual`);
            return ""; // Return empty string to indicate any table should be reset
        }
        
        // Remove "reset" and "visual" from the command
        let visualName = command.replace(/reset|visual|restore|return|show all columns|show all/gi, '')
            .replace(/to default|to original/gi, '')
            .trim();
            
        // If the only word left is "table", we should return empty string
        if (visualName.toLowerCase() === "table") {
            console.log(`🎯 Generic "table" reference detected, will target any table visual`);
            return "";
        }
        
        // Clean up any remaining spaces
        visualName = visualName.replace(/\s+/g, ' ').trim();
            
        console.log(`🎯 Extracted visual name: "${visualName}"`);
        return visualName;
    }
    
    // Handle reset visual command - restores a specific table visual to default view (all columns visible)
    async function handleResetVisualCommand(visualName, originalCommand) {
        console.log(`🔄 Processing RESET VISUAL command for "${visualName}"`);
        
        try {
            // First find all table visuals on the page
            const tableVisuals = await findTableVisuals();
            console.log(`📊 Found ${tableVisuals.length} table visual(s) on the page`);
            
            if (tableVisuals.length === 0) {
                addMessage(`❌ No table visuals found on this page. Please navigate to a page with tables first.`, 'bot');
                return;
            }
            
            let targetVisual = null;
            
            // If visual name was provided, try to find it
            if (visualName && visualName.length > 0) {
                targetVisual = findTableVisualByName(tableVisuals, visualName);
                
                if (!targetVisual) {
                    // If we couldn't find an exact match, show available tables
                    const availableTables = tableVisuals.map(v => v.title).filter(Boolean);
                    
                    addMessage(`❌ I couldn't find a table visual named "${visualName}".
                    
📊 Available tables on this page:
${formatTableList(availableTables)}

✅ Try: "Reset ${availableTables[0] || 'Table'}"`, 'bot');
                    return;
                }
            } else if (tableVisuals.length === 1) {
                // If only one table and no name specified, use that one
                targetVisual = tableVisuals[0];
                console.log(`🎯 No specific table name given but only one table exists: "${targetVisual.title || 'Unnamed table'}"`);
            } else {
                // For voice commands like "Reset table visual", just use the first table
                if (originalCommand && originalCommand.toLowerCase().includes("reset") && 
                    (originalCommand.toLowerCase().includes("table") || originalCommand.toLowerCase().includes("visual"))) {
                    console.log(`🎯 Voice command detected: "${originalCommand}" - using first table`);
                    targetVisual = tableVisuals[0];
                } else {
                    // Multiple tables but no specific one requested
                    const availableTables = tableVisuals.map(v => v.title).filter(Boolean);
                    
                    addMessage(`❓ I found ${tableVisuals.length} table visuals on this page. Please specify which one to reset:
                    
📊 Available tables:
${formatTableList(availableTables)}

✅ Try: "Reset ${availableTables[0] || 'Table'}"`, 'bot');
                    return;
                }
            }
            
            // Now reset the table visual to show all columns
            const result = await resetTableVisual(targetVisual);
            
            if (result.success) {
                addMessage(`✅ Success! Reset "${targetVisual.title || 'table'}" to show all columns.
                
📊 All ${result.totalColumns} columns are now visible.

💡 The table has been restored to its default view.`, 'bot');
            } else {
                addMessage(`❌ Error resetting table visual: ${result.error}

💡 Try a different approach:
• "Select all columns from ${targetVisual.title || 'table'}"
• "Show all columns in ${targetVisual.title || 'table'}"`, 'bot');
            }
        } catch (error) {
            console.error(`❌ Error in handleResetVisualCommand:`, error);
            addMessage(`❌ Error resetting table visual: ${error.message}

💡 Try refreshing the page or using a different command.`, 'bot');
        }
    }
    
    // Reset a table visual to show all columns
    async function resetTableVisual(tableVisual) {
        console.log(`🔄 Resetting table visual: "${tableVisual.title || 'Unnamed'}"`);
        
        try {
            const table = tableVisual.tableElement;
            const container = tableVisual.element;
            const totalColumns = tableVisual.headers.length;
            
            console.log(`📊 Table has ${totalColumns} total columns`);
            
            // STRATEGY 1: Try to use Power BI's own column visibility controls
            const headerCheckboxes = container.querySelectorAll('[class*="headerCheckbox"], [class*="columnHeaderCheckbox"]');
            if (headerCheckboxes && headerCheckboxes.length > 0) {
                console.log(`🔍 Found ${headerCheckboxes.length} column header checkboxes`);
                
                // Check each header checkbox to ensure all columns are visible
                let checkedCount = 0;
                
                for (let i = 0; i < headerCheckboxes.length; i++) {
                    const isChecked = headerCheckboxes[i].getAttribute('aria-checked') === 'true' ||
                                     headerCheckboxes[i].checked;
                    
                    if (!isChecked) {
                        console.log(`🔍 Checking checkbox for column ${i}`);
                        headerCheckboxes[i].click();
                        checkedCount++;
                        // Give some time for UI to update
                        await new Promise(resolve => setTimeout(resolve, 100));
                    }
                }
                
                console.log(`✅ Checked ${checkedCount} column checkboxes`);
            }
            
            // STRATEGY 2: Look for "Show All" or "Reset" buttons in the visual
            const showAllButtons = Array.from(container.querySelectorAll('button, [role="button"]')).filter(btn => {
                const text = btn.textContent.toLowerCase();
                return text.includes('show all') || 
                       text.includes('reset') || 
                       text.includes('clear') || 
                       text.includes('default view');
            });
            
            if (showAllButtons.length > 0) {
                console.log(`✅ Found ${showAllButtons.length} "Show All" or "Reset" buttons`);
                showAllButtons[0].click();
                await new Promise(resolve => setTimeout(resolve, 200));
            }
            
            // STRATEGY 3: Remove any CSS hiding columns
            const tableStyleIds = Array.from(document.querySelectorAll('style[id*="chatbot-table"]')).map(el => el.id);
            console.log(`🔍 Found ${tableStyleIds.length} table style elements: ${tableStyleIds.join(', ')}`);
            
            for (const styleId of tableStyleIds) {
                const styleElement = document.getElementById(styleId);
                if (styleElement) {
                    console.log(`🗑️ Removing style element: ${styleId}`);
                    styleElement.textContent = ''; // Clear the CSS rules
                }
            }
            
            return {
                success: true,
                totalColumns: totalColumns
            };
        } catch (error) {
            console.error(`❌ Error resetting table visual:`, error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Start the chatbot
    initializeChatbot();

    console.log('✅ Power BI Chatbot Content Script loaded successfully');

})();
