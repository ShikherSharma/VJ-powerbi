// Mobile-First Features for Universal Power BI Dashboard
// Touch gestures, haptic feedback, and mobile optimization

// Mobile Features Initialization
function initializeMobileFeatures() {
    createMobileQuickActions();
    setupGestureHandlers();
    setupServiceWorker();
    createNotificationSystem();
    console.log('📱 Mobile features initialized');
}

// 1. Mobile Quick Actions Floating Menu
function createMobileQuickActions() {
    const quickActions = document.createElement('div');
    quickActions.id = 'mobile-quick-actions';
    quickActions.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 1000;
        display: flex;
        flex-direction: column;
        gap: 10px;
    `;

    // Main FAB button
    const mainFab = document.createElement('button');
    mainFab.innerHTML = '📊';
    mainFab.style.cssText = `
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: #0078d4;
        color: white;
        border: none;
        font-size: 24px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        cursor: pointer;
        transition: all 0.3s ease;
    `;

    // Sub action buttons (initially hidden)
    const actions = [
        { icon: '🔄', action: () => window.universalPowerBITestDashboard.refreshData(), label: 'Refresh' },
        { icon: '🧹', action: () => window.universalPowerBITestDashboard.clearFilters(), label: 'Clear Filters' },
        { icon: '🤖', action: () => toggleChatbot(), label: 'Chatbot' },
        { icon: '🎤', action: () => toggleSpeechRecognition(), label: 'Voice' }
    ];

    let isExpanded = false;
    const subButtons = [];

    actions.forEach((actionData, index) => {
        const btn = document.createElement('button');
        btn.innerHTML = actionData.icon;
        btn.title = actionData.label;
        btn.style.cssText = `
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: white;
            color: #333;
            border: 2px solid #0078d4;
            font-size: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: all 0.3s ease;
            transform: scale(0);
            opacity: 0;
        `;

        btn.onclick = () => {
            actionData.action();
            if (navigator.vibrate) navigator.vibrate(50);
        };

        subButtons.push(btn);
        quickActions.appendChild(btn);
    });

    mainFab.onclick = () => {
        isExpanded = !isExpanded;

        if (isExpanded) {
            mainFab.innerHTML = '✕';
            subButtons.forEach((btn, index) => {
                setTimeout(() => {
                    btn.style.transform = `scale(1) translateY(-${(index + 1) * 60}px)`;
                    btn.style.opacity = '1';
                }, index * 50);
            });
        } else {
            mainFab.innerHTML = '📊';
            subButtons.forEach((btn, index) => {
                setTimeout(() => {
                    btn.style.transform = 'scale(0)';
                    btn.style.opacity = '0';
                }, index * 30);
            });
        }

        if (navigator.vibrate) navigator.vibrate(50);
    };

    quickActions.appendChild(mainFab);
    document.body.appendChild(quickActions);
}

// 2. Touch Gesture Handlers
function setupGestureHandlers() {
    let startX, startY, endX, endY;

    document.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
    });

    document.addEventListener('touchend', (e) => {
        endX = e.changedTouches[0].clientX;
        endY = e.changedTouches[0].clientY;
        handleGesture();
    });

    function handleGesture() {
        const deltaX = endX - startX;
        const deltaY = endY - startY;
        const minSwipeDistance = 100;

        // Horizontal swipes for tab navigation
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > minSwipeDistance) {
            if (deltaX > 0) {
                // Swipe right - previous tab
                navigateTabs('prev');
            } else {
                // Swipe left - next tab
                navigateTabs('next');
            }
        }

        // Vertical swipes for actions
        if (Math.abs(deltaY) > Math.abs(deltaX) && Math.abs(deltaY) > minSwipeDistance) {
            if (deltaY < 0) {
                // Swipe up - refresh dashboard
                window.universalPowerBITestDashboard.refreshData();
            } else {
                // Swipe down - clear filters
                window.universalPowerBITestDashboard.clearFilters();
            }
        }
    }

    function navigateTabs(direction) {
        const tabs = ['overview', 'sales-focus', 'customer-analytics', 'product-performance', 'regional-analysis', 'trends'];
        const currentIndex = tabs.indexOf(window.universalPowerBITestDashboard.currentBookmark);
        let newIndex;

        if (direction === 'next') {
            newIndex = (currentIndex + 1) % tabs.length;
        } else {
            newIndex = (currentIndex - 1 + tabs.length) % tabs.length;
        }

        window.universalPowerBITestDashboard.navigateToBookmark(tabs[newIndex]);

        if (navigator.vibrate) navigator.vibrate(50);
    }
}

// 3. Service Worker for Offline Capabilities
function setupServiceWorker() {
    if ('serviceWorker' in navigator) {
        const swCode = `
            const CACHE_NAME = 'powerbi-dashboard-v1';
            const urlsToCache = [
                '/',
                '/dashboard-core.js',
                '/intelligent-summarizer.js',
                '/chatbot-core.js',
                '/mobile-features.js'
            ];
            
            self.addEventListener('install', (event) => {
                event.waitUntil(
                    caches.open(CACHE_NAME)
                        .then((cache) => cache.addAll(urlsToCache))
                );
            });
            
            self.addEventListener('fetch', (event) => {
                event.respondWith(
                    caches.match(event.request)
                        .then((response) => response || fetch(event.request))
                );
            });
        `;

        const blob = new Blob([swCode], { type: 'application/javascript' });
        const swUrl = URL.createObjectURL(blob);

        navigator.serviceWorker.register(swUrl)
            .then(() => console.log('📱 Service Worker registered'))
            .catch(err => console.log('Service Worker registration failed:', err));
    }
}

// 4. Mobile Notification System
function createNotificationSystem() {
    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }

    // Add mobile notification styles
    const style = document.createElement('style');
    style.textContent = `
        @media (max-width: 768px) {
            .notification {
                top: 10px !important;
                right: 10px !important;
                left: 10px !important;
                max-width: none !important;
                border-radius: 12px !important;
                font-size: 14px !important;
            }
        }
        
        @keyframes slideInNotification {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes slideOutNotification {
            from { opacity: 1; transform: translateY(0); }
            to { opacity: 0; transform: translateY(-20px); }
        }
    `;
    document.head.appendChild(style);
}

// 5. Mobile Share Functionality
function enableMobileSharing() {
    if (navigator.share) {
        const shareButton = document.createElement('button');
        shareButton.innerHTML = '📤';
        shareButton.title = 'Share Dashboard';
        shareButton.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #0078d4;
            color: white;
            border: none;
            font-size: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            cursor: pointer;
            z-index: 999;
        `;

        shareButton.onclick = () => {
            navigator.share({
                title: 'Power BI Dashboard',
                text: 'Check out this Power BI dashboard with intelligent insights',
                url: window.location.href
            });
        };

        document.body.appendChild(shareButton);
    }
}

// 6. Voice Command Shortcuts for Mobile
function createVoiceShortcuts() {
    const voiceShortcuts = {
        'quick refresh': () => window.universalPowerBITestDashboard.refreshData(),
        'clear all': () => window.universalPowerBITestDashboard.clearFilters(),
        'open chat': () => toggleChatbot(),
        'sales view': () => window.universalPowerBITestDashboard.navigateToBookmark('sales-focus'),
        'customer view': () => window.universalPowerBITestDashboard.navigateToBookmark('customer-analytics'),
        'overview': () => window.universalPowerBITestDashboard.navigateToBookmark('overview')
    };

    // Add to global scope for voice recognition
    window.voiceShortcuts = voiceShortcuts;
}

// Toggle chatbot visibility (used by mobile actions)
function toggleChatbot() {
    const chatbot = document.getElementById('test-powerbi-chatbot');
    if (chatbot) {
        const isVisible = chatbot.style.display !== 'none';
        chatbot.style.display = isVisible ? 'none' : 'block';

        if (!isVisible) {
            // Show welcome message when opening
            setTimeout(() => {
                if (window.addMessage) {
                    window.addMessage('👋 Hi! I\'m your Power BI assistant. Try asking me to "Show North America" or "Go to Sales Focus"', 'bot');
                }
                if (window.speakResponse) {
                    window.speakResponse('Hi! I am your Power BI assistant. How can I help you today?');
                }
            }, 500);
        }
    }
}

// Initialize all mobile features
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        initializeMobileFeatures();
        enableMobileSharing();
        createVoiceShortcuts();
    }, 1000);
});

// Export functions for global access
window.toggleChatbot = toggleChatbot;
window.initializeMobileFeatures = initializeMobileFeatures;
