// Intelligent Summarizer for Universal Power BI Dashboard
// Provides AI-powered insights and analysis

window.intelligentSummarizer = {
    // Track user selections and provide intelligent insights
    trackSelection: function (element, type, data) {
        console.log('🧠 Intelligent Summarizer tracking selection:', type, data);

        // Determine what type of summary to generate
        switch (type) {
            case 'visual':
                this.summarizeVisual(data);
                break;
            case 'filter':
                this.summarizeFilter(data);
                break;
            case 'bookmark':
                this.summarizeBookmark(data);
                break;
            case 'kpi':
                this.summarizeKPI(data);
                break;
            default:
                this.generateGenericSummary(type, data);
        }
    },

    // Summarize visual/chart insights
    summarizeVisual: function (data) {
        const insights = {
            title: '📊 Visual Analysis: ' + (data.title || 'Chart'),
            insight: 'This visual shows key performance metrics. Based on current filters, you can see trends and patterns in your data.',
            keyMetrics: [
                'Current performance vs targets',
                'Trend analysis over time',
                'Comparative performance by category'
            ],
            recommendations: [
                'Focus on top-performing segments',
                'Investigate underperforming areas',
                'Consider seasonal adjustments'
            ]
        };

        this.displaySummary(insights);
    },

    // Summarize filter impact
    summarizeFilter: function (data) {
        const { filterType, value, previousValue } = data;

        const insights = {
            title: '🔍 Filter Impact Analysis',
            insight: `Applied ${filterType} filter: ${value}. This filter change affects your dashboard view and highlights relevant data segments.`,
            impact: `Data view updated from "${previousValue || 'all'}" to "${value}"`,
            affectedAreas: [
                'Revenue metrics updated',
                'Customer segments filtered',
                'Geographic analysis refined',
                'Product performance focused'
            ],
            recommendations: [
                'Compare filtered vs unfiltered results',
                'Explore related filter combinations',
                'Export filtered data for deeper analysis'
            ]
        };

        this.displaySummary(insights);
    },

    // Summarize bookmark/view insights  
    summarizeBookmark: function (data) {
        const bookmarkInsights = {
            'sales-focus': {
                title: '💰 Sales Focus Analysis',
                insight: 'Sales-focused view highlighting North America electronics performance. Revenue trends show strong Q4 performance with 24% growth.',
                keyAreas: ['Regional performance', 'Product category analysis', 'Sales trends'],
                opportunities: ['Expand successful categories', 'Replicate North America success', 'Optimize sales processes']
            },
            'customer-analytics': {
                title: '👥 Customer Analytics Overview',
                insight: 'Enterprise customer segment analysis showing high-value accounts and retention patterns. Focus on customer lifetime value optimization.',
                keyAreas: ['Customer segmentation', 'Retention analysis', 'Value optimization'],
                opportunities: ['Upsell enterprise accounts', 'Improve customer onboarding', 'Expand customer success programs']
            },
            'overview': {
                title: '🌟 Dashboard Overview',
                insight: 'Complete business overview showing all key metrics, trends, and performance indicators across regions and categories.',
                keyAreas: ['Overall performance', 'Cross-functional insights', 'Strategic metrics'],
                opportunities: ['Identify growth opportunities', 'Balance resource allocation', 'Strategic planning']
            }
        };

        const bookmark = data.bookmark || 'overview';
        const insight = bookmarkInsights[bookmark] || bookmarkInsights['overview'];

        this.displaySummary(insight);
    },

    // Display summary in chatbot
    displaySummary: function (summary) {
        console.log('🧠 displaySummary called with:', summary);

        // Check if chatbot exists
        const chatbot = document.getElementById('test-powerbi-chatbot');
        if (!chatbot) {
            console.log('Chatbot not found, cannot display summary');
            return;
        }

        // Format and send summary to chatbot (using <br> for HTML)
        let summaryMessage = '🧠 **Intelligent Summary**<br><br>';
        summaryMessage += '**' + summary.title + '**<br><br>';
        summaryMessage += summary.insight + '<br><br>';

        if (summary.keyMetrics) {
            summaryMessage += '**📊 Key Metrics:**<br>';
            summary.keyMetrics.forEach(metric => {
                summaryMessage += '• ' + metric + '<br>';
            });
            summaryMessage += '<br>';
        }

        if (summary.breakdown) {
            summaryMessage += '**📈 Breakdown:**<br>';
            Object.keys(summary.breakdown).forEach(key => {
                summaryMessage += '• **' + key + '**: ' + summary.breakdown[key] + '<br>';
            });
            summaryMessage += '<br>';
        }

        if (summary.recommendations) {
            summaryMessage += '**💡 Recommendations:**<br>';
            summary.recommendations.forEach(rec => {
                summaryMessage += '• ' + rec + '<br>';
            });
        }

        // Add message to chatbot
        if (window.addMessage) {
            console.log('📤 Sending summary to chatbot:', summaryMessage.substring(0, 100) + '...');
            window.addMessage(summaryMessage, 'bot');
            console.log('✅ Summary displayed successfully');

            // Also provide voice summary
            if (window.speakResponse) {
                const spokenSummary = summary.title + '. ' + summary.insight.replace(/[📊🌎🇪🇺🌏🌍🇦🇺📱👕📚🏠⚽🚗💊🏢🏬🏪👤🏛️💰👥📦🌍📈📊📑]/g, '').substring(0, 100) + '...';
                window.speakResponse(spokenSummary);
            }
        } else {
            console.error('❌ addMessage function not available globally');
        }
    },

    // Generate generic summary for unknown types
    generateGenericSummary: function (type, data) {
        return {
            title: '📋 Selection Summary: ' + type,
            insight: 'You have selected a ' + type + ' element. This provides focused insights on the selected data.',
            impact: 'Data view updated to reflect your selection',
            recommendations: ['Explore related data points', 'Apply additional filters', 'Compare with other segments']
        };
    }
};
