# Enhanced Power BI Chatbot - Setup and Test Script
# Run this script to set up and test your enhanced chatbot

Write-Host "🚀 Enhanced Power BI Chatbot Setup" -ForegroundColor Green
Write-Host "=================================================" -ForegroundColor Green

# Function to check if Chrome/Edge is installed
function Test-Browser {
    param($BrowserName, $ProcessName)
    
    try {
        $process = Get-Process $ProcessName -ErrorAction SilentlyContinue
        if ($process) {
            Write-Host "✅ $BrowserName is running" -ForegroundColor Green
            return $true
        } else {
            Write-Host "⚠️  $BrowserName is not currently running" -ForegroundColor Yellow
            return $false
        }
    } catch {
        Write-Host "❌ $BrowserName not found" -ForegroundColor Red
        return $false
    }
}

# Check browsers
Write-Host "`n📋 Checking browsers..." -ForegroundColor Cyan
$chromeRunning = Test-Browser "Google Chrome" "chrome"
$edgeRunning = Test-Browser "Microsoft Edge" "msedge"

# Check extension files
Write-Host "`n📁 Checking extension files..." -ForegroundColor Cyan
$requiredFiles = @(
    "manifest.json",
    "enhanced-contentScript.js", 
    "enhanced-powerbi-chatbot.js",
    "background.js",
    "chatbot.css"
)

foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        Write-Host "✅ $file found" -ForegroundColor Green
    } else {
        Write-Host "❌ $file missing" -ForegroundColor Red
    }
}

# Check test dashboard
if (Test-Path "enhanced-test-dashboard.html") {
    Write-Host "✅ Test dashboard found" -ForegroundColor Green
} else {
    Write-Host "❌ Test dashboard missing" -ForegroundColor Red
}

Write-Host "`n🎯 Setup Instructions:" -ForegroundColor Yellow
Write-Host "1. Open Chrome or Edge browser"
Write-Host "2. Go to chrome://extensions/ or edge://extensions/"
Write-Host "3. Enable 'Developer mode'"
Write-Host "4. Click 'Load unpacked' and select this folder:"
Write-Host "   $PWD" -ForegroundColor Green

Write-Host "`n🧪 Testing Instructions:" -ForegroundColor Yellow
Write-Host "Option 1 - Test with local dashboard:"
Write-Host "   Open: enhanced-test-dashboard.html"

Write-Host "`nOption 2 - Test with your actual Power BI app:"
Write-Host "   Navigate to: https://app.powerbi.com/groups/me/apps/0201219b-480c-4bbc-bad5-2d47df08f957"

Write-Host "`n🎤 Voice Commands to Test:" -ForegroundColor Yellow
Write-Host "• 'Show me sales report'"
Write-Host "• 'Go to customer analysis'"
Write-Host "• 'Apply quarterly bookmark'" 
Write-Host "• 'Filter by region'"
Write-Host "• 'What reports are available?'"

Write-Host "`n🔍 Features to Verify:" -ForegroundColor Yellow
Write-Host "✓ Chatbot appears on target URL"
Write-Host "✓ User greeting with identified name"
Write-Host "✓ Voice recognition working (mic button)"
Write-Host "✓ Report and page detection"
Write-Host "✓ Navigation commands work"
Write-Host "✓ Filter and bookmark commands"

# Open test dashboard option
$openTest = Read-Host "`n❓ Open test dashboard now? (y/n)"
if ($openTest -eq 'y' -or $openTest -eq 'Y') {
    if (Test-Path "enhanced-test-dashboard.html") {
        $dashboardPath = Resolve-Path "enhanced-test-dashboard.html"
        Start-Process $dashboardPath
        Write-Host "🌐 Test dashboard opened!" -ForegroundColor Green
    } else {
        Write-Host "❌ Test dashboard file not found" -ForegroundColor Red
    }
}

# Extension loading helper
$loadExtension = Read-Host "`n❓ Open browser extensions page? (y/n)"
if ($loadExtension -eq 'y' -or $loadExtension -eq 'Y') {
    if ($chromeRunning -or (Get-Command chrome -ErrorAction SilentlyContinue)) {
        Start-Process "chrome://extensions/"
        Write-Host "🌐 Chrome extensions page opened!" -ForegroundColor Green
    } elseif ($edgeRunning -or (Get-Command msedge -ErrorAction SilentlyContinue)) {
        Start-Process "microsoft-edge://extensions/"
        Write-Host "🌐 Edge extensions page opened!" -ForegroundColor Green
    } else {
        Write-Host "❌ No supported browser found" -ForegroundColor Red
    }
}

Write-Host "`n📝 Troubleshooting Tips:" -ForegroundColor Yellow
Write-Host "• Check browser console (F12) for error messages"
Write-Host "• Ensure you're on the correct Power BI URL"
Write-Host "• Try refreshing the page after loading extension"
Write-Host "• Check if microphone permissions are granted"

Write-Host "`n✅ Setup complete! Your enhanced Power BI chatbot is ready." -ForegroundColor Green
Write-Host "💡 The chatbot will automatically detect your reports and pages." -ForegroundColor Cyan
