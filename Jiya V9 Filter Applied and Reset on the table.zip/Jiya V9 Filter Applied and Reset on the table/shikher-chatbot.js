// Shikher's Power BI Chatbot - Main JavaScript File
console.log('🚀 Loading Shikher\'s Power BI Chatbot...');

// Dashboard State
let currentBookmark = 'overview';
let currentFilters = {};

// Speech Recognition
let recognition = null;
let isListening = false;

// Initialize Speech Recognition
function initializeSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = function () {
            isListening = true;
            const micBtn = document.getElementById('micBtn');
            if (micBtn) {
                micBtn.classList.add('recording');
            }
            addMessage('🎤 Listening... speak now!', 'bot');
        };

        recognition.onresult = function (event) {
            const transcript = event.results[0][0].transcript;
            console.log('Speech recognized:', transcript);

            addMessage('🎤 "' + transcript + '"', 'user');
            processVoiceCommand(transcript);
        };

        recognition.onend = function () {
            isListening = false;
            const micBtn = document.getElementById('micBtn');
            if (micBtn) {
                micBtn.classList.remove('recording');
            }
        };

        recognition.onerror = function (event) {
            console.log('Speech recognition error:', event.error);
            addMessage('❌ Speech error. Please try again.', 'bot');
            isListening = false;
            const micBtn = document.getElementById('micBtn');
            if (micBtn) {
                micBtn.classList.remove('recording');
            }
        };

        console.log('✅ Speech recognition initialized');
    } else {
        console.log('❌ Speech recognition not supported');
    }
}

// Bookmark Functions
function switchBookmark(bookmark, buttonElement) {
    console.log('Switching to bookmark:', bookmark);

    // Update UI
    document.querySelectorAll('.bookmark-btn').forEach(btn => btn.classList.remove('active'));
    if (buttonElement) {
        buttonElement.classList.add('active');
    }

    currentBookmark = bookmark;

    // Update content view
    const viewNames = {
        'overview': '📊 Overview Dashboard',
        'sales': '💰 Sales Focus',
        'customers': '👥 Customer Analytics',
        'products': '📦 Product Performance',
        'regional': '🌍 Regional Analysis',
        'trends': '📈 Trends Analysis'
    };

    const currentView = document.getElementById('currentView');
    if (currentView) {
        currentView.innerHTML =
            viewNames[bookmark] + '<br><small style="font-size: 16px; color: #666;">Successfully navigated to ' + bookmark + '</small>';
    }

    return true;
}

// Filter Functions
function applyFilter(filterType, filterValue) {
    console.log('Applying filter:', filterType, '=', filterValue);
    currentFilters[filterType] = filterValue;

    // Update the view to show filter applied
    const currentView = document.getElementById('currentView');
    if (currentView) {
        const filterText = filterValue ? `Filter: ${filterType} = ${filterValue}` : 'Filter cleared';
        currentView.innerHTML += '<br><small style="color: #28a745;">✅ ' + filterText + '</small>';
    }

    return true;
}

// Voice Command Processing
function processVoiceCommand(command) {
    const cmd = command.toLowerCase().trim();
    console.log('Processing voice command:', cmd);

    let response = '';
    let success = false;

    // Bookmark commands
    if (cmd.includes('go to') || cmd.includes('show me') || cmd.includes('navigate to')) {
        if (cmd.includes('sales') || cmd.includes('sales focus')) {
            const salesBtn = document.querySelector('[data-bookmark="sales"]');
            success = switchBookmark('sales', salesBtn);
            response = '✅ Navigated to Sales Focus';
        } else if (cmd.includes('customer') || cmd.includes('customer analytics')) {
            const customersBtn = document.querySelector('[data-bookmark="customers"]');
            success = switchBookmark('customers', customersBtn);
            response = '✅ Navigated to Customer Analytics';
        } else if (cmd.includes('product') || cmd.includes('product performance')) {
            const productsBtn = document.querySelector('[data-bookmark="products"]');
            success = switchBookmark('products', productsBtn);
            response = '✅ Navigated to Product Performance';
        } else if (cmd.includes('regional') || cmd.includes('regional analysis')) {
            const regionalBtn = document.querySelector('[data-bookmark="regional"]');
            success = switchBookmark('regional', regionalBtn);
            response = '✅ Navigated to Regional Analysis';
        } else if (cmd.includes('overview')) {
            const overviewBtn = document.querySelector('[data-bookmark="overview"]');
            success = switchBookmark('overview', overviewBtn);
            response = '✅ Navigated to Overview';
        } else if (cmd.includes('trends')) {
            const trendsBtn = document.querySelector('[data-bookmark="trends"]');
            success = switchBookmark('trends', trendsBtn);
            response = '✅ Navigated to Trends';
        }
    }

    // Filter commands
    else if (cmd.includes('filter') || cmd.includes('show')) {
        if (cmd.includes('region')) {
            const regionFilter = document.getElementById('regionFilter');
            if (cmd.includes('north')) {
                if (regionFilter) regionFilter.value = 'north';
                success = applyFilter('region', 'north');
                response = '✅ Applied North America filter';
            } else if (cmd.includes('south')) {
                if (regionFilter) regionFilter.value = 'south';
                success = applyFilter('region', 'south');
                response = '✅ Applied South America filter';
            } else if (cmd.includes('europe')) {
                if (regionFilter) regionFilter.value = 'europe';
                success = applyFilter('region', 'europe');
                response = '✅ Applied Europe filter';
            } else if (cmd.includes('asia')) {
                if (regionFilter) regionFilter.value = 'asia';
                success = applyFilter('region', 'asia');
                response = '✅ Applied Asia filter';
            }
        } else if (cmd.includes('enterprise')) {
            const segmentFilter = document.getElementById('segmentFilter');
            if (segmentFilter) segmentFilter.value = 'enterprise';
            success = applyFilter('segment', 'enterprise');
            response = '✅ Applied Enterprise filter';
        } else if (cmd.includes('electronics')) {
            const categoryFilter = document.getElementById('categoryFilter');
            if (categoryFilter) categoryFilter.value = 'electronics';
            success = applyFilter('category', 'electronics');
            response = '✅ Applied Electronics filter';
        }
    }

    // Clear/Reset commands
    else if (cmd.includes('clear') || cmd.includes('reset')) {
        const regionFilter = document.getElementById('regionFilter');
        const categoryFilter = document.getElementById('categoryFilter');
        const segmentFilter = document.getElementById('segmentFilter');

        if (regionFilter) regionFilter.value = '';
        if (categoryFilter) categoryFilter.value = '';
        if (segmentFilter) segmentFilter.value = '';

        currentFilters = {};
        response = '✅ All filters cleared';
        success = true;
    }

    // Add response message
    if (success && response) {
        addMessage(response, 'bot');
        speak(response.replace('✅ ', ''));
    } else {
        const errorMsg = '❌ I didn\'t understand "' + command + '". Try: "Go to Sales Focus" or "Filter region North America"';
        addMessage(errorMsg, 'bot');
        speak('I didn\'t understand that command. Please try again.');
    }
}

// Text-to-Speech
function speak(text) {
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.8;
        utterance.pitch = 1;
        speechSynthesis.speak(utterance);
    }
}

// Chatbot Functions
function toggleSpeech() {
    if (!recognition) {
        addMessage('❌ Speech recognition not supported', 'bot');
        return;
    }

    if (isListening) {
        recognition.stop();
    } else {
        recognition.start();
    }
}

function addMessage(text, type) {
    const messagesDiv = document.getElementById('messages');
    if (!messagesDiv) return;

    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ' + type;
    messageDiv.innerHTML = text;
    messagesDiv.appendChild(messageDiv);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function sendMessage() {
    const input = document.getElementById('chatInput');
    if (!input) return;

    const message = input.value.trim();

    if (!message) return;

    addMessage(message, 'user');
    input.value = '';

    processVoiceCommand(message);
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function minimizeChatbot() {
    const chatbot = document.getElementById('chatbot');
    if (!chatbot) return;

    if (chatbot.style.height === '60px') {
        chatbot.style.height = '500px';
        chatbot.style.overflow = 'visible';
    } else {
        chatbot.style.height = '60px';
        chatbot.style.overflow = 'hidden';
    }
}

function closeChatbot() {
    const chatbot = document.getElementById('chatbot');
    if (chatbot) {
        chatbot.style.display = 'none';
    }
}

// Initialize when page loads
function initializeChatbot() {
    console.log('🚀 Initializing Shikher\'s Power BI Chatbot...');

    // Initialize speech recognition
    initializeSpeechRecognition();

    // Welcome message
    setTimeout(() => {
        speak('Hi Shikher! I am ready to help you with your dashboard. Try saying Go to Sales Focus.');
    }, 1000);

    console.log('✅ Chatbot initialization complete');
}

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeChatbot);
} else {
    initializeChatbot();
}

// Make functions globally available
window.switchBookmark = switchBookmark;
window.applyFilter = applyFilter;
window.toggleSpeech = toggleSpeech;
window.sendMessage = sendMessage;
window.handleKeyPress = handleKeyPress;
window.minimizeChatbot = minimizeChatbot;
window.closeChatbot = closeChatbot;
