// Universal Power BI Assistant Background Script
console.log('🚀 Universal Power BI Assistant Background Script Loaded');

// Listen for extension installation
chrome.runtime.onInstalled.addListener((details) => {
    console.log('✅ Universal Power BI Assistant Installed:', details.reason);

    if (details.reason === 'install') {
        // Open welcome page on first install
        chrome.tabs.create({
            url: chrome.runtime.getURL('universal-test-dashboard.html')
        });
    }
});

// Listen for tab updates to inject chatbot
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        // Only inject if it's a valid webpage (not chrome:// or extension pages)
        if (tab.url.startsWith('http://') || tab.url.startsWith('https://') || tab.url.startsWith('file://')) {
            console.log('🌐 Page loaded, checking for chatbot injection:', tab.url);

            // Small delay to ensure page is fully loaded
            setTimeout(() => {
                chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    func: () => {
                        // Check if chatbot already exists
                        if (!document.getElementById('universal-powerbi-chatbot')) {
                            console.log('🤖 Chatbot not found, triggering injection...');
                            // Trigger the content script to load chatbot
                            if (window.loadUniversalChatbotSystem) {
                                window.loadUniversalChatbotSystem();
                            }
                        } else {
                            console.log('✅ Chatbot already present on page');
                        }
                    }
                }).catch(error => {
                    // Silently handle errors (some pages can't be scripted)
                    console.log('Info: Could not inject script into page (probably restricted)');
                });
            }, 1000);
        }
    }
});

// Handle messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('📨 Background received message:', request);

    switch (request.action) {
        case 'chatbot-ready':
            console.log('✅ Chatbot ready on tab:', sender.tab?.id);
            break;

        case 'dashboard-detected':
            console.log('📊 Dashboard detected:', request.dashboardType);
            break;

        case 'error':
            console.error('❌ Error from content script:', request.error);
            break;
    }

    sendResponse({ success: true });
});

// Keep service worker alive
let keepAlive = setInterval(() => {
    chrome.action.setBadgeText({ text: '🤖' });
}, 30000);

console.log('🎯 Universal Power BI Assistant Background Script Ready');
