// Universal Power BI Test Dashboard - Core JavaScript
// Mobile-first dashboard with intelligent summarization

// Global Dashboard Object
window.universalPowerBITestDashboard = {
    currentFilters: {
        region: 'all',
        category: 'all',
        customerSegment: 'all',
        revenue: 'all',
        timePeriod: 'all'
    },

    currentBookmark: 'overview',

    // Apply filter with enhanced mobile support
    applyFilter: function (filterType, value, skipUpdate = false) {
        console.log(`🔧 Applying filter: ${filterType} = ${value}`);

        const oldFilters = { ...this.currentFilters };
        this.currentFilters[filterType] = value;

        // Update filter UI
        const filterElement = document.getElementById(filterType + 'Filter');
        if (filterElement) {
            filterElement.value = value;
        }

        if (!skipUpdate) {
            this.updateChartVisuals();
            this.updateFilterStatus();
            this.highlightVisuals();

            // Trigger intelligent summarization for filter changes
            const changedFilters = Object.keys(this.currentFilters).filter(key => this.currentFilters[key] !== oldFilters[key] && this.currentFilters[key] !== 'all');
            if (changedFilters.length > 0 && window.intelligentSummarizer) {
                changedFilters.forEach(filterType => {
                    const filterValue = this.currentFilters[filterType];
                    if (filterValue !== 'all') {
                        window.intelligentSummarizer.trackSelection(
                            document.getElementById(filterType + 'Filter'),
                            'filter',
                            { filterType, value: filterValue, previousValue: oldFilters[filterType] }
                        );
                    }
                });
            }
        }

        return true;
    },

    // Apply multiple filters sequentially
    applyFilters: function (filters) {
        let applied = false;
        for (const [filterType, value] of Object.entries(filters)) {
            if (this.applyFilter(filterType, value, true)) {
                applied = true;
            }
        }
        if (applied) {
            this.updateChartVisuals();
            this.updateFilterStatus();
            this.highlightVisuals();
        }
        return applied;
    },

    // Clear filters with animation
    clearFilters: function () {
        console.log('🧹 Clearing all filters');

        const filters = ['region', 'category', 'customerSegment', 'revenue', 'timePeriod'];
        filters.forEach(filter => {
            const element = document.getElementById(filter + 'Filter');
            if (element) {
                element.value = 'all';
            }
            this.currentFilters[filter] = 'all';
        });

        this.updateChartVisuals();
        this.updateFilterStatus();
        this.highlightVisuals();

        // Add visual feedback
        this.showNotification('🧹 All filters cleared', 'success');

        return true;
    },

    // Navigate to bookmark with mobile optimization
    navigateToBookmark: function (bookmark) {
        console.log(`📑 Navigating to bookmark: ${bookmark}`);

        this.currentBookmark = bookmark;
        const tabs = document.querySelectorAll('.tab');
        const tabContents = document.querySelectorAll('.tab-content');

        // Remove active state
        tabs.forEach(tab => tab.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));

        // Add active state to selected tab
        const targetTab = document.querySelector(`[data-tab="${bookmark}"]`);
        const targetContent = document.getElementById(bookmark);

        if (targetTab) targetTab.classList.add('active');
        if (targetContent) targetContent.classList.add('active');

        // Apply bookmark-specific filters with mobile haptic feedback
        this.applyBookmarkFilters(bookmark);

        // Haptic feedback for mobile
        if (navigator.vibrate) {
            navigator.vibrate(50);
        }

        // Show success notification
        this.showNotification(`📊 Switched to ${bookmark.charAt(0).toUpperCase() + bookmark.slice(1)} view`, 'info');

        return true;
    },

    // Apply filters specific to bookmarks
    applyBookmarkFilters: function (bookmark) {
        const bookmarkFilters = {
            'sales-focus': { region: 'north', category: 'electronics' },
            'customer-analytics': { customerSegment: 'enterprise' },
            'product-performance': { category: 'electronics', revenue: 'high' },
            'regional-analysis': { region: 'all', category: 'all' },
            'overview': { region: 'all', category: 'all', customerSegment: 'all' },
            'trends': { timePeriod: 'quarter' }
        };

        const filters = bookmarkFilters[bookmark];
        if (filters) {
            this.applyFilters(filters);
        }
    },

    // Update chart visuals with mobile responsiveness
    updateChartVisuals: function () {
        // Simulate data updates based on current filters
        const charts = document.querySelectorAll('.chart, .visual');
        charts.forEach(chart => {
            chart.style.opacity = '0.7';
            setTimeout(() => {
                chart.style.opacity = '1';
                chart.style.transform = 'scale(1.02)';
                setTimeout(() => {
                    chart.style.transform = 'scale(1)';
                }, 200);
            }, 100);
        });
    },

    // Update filter status with visual indicators
    updateFilterStatus: function () {
        const statusContainer = document.querySelector('.filter-status');
        if (!statusContainer) return;

        const activeFilters = Object.entries(this.currentFilters)
            .filter(([key, value]) => value !== 'all')
            .map(([key, value]) => `${key}: ${value}`);

        if (activeFilters.length === 0) {
            statusContainer.innerHTML = '<span style="color: #666;">No filters applied</span>';
        } else {
            statusContainer.innerHTML = activeFilters.map(filter =>
                `<span class="filter-tag">${filter}</span>`
            ).join(' ');
        }
    },

    // Highlight relevant visuals
    highlightVisuals: function () {
        const visuals = document.querySelectorAll('.visual, .chart, .kpi-card');
        visuals.forEach(visual => {
            visual.style.borderLeft = '3px solid #0078d4';
            setTimeout(() => {
                visual.style.borderLeft = 'none';
            }, 1000);
        });
    },

    // Show mobile-optimized notifications
    showNotification: function (message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#d4edda' : type === 'error' ? '#f8d7da' : '#d1ecf1'};
            color: ${type === 'success' ? '#155724' : type === 'error' ? '#721c24' : '#0c5460'};
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10000;
            font-weight: 500;
            animation: slideInNotification 0.3s ease;
            max-width: 300px;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOutNotification 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    },

    // Refresh dashboard data
    refreshData: function () {
        console.log('🔄 Refreshing dashboard data');

        this.updateChartVisuals();
        this.showNotification('📊 Dashboard data refreshed', 'success');

        // Haptic feedback
        if (navigator.vibrate) {
            navigator.vibrate([50, 100, 50]);
        }

        return true;
    },

    // Export dashboard data (mobile-friendly)
    exportData: function () {
        console.log('📤 Exporting dashboard data');

        // Simulate export with mobile sharing
        if (navigator.share) {
            navigator.share({
                title: 'Power BI Dashboard Data',
                text: 'Dashboard export from Universal Power BI',
                url: window.location.href
            });
        } else {
            this.showNotification('📱 Export completed', 'success');
        }

        return true;
    },

    // Search functionality with mobile optimization
    search: function (query) {
        console.log(`🔍 Searching for: ${query}`);

        // Simulate search results
        const results = [
            'Customer: Acme Corp',
            'Product: Wireless Headphones',
            'Region: North America Sales'
        ].filter(item => item.toLowerCase().includes(query.toLowerCase()));

        this.showNotification(`🔍 Found ${results.length} results for "${query}"`, 'info');

        return results;
    }
};

// Make dashboard globally accessible
window.testDashboard = window.universalPowerBITestDashboard;

console.log('🌟 Universal Power BI Test Dashboard fully loaded and ready for comprehensive chatbot testing');
