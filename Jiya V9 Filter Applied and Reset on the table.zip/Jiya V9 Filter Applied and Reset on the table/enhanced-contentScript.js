/*
====================================================================
ENHANCED POWER BI CHATBOT - CONTENT SCRIPT LOADER
====================================================================
Purpose: Load the enhanced chatbot specifically for your Power BI app
Target: https://app.powerbi.com/groups/me/apps/0201219b-480c-4bbc-bad5-2d47df08f957
====================================================================
*/

(function () {
    'use strict';

    // Prevent multiple injections
    if (window.__enhancedPowerBIChatbotInjected) return;
    window.__enhancedPowerBIChatbotInjected = true;

    console.log('🚀 Enhanced Power BI Chatbot Content Script Initializing...');

    // Check if we're on the target Power BI app
    const isTargetApp = () => {
        const currentUrl = window.location.href;
        return currentUrl.includes('0201219b-480c-4bbc-bad5-2d47df08f957') || 
               currentUrl.includes('app.powerbi.com/groups/me/apps');
    };

    // Load the enhanced chatbot system
    function loadEnhancedChatbotSystem() {
        if (!isTargetApp()) {
            console.log('❌ Not on target Power BI app - chatbot will not load');
            return;
        }

        console.log('✅ Target Power BI app detected - loading enhanced chatbot');

        // Try multiple methods to inject the chatbot
        console.log('🔄 Attempting to load enhanced chatbot...');
        
        // Method 1: Try chrome.runtime.getURL (for Chrome/Edge)
        try {
            const script = document.createElement('script');
            const extensionUrl = (typeof chrome !== 'undefined' && chrome.runtime) 
                ? chrome.runtime.getURL('enhanced-powerbi-chatbot.js')
                : browser?.runtime?.getURL('enhanced-powerbi-chatbot.js');
                
            if (extensionUrl) {
                script.src = extensionUrl;
                script.type = 'text/javascript';
                
                script.onload = () => {
                    console.log('✅ Enhanced Power BI Chatbot script loaded successfully');
                };
                
                script.onerror = (error) => {
                    console.error('❌ Failed to load enhanced chatbot script:', error);
                    loadFallbackChatbot();
                };
                
                (document.head || document.documentElement).appendChild(script);
                return;
            }
        } catch (error) {
            console.log('⚠️ Extension API not available, using fallback');
        }
        
        // Method 2: Load fallback immediately if extension API fails
        loadFallbackChatbot();
    }
    
    function loadFallbackChatbot() {
        console.log('🔄 Loading fallback chatbot...');
            
            // Fallback: inject inline
            const fallbackScript = document.createElement('script');
            fallbackScript.textContent = `
                console.log('🔄 Loading chatbot via fallback method...');
                
                // Mini version of the chatbot for fallback
                class FallbackPowerBIChatbot {
                    constructor() {
                        console.log('📱 Fallback chatbot initializing...');
                        this.createBasicChatbot();
                    }
                    
                    createBasicChatbot() {
                        const chatbotHTML = \`
                            <div id="fallback-powerbi-chatbot" style="
                                position: fixed;
                                bottom: 20px;
                                right: 20px;
                                width: 300px;
                                height: 400px;
                                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                                border-radius: 15px;
                                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                                z-index: 10000;
                                display: flex;
                                flex-direction: column;
                                font-family: 'Segoe UI', sans-serif;
                                color: white;
                            ">
                                <div style="padding: 15px; background: rgba(255,255,255,0.1); border-radius: 15px 15px 0 0;">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span>🤖 Power BI Assistant</span>
                                        <button onclick="this.parentElement.parentElement.parentElement.style.display='none'" style="
                                            background: rgba(255,255,255,0.2);
                                            border: none;
                                            border-radius: 50%;
                                            width: 25px;
                                            height: 25px;
                                            color: white;
                                            cursor: pointer;
                                        ">×</button>
                                    </div>
                                </div>
                                <div style="flex: 1; padding: 15px; overflow-y: auto;">
                                    <div style="background: rgba(255,255,255,0.9); color: #333; padding: 10px; border-radius: 10px; margin-bottom: 10px;">
                                        Hello! I'm your Power BI Assistant. 👋<br><br>
                                        I can help you navigate your Power BI app at:<br>
                                        <small>${window.location.href}</small><br><br>
                                        🔍 Try voice commands<br>
                                        📊 Navigate reports<br>
                                        📄 Switch between pages<br>
                                        🎯 Apply filters<br><br>
                                        <em>Enhanced features loading...</em>
                                    </div>
                                </div>
                                <div style="padding: 15px;">
                                    <div style="display: flex; gap: 10px;">
                                        <input type="text" placeholder="Ask me about your reports..." style="
                                            flex: 1;
                                            padding: 8px 12px;
                                            border: none;
                                            border-radius: 20px;
                                            outline: none;
                                        ">
                                        <button style="
                                            background: #007acc;
                                            border: none;
                                            border-radius: 50%;
                                            width: 35px;
                                            height: 35px;
                                            color: white;
                                            cursor: pointer;
                                        ">📤</button>
                                    </div>
                                </div>
                            </div>
                        \`;
                        
                        document.body.insertAdjacentHTML('beforeend', chatbotHTML);
                        console.log('✅ Fallback chatbot created');
                    }
                }
                
                // Initialize fallback chatbot
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', () => {
                        new FallbackPowerBIChatbot();
                    });
                } else {
                    new FallbackPowerBIChatbot();
                }
            `;
            
            (document.head || document.documentElement).appendChild(fallbackScript);
        };
        
        (document.head || document.documentElement).appendChild(script);
    }

    // Enhanced loading with multiple triggers
    function initializeChatbot() {
        // Wait for basic DOM
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', loadEnhancedChatbotSystem);
        } else {
            loadEnhancedChatbotSystem();
        }

        // Also try after a delay for dynamic content
        setTimeout(loadEnhancedChatbotSystem, 2000);
        
        // Monitor for Power BI loading
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.addedNodes.length > 0) {
                    // Check if Power BI content is being added
                    for (const node of mutation.addedNodes) {
                        if (node.nodeType === 1) { // Element node
                            const hasPowerBIContent = node.querySelector && (
                                node.querySelector('.visual-container, .slicer, iframe[src*="powerbi"]') ||
                                node.classList.contains('visual-container') ||
                                node.classList.contains('exploration-container')
                            );
                            
                            if (hasPowerBIContent) {
                                console.log('🎯 Power BI content detected, ensuring chatbot is loaded...');
                                setTimeout(loadEnhancedChatbotSystem, 1000);
                                break;
                            }
                        }
                    }
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        // Stop observing after 30 seconds
        setTimeout(() => observer.disconnect(), 30000);
    }

    // Start initialization
    initializeChatbot();

    console.log('✅ Enhanced Power BI Chatbot Content Script loaded');
})();
